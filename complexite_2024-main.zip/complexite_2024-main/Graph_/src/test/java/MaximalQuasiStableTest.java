import QuasiStableGraph.GraphClass.Graph;
import QuasiStableGraph.QuasiStable.MaximalQuasiStable;
import QuasiStableGraph.QuasiStable.QuasiStableChecker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

public class MaximalQuasiStableTest {

    // Test de base avec un graphe simple (chaîne de sommets)
    @Test
    public void testFindMaximalQuasiStable() {
        Graph graph = new Graph(4);
        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);

        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(graph);
        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertTrue(quasiStableSet.size() > 0, "L'ensemble quasi-stable maximal devrait contenir des sommets.");

        // Vérification qu'il n'y a pas plus d'une arête entre les sommets de l'ensemble quasi-stable
        assertTrue(QuasiStableChecker.isQuasiStable(graph,quasiStableSet), "Il ne devrait pas y avoir plus d'une arête dans l'ensemble quasi-stable.");
    }

    // Test avec un graphe complet (tous les sommets connectés entre eux)
    @Test
    public void testCompleteGraph() {
        Graph completeGraph = new Graph(4);
        completeGraph.addEdge(0, 1);
        completeGraph.addEdge(0, 2);
        completeGraph.addEdge(0, 3);
        completeGraph.addEdge(1, 2);
        completeGraph.addEdge(1, 3);
        completeGraph.addEdge(2, 3);

        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(completeGraph);

        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        System.out.println("Taille de l'ensemble quasi-stable maximal : " + quasiStableSet.size());

        // Dans un graphe complet, un ensemble quasi-stable maximal peut contenir au plus 2 sommets,
        assertTrue(quasiStableSet.size() <= 2, "Dans un graphe complet, l'ensemble quasi-stable maximal peut contenir jusqu'à 2 sommets.");
    }

    // Test avec un graphe sans arêtes (aucune connexion entre les sommets)
    @Test
    public void testGraphWithoutEdges() {
        Graph graphWithoutEdges = new Graph(5);

        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(graphWithoutEdges);
        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertEquals(5, quasiStableSet.size(), "Dans un graphe sans arêtes, tous les sommets devraient appartenir à l'ensemble quasi-stable maximal.");
    }

    // Test avec un graphe contenant un seul sommet
    @Test
    public void testSingleNodeGraph() {
        Graph singleNodeGraph = new Graph(1);

        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(singleNodeGraph);
        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertEquals(1, quasiStableSet.size(), "L'ensemble quasi-stable maximal dans un graphe à un sommet devrait contenir exactement 1 sommet.");
    }

    // Test avec un graphe en étoile
    @Test
    public void testStarGraph() {
        Graph starGraph = new Graph(5);
        // Graphe en étoile : le sommet 0 est connecté à tous les autres
        starGraph.addEdge(0, 1);
        starGraph.addEdge(0, 2);
        starGraph.addEdge(0, 3);
        starGraph.addEdge(0, 4);

        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(starGraph);
        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertTrue(quasiStableSet.size() > 0, "L'ensemble quasi-stable maximal devrait contenir des sommets.");

        // Vérification correcte : dans un graphe en étoile, l'ensemble quasi-stable maximal peut inclure le sommet central et un autre sommet
        assertTrue(quasiStableSet.contains(0) || quasiStableSet.size() <= 2, "L'ensemble quasi-stable maximal peut inclure le sommet central.");
    }
}
