import QuasiStableGraph.GraphClass.Graph;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

public class GraphTest {

    @Test
    public void testAddEdge() {
        Graph graph = new Graph(5);
        graph.addEdge(0, 1);
        assertTrue(graph.hasEdge(0, 1), "L'arête entre 0 et 1 devrait exister.");
        assertTrue(graph.hasEdge(1, 0), "L'arête entre 1 et 0 devrait exister.");
    }

    @Test
    public void testHasEdge() {
        Graph graph = new Graph(5);
        assertFalse(graph.hasEdge(1, 2), "L'arête entre 1 et 2 ne devrait pas exister.");
        graph.addEdge(1, 2);
        assertTrue(graph.hasEdge(1, 2), "L'arête entre 1 et 2 devrait exister.");
    }

    @Test
    public void testGetNeighbors() {
        Graph graph = new Graph(3);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        Set<Integer> neighbors = graph.getNeighbors(0);
        assertTrue(neighbors.contains(1), "Le sommet 1 devrait être voisin de 0.");
        assertTrue(neighbors.contains(2), "Le sommet 2 devrait être voisin de 0.");
        assertFalse(neighbors.contains(3), "Le sommet 3 ne devrait pas être voisin de 0.");
    }

    @Test
    public void testGetVertexCount() {
        Graph graph = new Graph(6);
        assertEquals(6, graph.getVertexCount(), "Le graphe devrait avoir 6 sommets.");
    }
}
