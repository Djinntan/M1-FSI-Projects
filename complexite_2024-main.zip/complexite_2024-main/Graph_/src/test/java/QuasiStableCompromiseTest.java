import QuasiStableGraph.GraphClass.Graph;
import QuasiStableGraph.QuasiStable.MaximalQuasiStable;
import QuasiStableGraph.QuasiStable.QuasiStableCompromise;
import QuasiStableGraph.QuasiStable.QuasiStableChecker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

public class QuasiStableCompromiseTest {

    @Test
    public void testFindCompromiseQuasiStable() {
        // Création d'un graphe simple
        Graph graph = new Graph(5);
        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(3, 4);

        // Trouver l'ensemble quasi-stable maximal
        Set<Integer> maximalSet = MaximalQuasiStable.findMaximalQuasiStable(graph);
        // Trouver l'ensemble quasi-stable avec l'algorithme de compromis
        Set<Integer> compromiseSet = QuasiStableCompromise.findCompromiseQuasiStable(graph);
        // Vérifications de base
        assertNotNull(maximalSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertNotNull(compromiseSet, "L'ensemble quasi-stable de compromis ne devrait pas être nul.");
        assertTrue(maximalSet.size() > 0, "L'ensemble quasi-stable maximal devrait contenir des sommets.");
        assertTrue(compromiseSet.size() > 0, "L'ensemble quasi-stable de compromis devrait contenir des sommets.");
        System.out.println(compromiseSet);
        System.out.println(maximalSet);
        // Vérification que l'ensemble quasi-stable de compromis est au moins aussi grand que celui trouvé par l'algorithme maximal
        assertTrue(compromiseSet.size() >= maximalSet.size(),
                "L'ensemble quasi-stable de compromis doit être de cardinalité supérieure ou égale à celui de l'ensemble maximal.");

        // Vérification que l'ensemble compromis est bien quasi-stable
        assertTrue(QuasiStableChecker.isQuasiStable(graph, compromiseSet),
                "L'ensemble quasi-stable de compromis doit être valide (quasi-stable).");

        // Optionnel : Afficher la taille des ensembles pour une vérification visuelle
        System.out.println("Taille de l'ensemble quasi-stable maximal : " + maximalSet.size());
        System.out.println("Taille de l'ensemble quasi-stable de compromis : " + compromiseSet.size());
    }

    @Test
    public void testCompromiseWithCompleteGraph() {
        // Test avec un graphe complet (chaque paire de sommets est connectée)
        Graph completeGraph = new Graph(4);
        completeGraph.addEdge(0, 1);
        completeGraph.addEdge(0, 2);
        completeGraph.addEdge(0, 3);
        completeGraph.addEdge(1, 2);
        completeGraph.addEdge(1, 3);
        completeGraph.addEdge(2, 3);

        // Trouver l'ensemble quasi-stable maximal
        Set<Integer> maximalSet = MaximalQuasiStable.findMaximalQuasiStable(completeGraph);

        // Trouver l'ensemble quasi-stable avec l'algorithme de compromis
        Set<Integer> compromiseSet = QuasiStableCompromise.findCompromiseQuasiStable(completeGraph);

        // Vérifications
        assertNotNull(maximalSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertNotNull(compromiseSet, "L'ensemble quasi-stable de compromis ne devrait pas être nul.");

        // Dans un graphe complet, l'ensemble quasi-stable maximal et l'ensemble de compromis peuvent être de petite taille
        assertTrue(compromiseSet.size() <= 2, "Dans un graphe complet, l'ensemble quasi-stable doit être de petite taille (maximum 2).");

        // Vérification de la validité de l'ensemble quasi-stable de compromis
        assertTrue(QuasiStableChecker.isQuasiStable(completeGraph, compromiseSet),
                "L'ensemble quasi-stable de compromis doit être valide (quasi-stable).");

        System.out.println("Taille de l'ensemble quasi-stable maximal : " + maximalSet.size());
        System.out.println("Taille de l'ensemble quasi-stable de compromis : " + compromiseSet.size());
    }

    @Test
    public void testCompromiseWithGraphWithoutEdges() {
        // Test avec un graphe sans arêtes
        Graph graphWithoutEdges = new Graph(5);

        // Trouver l'ensemble quasi-stable maximal
        Set<Integer> maximalSet = MaximalQuasiStable.findMaximalQuasiStable(graphWithoutEdges);

        // Trouver l'ensemble quasi-stable avec l'algorithme de compromis
        Set<Integer> compromiseSet = QuasiStableCompromise.findCompromiseQuasiStable(graphWithoutEdges);

        // Vérifications
        assertNotNull(maximalSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertNotNull(compromiseSet, "L'ensemble quasi-stable de compromis ne devrait pas être nul.");

        // Dans un graphe sans arêtes, tous les sommets doivent être quasi-stables
        assertEquals(5, maximalSet.size(), "Dans un graphe sans arêtes, tous les sommets devraient appartenir à l'ensemble quasi-stable maximal.");
        assertEquals(5, compromiseSet.size(), "Dans un graphe sans arêtes, tous les sommets devraient appartenir à l'ensemble quasi-stable de compromis.");

        System.out.println("Taille de l'ensemble quasi-stable maximal : " + maximalSet.size());
        System.out.println("Taille de l'ensemble quasi-stable de compromis : " + compromiseSet.size());
    }

    @Test
    public void testCompromiseImprovesOverMaximal() {
        // Création d'un graphe en "papillon" ou forme de cycle
        Graph butterflyGraph = new Graph(6);
        butterflyGraph.addEdge(0, 1);  // Forme un groupe {0, 1}
        butterflyGraph.addEdge(1, 2);  // Connexion entre groupes
        butterflyGraph.addEdge(2, 3);  // Forme un groupe {2, 3}
        butterflyGraph.addEdge(3, 4);  // Connexion entre groupes
        butterflyGraph.addEdge(4, 5);  // Forme un groupe {4, 5}

        // Trouver l'ensemble quasi-stable maximal
        Set<Integer> maximalSet = MaximalQuasiStable.findMaximalQuasiStable(butterflyGraph);

        // Trouver l'ensemble quasi-stable avec l'algorithme de compromis
        Set<Integer> compromiseSet = QuasiStableCompromise.findCompromiseQuasiStable(butterflyGraph);

        // Vérifications de base
        assertNotNull(maximalSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertNotNull(compromiseSet, "L'ensemble quasi-stable de compromis ne devrait pas être nul.");
        assertTrue(maximalSet.size() > 0, "L'ensemble quasi-stable maximal devrait contenir des sommets.");
        assertTrue(compromiseSet.size() > 0, "L'ensemble quasi-stable de compromis devrait contenir des sommets.");

        // Vérification que l'ensemble quasi-stable de compromis est plus grand que celui trouvé par l'algorithme maximal
        assertTrue(compromiseSet.size() >= maximalSet.size(),
                "L'ensemble quasi-stable de compromis doit être de cardinalité supérieure à celui de l'ensemble maximal.");

        // Vérification que les deux ensembles sont bien quasi-stables
        assertTrue(QuasiStableChecker.isQuasiStable(butterflyGraph, maximalSet),
                "L'ensemble quasi-stable maximal doit être valide (quasi-stable).");
        assertTrue(QuasiStableChecker.isQuasiStable(butterflyGraph, compromiseSet),
                "L'ensemble quasi-stable de compromis doit être valide (quasi-stable).");

        // Afficher la taille des ensembles pour confirmation
        System.out.println("Taille de l'ensemble quasi-stable maximal : " + maximalSet.size());
        System.out.println("Taille de l'ensemble quasi-stable de compromis : " + compromiseSet.size());
    }

    @Test
    public void testCompromiseWithComplexGraph() {
        // Un graphe avec plusieurs composants et connexions
        Graph complexGraph = new Graph(7);
        complexGraph.addEdge(0, 1);  // Groupe de {0, 1}
        complexGraph.addEdge(1, 2);  // Groupe de {1, 2}
        complexGraph.addEdge(2, 3);  // Groupe de {2, 3}
        complexGraph.addEdge(4, 5);  // Un autre groupe {4, 5}
        complexGraph.addEdge(5, 6);  // Groupe de {5, 6}
        complexGraph.addEdge(0, 4);  // Connexion entre {0, 1} et {4, 5}

        // Trouver l'ensemble quasi-stable maximal
        Set<Integer> maximalSet = MaximalQuasiStable.findMaximalQuasiStable(complexGraph);

        // Trouver l'ensemble quasi-stable avec l'algorithme de compromis
        Set<Integer> compromiseSet = QuasiStableCompromise.findCompromiseQuasiStable(complexGraph);

        // Vérifications de base
        assertNotNull(maximalSet, "L'ensemble quasi-stable maximal ne devrait pas être nul.");
        assertNotNull(compromiseSet, "L'ensemble quasi-stable de compromis ne devrait pas être nul.");

        // Vérification que l'ensemble quasi-stable de compromis est plus grand que celui trouvé par l'algorithme maximal
        assertTrue(compromiseSet.size() >= maximalSet.size(),
                "L'ensemble quasi-stable de compromis doit être de cardinalité supérieure à celui de l'ensemble maximal.");

        // Vérification que les deux ensembles sont bien quasi-stables
        assertTrue(QuasiStableChecker.isQuasiStable(complexGraph, maximalSet),
                "L'ensemble quasi-stable maximal doit être valide (quasi-stable).");
        assertTrue(QuasiStableChecker.isQuasiStable(complexGraph, compromiseSet),
                "L'ensemble quasi-stable de compromis doit être valide (quasi-stable).");

        // Afficher la taille des ensembles pour confirmation
        System.out.println("Taille de l'ensemble quasi-stable maximal : " + maximalSet.size());
        System.out.println("Taille de l'ensemble quasi-stable de compromis : " + compromiseSet.size());
    }
}
