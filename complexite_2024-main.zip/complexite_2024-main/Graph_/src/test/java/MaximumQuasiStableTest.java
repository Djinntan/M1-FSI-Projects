import QuasiStableGraph.GraphClass.Graph;
import QuasiStableGraph.QuasiStable.MaximumQuasiStable;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

public class MaximumQuasiStableTest {

    @Test
    public void testFindMaximumQuasiStable() {
        Graph graph = new Graph(4);
        graph.addEdge(0, 1);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);

        Set<Integer> quasiStableSet = MaximumQuasiStable.findMaximumQuasiStable(graph);
        assertNotNull(quasiStableSet, "L'ensemble quasi-stable maximum ne devrait pas être nul.");
        assertTrue(quasiStableSet.size() > 0, "L'ensemble quasi-stable maximum devrait contenir des sommets.");
    }
}
