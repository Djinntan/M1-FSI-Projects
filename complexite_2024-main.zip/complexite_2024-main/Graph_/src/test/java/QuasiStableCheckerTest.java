import QuasiStableGraph.GraphClass.Graph;
import QuasiStableGraph.QuasiStable.QuasiStableChecker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

public class QuasiStableCheckerTest {

    @Test
    public void testIsQuasiStable() {
        Graph graph = new Graph(4);
        graph.addEdge(0, 1);
        graph.addEdge(2, 3);

        Set<Integer> stableSet = new HashSet<>();
        stableSet.add(0);
        stableSet.add(2);

        assertTrue(QuasiStableChecker.isQuasiStable(graph, stableSet), "L'ensemble devrait être quasi-stable.");

        stableSet.add(1);
        assertTrue(QuasiStableChecker.isQuasiStable(graph, stableSet), "L'ensemble ne devrait pas être quasi-stable.");

        stableSet.add(3);
        assertFalse(QuasiStableChecker.isQuasiStable(graph, stableSet), "L'ensemble ne devrait pas être quasi-stable.");
    }
}
