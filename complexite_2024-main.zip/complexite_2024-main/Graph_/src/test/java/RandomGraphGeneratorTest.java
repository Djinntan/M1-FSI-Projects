import QuasiStableGraph.Generators.RandomGraphGenerator;
import QuasiStableGraph.GraphClass.Graph;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RandomGraphGeneratorTest {

    @Test
    public void testGenerateRandomGraph() {
        int n = 5;
        double p = 0.5;
        Graph graph = RandomGraphGenerator.generateRandomGraph(n, p);

        assertEquals(5, graph.getVertexCount(), "Le graphe devrait avoir 5 sommets.");
    }

    @Test
    public void testGenerateRandomGraphWithQuasiStable() {
        int n = 5;
        double p = 0.5;
        int k = 3;
        Graph graph = RandomGraphGenerator.generateRandomGraphWithQuasiStable(n, p, k);

        assertEquals(5, graph.getVertexCount(), "Le graphe devrait avoir 5 sommets.");
    }
}
