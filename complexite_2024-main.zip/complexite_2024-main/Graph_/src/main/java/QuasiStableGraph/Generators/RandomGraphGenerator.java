package QuasiStableGraph.Generators;

import QuasiStableGraph.GraphClass.Graph;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class RandomGraphGenerator {

    public static Graph generateRandomGraph(int n, double p) {
        Graph G = new Graph(n);
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (rand.nextDouble() < p) {
                    G.addEdge(i, j);
                }
            }
        }
        return G;
    }

    public static Graph generateRandomGraphWithQuasiStable(int n, double p, int k) {
        Graph G = generateRandomGraph(n, p);
        Set<Integer> quasiStableSet = new HashSet<>();
        Random rand = new Random();
        while (quasiStableSet.size() < k) {
            quasiStableSet.add(rand.nextInt(n));
        }

        // S'assurer qu'il y ait au plus une arête dans le sous-ensemble quasi-stable
        Integer[] vertices = quasiStableSet.toArray(new Integer[0]);
        for (int i = 1; i < k; i++) {
            for (int j = i + 1; j < k; j++) {
                if (G.hasEdge(vertices[i], vertices[j])) {
                    G.addEdge(vertices[i], vertices[j]);
                }
            }
        }
        return G;
    }
}
