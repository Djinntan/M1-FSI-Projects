package QuasiStableGraph.QuasiStable;


import QuasiStableGraph.GraphClass.Graph;
import java.util.HashSet;
import java.util.Set;

public class MaximalQuasiStable {

    public static Set<Integer> findMaximalQuasiStable(Graph G) {
        Set<Integer> quasiStableSet = new HashSet<>();
        if(G.getVertexCount()>0)quasiStableSet.add(0);
        for (int u = 0; u < G.getVertexCount()-1; u++) {
            quasiStableSet.add(u+1);
            if (!QuasiStableChecker.isQuasiStable(G, quasiStableSet)) {
                quasiStableSet.remove(u+1);
            }
        }
        return quasiStableSet;
    }
}
