package QuasiStableGraph.QuasiStable;

import QuasiStableGraph.GraphClass.Graph;
import java.util.HashSet;
import java.util.Set;

public class MaximumQuasiStable {

    public static Set<Integer> findMaximumQuasiStable(Graph G) {
        Set<Integer> bestSet = new HashSet<>();
        return findMaximum(G, new HashSet<>(), 0, bestSet);
    }

    private static Set<Integer> findMaximum(Graph G, Set<Integer> currentSet, int vertex, Set<Integer> bestSet) {
        if (vertex == G.getVertexCount()) {
            if (QuasiStableChecker.isQuasiStable(G, currentSet) && currentSet.size() > bestSet.size()) {
                bestSet = new HashSet<>(currentSet);
            }
            return bestSet;
        }

        currentSet.add(vertex);
        Set<Integer> withVertex = findMaximum(G, currentSet, vertex + 1, bestSet);
        currentSet.remove(vertex);
        Set<Integer> withoutVertex = findMaximum(G, currentSet, vertex + 1, bestSet);

        return (withVertex.size() > withoutVertex.size()) ? withVertex : withoutVertex;
    }
}
