package QuasiStableGraph.QuasiStable;


import QuasiStableGraph.GraphClass.Graph;
import java.util.Set;

public class QuasiStableChecker {

    public static boolean isQuasiStable(Graph G, Set<Integer> X) {
        int count = 0 ;
        for (int u =0 ; u<G.getVertexCount()-1; u++) {
            for (int v =u+1 ; v<G.getVertexCount(); v++) {
                if(X.contains(u) && X.contains(v)) {
                    if (G.hasEdge(u, v) && count>=1) {
                        return false;  // Il y a plus d'une arête
                    }else if(G.hasEdge(u, v) && count<1){
                        count++;
                    }
                }
            }
        }
        return true;
    }
}
