package QuasiStableGraph.QuasiStable;

import QuasiStableGraph.GraphClass.Graph;
import java.util.HashSet;
import java.util.Set;

public class QuasiStableCompromise {

    public static Set<Integer> findCompromiseQuasiStable(Graph G) {
        Set<Integer> quasiStableSet = MaximalQuasiStable.findMaximalQuasiStable(G);
        return improveBySwapping(G, quasiStableSet);
    }


    private static Set<Integer> improveBySwapping(Graph G, Set<Integer> quasiStableSet) {
        boolean improved = true;
        Set<Integer> bestSet = new HashSet<>(quasiStableSet);

        while (improved) {
            improved = false;

            // Parcourir les sommets qui ne sont pas dans l'ensemble quasi-stable
            for (Integer u = 0; u < G.getVertexCount(); u++) {
                if (!quasiStableSet.contains(u)) {
                    // Essayer de retirer un sommet de l'ensemble quasi-stable et d'ajouter ce sommet
                    for (int i =0 ; i < G.getVertexCount() ; i++) {
                        if(quasiStableSet.contains(i)){
                            quasiStableSet.remove(i);
                            quasiStableSet.add(u);
                            // Vérifier si ce nouvel ensemble est quasi-stable et s'il est meilleur
                            if (QuasiStableChecker.isQuasiStable(G, quasiStableSet) && quasiStableSet.size() >= bestSet.size()) {
                                bestSet = new HashSet<>(quasiStableSet);
                                improved = true;  // Amélioration trouvée
                                break;  // Arrêter la boucle dès qu'on trouve une amélioration
                            }
                            // Sinon, on annule le changement
                            quasiStableSet.remove(u);
                            quasiStableSet.add(i);
                        }
                    }
                    if(improved){
                        for (Integer v = u+1; v < G.getVertexCount(); v++) {
                            if(!bestSet.contains(v)){
                            bestSet.add(v);
                            if (!QuasiStableChecker.isQuasiStable(G, bestSet)) {
                                bestSet.remove(v);}
                            }
                        }
                    }
                    improved = false;
                }
            }
        }
        return bestSet;
    }
}
