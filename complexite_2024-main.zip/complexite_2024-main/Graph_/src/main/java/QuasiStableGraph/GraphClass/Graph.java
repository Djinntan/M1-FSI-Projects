package QuasiStableGraph.GraphClass;

import java.util.HashSet;
import java.util.Set;

public class Graph {
    private final int n;  // Nombre de sommets
    private final Set<Integer>[] adjList;  // Liste d'adjacence pour chaque sommet

    @SuppressWarnings("unchecked")
    public Graph(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Le nombre de sommets doit être positif.");
        }
        this.n = n;
        this.adjList = (Set<Integer>[]) new HashSet[n];
        for (int i = 0; i < n; i++) {
            adjList[i] = new HashSet<>();
        }
    }

    public void addEdge(int u, int v) {
        if (u != v) {
            adjList[u].add(v);
            adjList[v].add(u);
        }
    }

    public boolean hasEdge(int u, int v) {
        return adjList[u].contains(v);
    }

    public Set<Integer> getNeighbors(int u) {
        return adjList[u];
    }

    public int getVertexCount() {
        return n;
    }
}
