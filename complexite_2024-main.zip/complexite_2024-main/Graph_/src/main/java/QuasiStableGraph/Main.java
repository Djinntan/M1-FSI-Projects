package QuasiStableGraph;

import QuasiStableGraph.GraphClass.Graph;
import QuasiStableGraph.Generators.RandomGraphGenerator;
import QuasiStableGraph.QuasiStable.MaximumQuasiStable;
import QuasiStableGraph.SAT.SatReduction;
import QuasiStableGraph.SAT.SatFileWriter;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Saisie des paramètres du graphe et de la taille quasi-stable
            System.out.print("Veuillez entrer le nombre de sommets du graphe : ");
            int numberOfVertices = scanner.nextInt();
            System.out.print("Veuillez entrer la probabilité de création des arêtes (entre 0 et 1) : ");
            double edgeProbability = scanner.nextDouble();
            System.out.print("Veuillez entrer la taille de l'ensemble quasi-stable (k) : ");
            int k = scanner.nextInt();

            Graph graph = RandomGraphGenerator.generateRandomGraph(numberOfVertices, edgeProbability);

            // Mesurer le temps d'exécution pour MiniSat (réduction SAT)
            long startTimeSat = System.currentTimeMillis();
            List<String> clauses = SatReduction.generateSatClauses(graph, k);
            SatFileWriter.writeDimacsFile(clauses, "input.dimacs", graph.getVertexCount());

            ProcessBuilder processBuilder = new ProcessBuilder("minisat", "input.dimacs", "output.txt");
            Process process = processBuilder.start();
            process.waitFor();

            long endTimeSat = System.currentTimeMillis();
            System.out.println("Temps d'exécution pour MiniSat : " + (endTimeSat - startTimeSat) + " ms");

            // Mesurer le temps d'exécution pour l'algorithme exact (MaximumQuasiStable)
            long startTimeExact = System.currentTimeMillis();
            Set<Integer> maximumQuasiStable = MaximumQuasiStable.findMaximumQuasiStable(graph);
            long endTimeExact = System.currentTimeMillis();
            System.out.println("Temps d'exécution pour MaximumQuasiStable : " + (endTimeExact - startTimeExact) + " ms");

            System.out.println("Ensemble quasi-stable maximum trouvé : " + maximumQuasiStable);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
