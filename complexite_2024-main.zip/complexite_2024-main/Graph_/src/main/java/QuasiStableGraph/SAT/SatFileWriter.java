package QuasiStableGraph.SAT;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class SatFileWriter {

    public static void writeDimacsFile(List<String> clauses, String fileName, int numVariables) throws IOException {
        FileWriter writer = new FileWriter(fileName);

        // En-tête du fichier DIMACS
        writer.write(String.format("p cnf %d %d\n", numVariables, clauses.size()));

        // Écrire chaque clause
        for (String clause : clauses) {
            writer.write(clause + " \n"); // Chaque clause se termine par "0" en DIMACS
        }

        writer.close();
    }
}
