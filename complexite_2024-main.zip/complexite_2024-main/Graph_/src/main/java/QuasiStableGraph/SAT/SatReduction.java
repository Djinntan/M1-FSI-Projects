package QuasiStableGraph.SAT;

import QuasiStableGraph.GraphClass.Graph;

import java.util.ArrayList;
import java.util.List;

public class SatReduction {

    // Générer les clauses SAT pour la quasi-stabilité
    public static List<String> generateSatClauses(Graph G, int k) {
        List<String> clauses = new ArrayList<>();

        // Contrainte 1 : Sélectionner exactement k sommets
        clauses.add(generateExactlyKVertices(G, k));

        // Contrainte 2 : Quasi-stabilité
        for (int u = 0; u < G.getVertexCount(); u++) {
            for (int v = u + 1; v < G.getVertexCount(); v++) {
                if (G.hasEdge(u, v)) {
                    clauses.add(generateQuasiStabilityClause(u, v));
                }
            }
        }

        return clauses;
    }

    // Générer la contrainte pour exactement k sommets sélectionnés
    private static String generateExactlyKVertices(Graph G, int k) {
        StringBuilder clause = new StringBuilder();
        // Exprimer que la somme des variables est exactement k
        for (int i = 1; i <= G.getVertexCount(); i++) {
            clause.append(i).append(" ");
        }
        clause.append("0"); // Fin de clause
        return clause.toString();
    }

    // Générer la clause de quasi-stabilité pour une arête (u, v)
    private static String generateQuasiStabilityClause(int u, int v) {
        return String.format("-%d -%d 0", u + 1, v + 1); // Les variables sont indexées à partir de 1
    }
}
