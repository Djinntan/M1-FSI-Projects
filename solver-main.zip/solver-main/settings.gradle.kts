rootProject.name = "GL-Solver"

