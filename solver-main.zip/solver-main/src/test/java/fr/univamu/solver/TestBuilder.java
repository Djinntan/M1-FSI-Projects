package fr.univamu.solver;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class TestBuilder {
    @Test
    public void testVarCreation () {
        var builder = new Builder();
		var a = builder.newVar("A").domain(0, 9);

        assertEquals("A", a.getName());
        int expectedmin = 0;
        int expectedmax = 9;
        assertEquals(0, a.getMin());
        assertEquals(9, a.getMax());
    }
    @Test
    public void testNewVar() {
        var builder = new Builder();
        var b = builder.newVar("B");

        assertEquals("B", b.getName());
        assertFalse(b.isFixed()); // Check if the variable is not fixed
    }

    @Test
    public void testAddConstraintEquals() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5);
        var b = builder.newVar("B").domain(3, 7);
        builder.addConstraint(a, "=", b);

        // Check if constraints are added correctly
        assertEquals(1, builder.getConstraints().size()); // One constraint should be added
    }

    @Test
    public void testAddConstraintGreaterThan() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5);
        var b = builder.newVar("B").domain(3, 7);
        builder.addConstraint(a, ">", b);

        // Check if constraints are added correctly
        assertEquals(1, builder.getConstraints().size());
        // Optionally, you can validate the specific constraint details.
    }

    @Test
    public void testAddAllDifferentConstraint() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5);
        var b = builder.newVar("B").domain(3, 7);
        var c = builder.newVar("C").domain(0, 10);

        builder.allDiff(a, b, c);

        // Check if all-different constraints are added correctly
        assertEquals(3, builder.getConstraints().size()); // Three constraints should be added
    }

    @Test
    public void testAddConstraintInvalidRelation() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5);
        var b = builder.newVar("B").domain(3, 7);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            builder.addConstraint(a, "invalid_relation", b);
        });

        assertEquals("Unsupported relation: invalid_relation", exception.getMessage());
    }

    @Test
    public void testExpression2() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5);
        var b = builder.newVar("B").domain(3, 7);
        var c = builder.newVar("C").domain(2, 4);

        // Assuming the expression A + B - C should be created
        var result = builder.expression2(a, "+", b, "-", c);

        // Validate the resulting variable
        assertNotNull(result);
        // You may want to check if the correct constraints are created for the expression
    }

    @Test
    public void testVariableDomainFixedValue() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(5); // Fixed value

        assertEquals(5, a.getFixedValue());
        
        // Check if the variable is fixed
        assertTrue(a.isFixed());
    }

    @Test
    public void testVariableDomainIllegalState() {
        var builder = new Builder();
        var a = builder.newVar("A").domain(1, 5); // Not fixed

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            a.getFixedValue();
        });

        assertEquals("variable not fixed: " + a, exception.getMessage());
    }
    @Test
    public void testExpression_APlus2EqualsB() {
        Builder builder = new Builder();
        Variable varA = builder.newVar("A");
        Variable varB = builder.newVar("B");
        
        builder.addConstraint(varA, "+", 2, "=", varB);
        
        assertEquals(2, builder.getVariables().size(), "There should be 2 variables: A and B");

        assertEquals(2, builder.getConstraints().size());
    }

    @Test
public void testOptimizedParser() {
    var builder = new Builder();
    var a = builder.newVar("A").domain(1, 5);
    var b = builder.newVar("B").domain(1, 5);
    
    // Add constraint A + 2 = B
    builder.addConstraint(a, "+", 2, "=", b);

    // Print out the variables
    for (Variable var : builder.getVariables()) {
        System.out.println("Variable: " + var.getName() + " Domain: " + var.getMin() + " to " + var.getMax());
    }
    for (Constraint con : builder.getConstraints()){
        System.out.println("Constraints"+ con.toString());
    }
    // Check number of variables
    System.out.println("Total Variables: " + builder.getVariables().size());
}

}
