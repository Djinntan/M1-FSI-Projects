package fr.univamu.solver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class TestAlwaysReduceStrategy {

    // Helper method to create the N-Queens problem for testing
    private Solver makeQueens(int n, IStrategy strategy) {
        var solver = new Solver();
        var builder = new Builder(); // Create a builder instance
        solver.setStrategy(strategy);

        var queens = new Variable[n];
        for (int i = 0; i < n; i++) {
            queens[i] = builder.newVar("Q" + i).domain(1, n);  // Create domain 1 to n
            
            for (int j = 0; j < i; j++) {
                // Corrected to use "!=" instead of "<>"
                builder.addConstraint(queens[i], "!=", queens[j]);  // Q[i] != Q[j] for row constraints
                
                // Corrected to use "!=" for diagonal constraints
                builder.addConstraint(queens[i], "+", i, "!=", queens[j], "+", j);  // Diagonal constraint
                builder.addConstraint(queens[i], "-", i, "!=", queens[j], "-", j);  // Diagonal constraint
            }
        }
        return solver;
    }

    @Test
    public void testAlwaysReduceStrategyVsDefault() {
        int n = 8;  // N-Queens Problem

        // Create a solver with DefaultStrategy
        var defaultStrategy = new DefaultStrategy();
        var solverWithDefault = makeQueens(n, defaultStrategy);
        Solutions defaultSolutions = solverWithDefault.solve(true);  // 'true' to display solutions
        long defaultStrategyNodes = solverWithDefault.getNodesCounter();

        // Create a builder and pass it to AlwaysReduceStrategy
        var alwaysReduceStrategy = new AlwaysReduceStrategy(new Builder());
        var solverWithAlwaysReduce = makeQueens(n, alwaysReduceStrategy);
        Solutions alwaysReduceSolutions = solverWithAlwaysReduce.solve(false);  // 'false' to skip displaying solutions
        long alwaysReduceStrategyNodes = solverWithAlwaysReduce.getNodesCounter();
        // Compare results: AlwaysReduce should explore fewer or equal nodes
        assertTrue(alwaysReduceStrategyNodes <= defaultStrategyNodes, 
            "AlwaysReduceStrategy should explore fewer or equal nodes than DefaultStrategy");
        assertEquals(92, defaultSolutions.getSolutionsCount());
        
        // Print node counts for comparison
        System.out.println("Default Strategy Nodes: " + defaultStrategyNodes);
        System.out.println("Always Reduce Strategy Nodes: " + alwaysReduceStrategyNodes);

        // Optional: Process the solutions if needed
        if (defaultSolutions.getSolutionsCount() > 0) {
            System.out.println("Default Strategy found solutions: " + defaultSolutions.getSolutionsCount());
        }
        if (alwaysReduceSolutions.getSolutionsCount() > 0) {
            System.out.println("Always Reduce Strategy found solutions: " + alwaysReduceSolutions.getSolutionsCount());
        }
    }
}
