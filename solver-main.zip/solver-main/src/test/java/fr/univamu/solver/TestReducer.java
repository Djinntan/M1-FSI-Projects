package fr.univamu.solver;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TestReducer {

    @Test
    public void testDiffReductionCase1() {
        // X in [10,20], Y in [20,20] --> X in [10,19], Y in [20,20]
        var builder = new Builder();
        var x = builder.newVar("X").domain(10, 20);
        var y = builder.newVar("Y").domain(20, 20);

        builder.addConstraint(x, "<>", y);
        var reducer = new Reducer();
        reducer.reduce(builder.getProblem());

        assertEquals(10, x.getMin());
        assertEquals(19, x.getMax());
        assertEquals(20, y.getMin());
    }

    @Test
    public void testDiffReductionCase2() {
        // X in [10,10], Y in [10,11] --> X in [10,10], Y in [11,11]
        var builder = new Builder();
        var x = builder.newVar("X").domain(10, 10);
        var y = builder.newVar("Y").domain(10, 11);

        builder.addConstraint(x, "<>", y);
        var reducer = new Reducer();
        reducer.reduce(builder.getProblem());

        // Check the reduced intervals
        assertEquals(10, x.getMin());
        assertEquals(10, x.getMax());
        assertEquals(11, y.getMin());
        assertEquals(11, y.getMax());  // This one already works
    }

    @Test
    public void testDiffReductionCase3() {
        // X in [15,15], Y in [15,15] --> X in [], Y in []
        var builder = new Builder();
        var x = builder.newVar("X").domain(15, 15);
        var y = builder.newVar("Y").domain(15, 15);

        builder.addConstraint(x, "<>", y);
        var reducer = new Reducer();
        reducer.reduce(builder.getProblem());

        assertTrue(x.isEmpty());
        assertTrue(y.isEmpty());
    }
}
