package fr.univamu.solver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;

import java.util.function.BiFunction;

import org.junit.jupiter.api.Test;

public class TestInterval {
	
	@Test
	void testEmpty() {
		var i = new Interval(20, 10);
		assertTrue(i.isEmpty());
	}

	@Test
	void testFixed() {
		var i = new Interval(20, 20);
		assertTrue(i.isFixed());
	}

	@Test
	void testAdd() {
		var a = new Interval(20, 30);
		var b = new Interval(-33, -5);
		assertEquals("[-13,25]", a.add(b).toString());
	}

	private Interval exploreBiFunction(//
            BiFunction<Integer, Integer, Integer> operation, //
            Interval a, Interval b) {
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        // Parcours de toutes les combinaisons possibles entre les valeurs des intervalles a et b
        for (int i = a.getMin(); i <= a.getMax(); i++) {
            for (int j = b.getMin(); j <= b.getMax(); j++) {
                int result = operation.apply(i, j);
                if (result < min) {
                    min = result;
                }
                if (result > max) {
                    max = result;
                }
            }
        }
        return new Interval(min, max);
    }

    // Test de l'addition via exploreBiFunction
    @Test
    public void testExploreBiFunctionAddition() {
        Interval a = new Interval(1, 3);
        Interval b = new Interval(4, 6);

        Interval resultExplored = exploreBiFunction((x, y) -> x + y, a, b);
        Interval resultAdd = a.add(b);
        System.out.println("The result of the explored Bifunction is" + resultExplored);
        System.out.println("The result of the add operator is" + resultAdd);


        assertEquals(resultExplored, resultAdd);
    }
    @Test 
    public void enumerateBiFunction () {
        Interval a = new Interval (-8,8);
        Interval b = new Interval (-8,8);
        ArrayList<Interval> intervalA = new ArrayList<>();
        ArrayList<Interval> intervalB = new ArrayList<>();

        for (int aMin = a.getMin(); aMin <= 8; aMin++) {
            for (int aMax = aMin; aMax <= 8; aMax++) {
                Interval interval = new Interval(aMin, aMax);
                intervalA.add(interval);
            }
        }

        for (int bMin = b.getMin(); bMin <= 8; bMin++) {
            for (int bMax = bMin; bMax <= 8; bMax++) {
                Interval interval = new Interval(bMin, bMax);
                intervalB.add(interval);
            }
        }
        int count = 0;
        for (Interval intA : intervalA) {
            for (Interval intB : intervalB) {
                count++;
                //System.out.println("Interval A: " + intA + ", Interval B: " + intB);
            }  
        }
        System.out.println("Total number of interval pairs: " + count);

    }

    // Tests exhaustifs pour toutes les opérations
    @Test
    public void testExhaustiveAddition() {
        for (int aMin = -8; aMin <= 8; aMin++) {
            for (int aMax = aMin; aMax <= 8; aMax++) {
                Interval a = new Interval(aMin, aMax);
                for (int bMin = -8; bMin <= 8; bMin++) {
                    for (int bMax = bMin; bMax <= 8; bMax++) {
                        Interval b = new Interval(bMin, bMax);
                        Interval resultExplored = exploreBiFunction((x, y) -> x + y, a, b);
                        Interval resultAdd = a.add(b);
                        assertEquals(resultExplored, resultAdd);
                    }
                }
            }
        }
    }

    @Test
    public void testExhaustiveSubtraction() {
        // De la même manière, test exhaustif pour la soustraction
        for (int aMin = -8; aMin <= 8; aMin++) {
            for (int aMax = aMin; aMax <= 8; aMax++) {
                Interval a = new Interval(aMin, aMax);
                for (int bMin = -8; bMin <= 8; bMin++) {
                    for (int bMax = bMin; bMax <= 8; bMax++) {
                        Interval b = new Interval(bMin, bMax);
                        Interval resultExplored = exploreBiFunction((x, y) -> x - y, a, b);
                        Interval resultSub = a.sub(b);
                        assertEquals(resultExplored, resultSub);
                    }
                }
            }
        }
    }

    @Test
    public void testExhaustiveMultiplication() {
        // Test exhaustif pour la multiplication
        for (int aMin = -8; aMin <= 8; aMin++) {
            for (int aMax = aMin; aMax <= 8; aMax++) {
                Interval a = new Interval(aMin, aMax);
                for (int bMin = -8; bMin <= 8; bMin++) {
                    for (int bMax = bMin; bMax <= 8; bMax++) {
                        Interval b = new Interval(bMin, bMax);
                        Interval resultExplored = exploreBiFunction((x, y) -> x * y, a, b);
                        Interval resultMul = a.mul(b);
                        assertEquals(resultExplored, resultMul);
                    }
                }
            }
        }
    }

    @Test
    public void testExhaustiveDivision() {
        // Test exhaustif pour la division, en évitant la division par 0
        for (int aMin = -8; aMin <= 8; aMin++) {
            for (int aMax = aMin; aMax <= 8; aMax++) {
                Interval a = new Interval(aMin, aMax);
                for (int bMin = -8; bMin <= 8; bMin++) {
                    for (int bMax = bMin; bMax <= 8; bMax++) {
                        Interval b = new Interval(bMin, bMax);
                        if (b.getMin() <= 0 && b.getMax() >= 0) {
                            continue; // éviter la division par 0
                        }
                        Interval resultExplored = exploreBiFunction((x, y) -> x / y, a, b);
                        Interval resultDiv = a.div(b);
                        assertEquals(resultExplored, resultDiv);
                    }
                }
            }
        }
    }

}
