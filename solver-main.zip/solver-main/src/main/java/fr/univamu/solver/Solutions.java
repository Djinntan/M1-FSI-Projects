package fr.univamu.solver;

import java.util.ArrayList;
import java.util.List;

public class Solutions {

    // List to store each solution as a list of variable assignments
    private List<List<Assignment>> allSolutions;
    private long solutionsCount;
    private boolean displaySolutions; // Flag to control whether solutions are displayed

    // Constructor
    public Solutions(boolean displaySolutions) {
        this.allSolutions = new ArrayList<>();
        this.solutionsCount = 0;
        this.displaySolutions = displaySolutions;
    }

    // Method to add a solution
    public void addSolution(List<Assignment> solution) {
        allSolutions.add(solution);
        solutionsCount++;
        if (displaySolutions) {
            displaySolution(solution);
        }
    }

    // Method to display a single solution
    private void displaySolution(List<Assignment> solution) {
        solution.forEach(System.out::println);
        System.out.println(); // Print an empty line between solutions
    }

    // Get the total number of solutions found
    public long getSolutionsCount() {
        return solutionsCount;
    }

    // Get all solutions
    public List<List<Assignment>> getAllSolutions() {
        return allSolutions;
    }

    
}
