package fr.univamu.solver;
import java.util.List;


public record Problem (List<Constraint> constraints, List<Variable> variables, int strategy ) {
}
