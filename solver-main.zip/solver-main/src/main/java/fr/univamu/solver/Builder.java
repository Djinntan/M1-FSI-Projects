package fr.univamu.solver;

import java.util.LinkedList;
import java.util.List;

public class Builder {
    private LinkedList<Variable> variables = new LinkedList<>();
    private LinkedList<Constraint> constraints = new LinkedList<>();  // renamed to 'constraints' for clarity

    public Problem getProblem() {
        return new Problem(constraints, variables, 0); // Create and return the problem
    }

    // Add a public getter method for constraints
    public List<Constraint> getConstraints() {
        return constraints;
    }

    public List<Variable> getVariables() {
        return variables;
    }
    
    private void add(Variable result, Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.ADD, result, a, b));
    }

    private void add(Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.ADD, a, a, b));
    }

    private void sub(Variable result, Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.SUB, result, a, b));
    }

    private void sub(Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.SUB, a, a, b));
    }

    private void mul(Variable result, Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.MUL, result, a, b));
    }

    private void mul(Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.MUL, a, a, b));
    }

    private void div(Variable result, Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.DIV, result, a, b));
    }

    private void div(Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.DIV, a, a, b));
    }

    public void diff(Variable a, Variable b) {
        constraints.add(new Constraint(ConstraintType.DIFF, a, b, null));  // Ensure null handling is supported in the Constraint class
    }

    public void allDiff(Variable... variables) {
        for (int i = 0; i < variables.length; i++) {
            for (int j = i + 1; j < variables.length; j++) {
                diff(variables[i], variables[j]);
            }
        }
    }

    private Variable parseSimpleTerm(LinkedList<Object> terms) {
        var first = terms.removeFirst();
        if (first instanceof Variable var) {
            return var;
        }
        if (first instanceof Integer cst) {
            return this.newConstant(cst);
        }
        throw new IllegalArgumentException("bad expression: " + first);
    }

    private boolean parseToken(String token, LinkedList<Object> terms) {
        if (!terms.isEmpty() && token.equals(terms.getFirst())) {
            terms.removeFirst();
            return true;
        }
        return false;
    }

    private Variable parseMultiplicationTerm(LinkedList<Object> terms) {
        var first = parseSimpleTerm(terms);
        if (parseToken("*", terms)) {
            var second = parseMultiplicationTerm(terms);
            if (second.isConstant()) {
                mul(first, second);
                return first;
            } else {
                var result = newVar();
                mul(result, first, second);
                return result;
            }
        }
        if (parseToken("/", terms)) {
            var second = parseMultiplicationTerm(terms);
            if (second.isConstant()){
                div(first, second);
            } else{
                var result = newVar();
                div(result, first, second);
                return result;
            }
        }
        return first;
    }

    private Variable parseAdditionTerm(LinkedList<Object> terms) {
        var first = parseMultiplicationTerm(terms);
        if (parseToken("+", terms)) {
            var second = parseAdditionTerm(terms);
            if (second.isConstant()) {
                add(first, second);
                return first;
            } else {
                var result = newVar();
                add(result, first, second);
                return result;
            }
        }

        if (parseToken("-", terms)) {
            var second = parseAdditionTerm(terms);
            if (second.isConstant()) {
                sub(first, second);
                return first;
            } else {
                var result = newVar();
                sub(result, first, second);
                return result;
            }
        }
        return first;
    }
    public void addConstraint(Object... terms) {
        var termsList = new LinkedList<>(List.of(terms));
        var var1 = parseAdditionTerm(termsList);
        var relation = termsList.removeFirst();
        var var2 = parseAdditionTerm(termsList);
    
        if (!termsList.isEmpty()) {
            throw new IllegalArgumentException("bad expression: " + termsList);
        }
    
        // If var2 is a constant, reduce the domain directly
        if (var2.isConstant()) {
            switch (relation.toString()) {
                case ">":
                    var1.domain(var2.getFixedValue() + 1, Variable.MAX_VALUE - 1);
                    return;
                case ">=":
                    var1.domain(var2.getFixedValue(), Variable.MAX_VALUE - 1);
                    return;
                case "<":
                    var1.domain(Variable.MIN_VALUE + 1, var2.getFixedValue() - 1);
                    return;
                case "<=":
                    var1.domain(Variable.MIN_VALUE + 1, var2.getFixedValue());
                    return;
                case "=":
                    var1.domain(var2.getFixedValue());
                    return;
            }
        }
    
        // Map the relation to the appropriate ConstraintType
        ConstraintType constraintType;
        switch (relation.toString()) {
            case ">": constraintType = ConstraintType.GT; break;
            case ">=": constraintType = ConstraintType.GTE; break;
            case "<": constraintType = ConstraintType.LT; break;
            case "<=": constraintType = ConstraintType.LTE; break;
            case "=": constraintType = ConstraintType.EQ; break;
            default: throw new IllegalArgumentException("Unknown relation: " + relation);
        }
    
        // Use null as the result for comparison constraints since there's no result variable
        constraints.add(new Constraint(constraintType, null, var1, var2));
    }
    

    public Variable expression2(Object... terms) {
        var termsList = new LinkedList<>(List.of(terms));
        var result = parseAdditionTerm(termsList);
        if (!termsList.isEmpty()) {
            throw new IllegalArgumentException("bad expression: " + termsList);
        }
        return result;
    }

    public Variable newVar() {
        var v = new Variable(variables.size());
        variables.add(v);
        return v;
    }

    public Variable newVar(String name) {
        var v = new Variable(name);
        variables.add(v);
        return v;
    }

    public Variable newConstant(int value) {
        Variable constant = new Variable(value);
        constant.domain(value);
        return constant;
    }

    public void eq(Variable a, Variable b) {
        sub(newConstant(0), a, b); // 0 = A - B
    }

    public void gt(Variable a, Variable b) {
        sub(newVar().domain(1, Variable.MAX_VALUE), a, b); // Z=A-B,Z>0
    }

    public void get(Variable a, Variable b) {
        sub(newVar().domain(0, Variable.MAX_VALUE), a, b); // Z=A-B, Z>=0
    }

    public void lt(Variable a, Variable b) {
        gt(b, a);
    }

    public void let(Variable a, Variable b) {
        get(b, a);
    }
}
