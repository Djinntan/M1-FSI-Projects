package fr.univamu.solver;

import java.util.List;

public class DefaultStrategy implements IStrategy {

    @Override
    public boolean before(Solver solver) {
        return true;
    }

    @Override
    public Variable findVariable(Solver solver) {
        // Default variable selection logic
        Variable best = null;
        for (Variable v : solver.getVariables()) {
            if (v.isFixed()) continue;
            if (best == null || v.getSize() < best.getSize()) {
                best = v;
            }
        }
        return best;
    }

    @Override
    public int step(Variable v) {
        return 1;
    }

    @Override
    public boolean check(Solver solver) {
        for (Constraint c : solver.getConstraints()) {
            if (!checkConstraint(c)) {
                return false;
            }
        }
        return true;
    }

    private boolean checkConstraint(Constraint c) {
        switch (c.type()) {
            case ADD:
                return checkAddConstraintIntervalsStrategy(c);
            case MUL:
                return checkMulConstraintIntervalsStrategy(c);
            case DIV:
                return checkDivConstraintIntervalsStrategy(c);
            case DIFF:
                return checkDiffConstraintIntervalsStrategy(c);
            default:
                throw new IllegalArgumentException("Unsupported constraint type: " + c.type());
        }
    }

    private boolean checkAddConstraintIntervalsStrategy(Constraint c) {
        return c.var1().add(c.var2()).inter(c.result()).isNotEmpty();
    }

    private boolean checkMulConstraintIntervalsStrategy(Constraint c) {
        return c.var1().mul(c.var2()).inter(c.result()).isNotEmpty();
    }

    private boolean checkDivConstraintIntervalsStrategy(Constraint c) {
        return c.var1().div(c.var2()).inter(c.result()).isNotEmpty();
    }

    private boolean checkDiffConstraintIntervalsStrategy(Constraint c) {
        var result = c.result();
        return !(result.equals(c.var1()) && result.isFixed());
    }

    @Override
    public Backup createBackup(List<Variable> variables) {
        return new Backup(variables);
    }

    @Override
    public void restoreBackup(Backup backup, List<Variable> variables) {
        backup.restore(variables);
    }
}
