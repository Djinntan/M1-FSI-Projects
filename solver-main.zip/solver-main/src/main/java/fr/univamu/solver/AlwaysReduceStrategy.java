package fr.univamu.solver;

import java.util.List;

public class AlwaysReduceStrategy implements IStrategy {

    private final Reducer reducer;
    private final Builder builder;

    
public AlwaysReduceStrategy(Builder builder) { // Pass the builder in the constructor
        this.reducer = new Reducer();
        this.builder = builder;  // Initialize the builder
    }

    @Override
    public boolean before(Solver solver) {
        builder.getProblem(); // You can call builder methods if needed
        solver.reduce();  // Perform an initial reduction before solving
        return true;
    }

    @Override
    public Variable findVariable(Solver solver) {
        return solver.getVariables().stream()
                .filter(v -> !v.isFixed())
                .findFirst()
                .orElse(null);
    }

    @Override
    public int step(Variable v) {
        return 1;  // Always reduce by step of 1
    }

    @Override
    public boolean check(Solver r) {
        return reducer.reduce(builder.getProblem());  // Reduce and check constraints
    }
    

    @Override
    public Backup createBackup(List<Variable> variables) {
        return new Backup(variables);
    }

    @Override
    public void restoreBackup(Backup backup, List<Variable> variables) {
        backup.restore(variables);
    }
}
