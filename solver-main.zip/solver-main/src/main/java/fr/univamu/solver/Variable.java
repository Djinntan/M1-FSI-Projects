package fr.univamu.solver;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Variable extends Interval {

    final private String name;
    final private boolean named;
    private List<Constraint> constraints = new ArrayList<>(); // List to store associated constraints
    private Consumer<Variable> domainObserver; // Observer for domain changes

    public Variable(int _number) {
        named = false;
        name = "_" + _number;
    }

    public Variable(String _name) {
        named = true;
        name = _name;
    }

    // Attach an observer that reacts to domain changes
    public void setDomainObserver(Consumer<Variable> observer) {
        this.domainObserver = observer;
    }

    // Trigger the domain observer when the domain is reduced
    @Override
    public boolean reduce(int newMin, int newMax) {
        boolean modified = super.reduce(newMin, newMax);
        if (modified && domainObserver != null) {
            domainObserver.accept(this); // Notify the observer if the domain is changed
        }
        return modified;
    }

    // Add a constraint associated with this variable
    public void addConstraint(Constraint constraint) {
        constraints.add(constraint);
    }

    // Get the list of constraints associated with this variable
    public List<Constraint> getConstraints() {
        return constraints;
    }

    public Variable domain(int min, int max) {
        reduce(min, max);
        return this;
    }

    public Variable domain(int value) {
        return domain(value, value);
    }

    public boolean isConstant() {
        return getMin() == getMax(); 
    }

    public int getFixedValue() {
        if (isFixed()) {
            return getMin();
        }
        throw new IllegalStateException("variable not fixed: " + this);
    }

    @Override
    public String toString() {
        return String.format("%s%s", this.name, super.toString());
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public String getName() {
        return name;
    }

    public boolean isNamed() {
        return named;
    }
}
