package fr.univamu.solver;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

public class Reducer {

    private final Set<Constraint> constraintsToReduce = new HashSet<>();

    public boolean reduce(Problem problem) {
        boolean modified = false;
        for (Constraint c : problem.constraints()) {
            if (reduceConstraint(c)) {
                modified = true;
            }
        }
        return modified;
    }

    public boolean reduceConstraint(Constraint c) {
        switch (c.type()) {
            case ADD:
                return reduceAddConstraint(c);
            case MUL:
                return reduceMulConstraint(c);
            case DIFF:
                return reduceDiffConstraint(c);  // Handle DIFF constraints properly
            default:
                throw new IllegalArgumentException("Unsupported constraint type: " + c.type());
        }
    }

    private boolean reduceAddConstraint(Constraint c) {
        boolean modified = c.result().reduce(c.var1().add(c.var2()));
        modified |= c.var1().reduce(c.result().sub(c.var2()));
        modified |= c.var2().reduce(c.result().sub(c.var1()));
        return modified;
    }

    private boolean reduceMulConstraint(Constraint c) {
        boolean modified = c.result().reduce(c.var1().mul(c.var2()));
        modified |= c.var1().reduce(c.result().div(c.var2()));
        modified |= c.var2().reduce(c.result().div(c.var1()));
        return modified;
    }

    private boolean reduceDiffConstraint(Constraint c) {
        boolean modified = false;
        Variable x = c.var1();
        Variable y = c.var2();

        if (x.isFixed() && y.isFixed() && x.getFixedValue() == y.getFixedValue()) {
            x.reduce(Interval.empty());
            y.reduce(Interval.empty());
            modified = true;
        }

        if (x.isFixed() && y.getMin() <= x.getFixedValue() && x.getFixedValue() <= y.getMax()) {
            y.reduce(x.getFixedValue() + 1, y.getMax());
            modified = true;
        }

        if (x.getMax() == y.getMin()) {
            x.reduce(x.getMin(), x.getMax() - 1);
            modified = true;
        }

        if (x.isFixed()) {
            x.reduce(x.getFixedValue(), x.getFixedValue());
        }

        // Adding observers and triggering them
        addObserver(x, c);
        addObserver(y, c);

        return modified;
    }

    private void addObserver(Variable variable, Constraint c) {
        Consumer<Variable> observer = (v) -> constraintsToReduce.add(c);
        variable.setDomainObserver(observer); 
    }

    public Set<Constraint> getConstraintsToReduce() {
        return constraintsToReduce;
    }
}
