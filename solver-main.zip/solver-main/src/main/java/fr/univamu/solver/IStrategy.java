package fr.univamu.solver;

import java.util.List;

public interface IStrategy {

    // Simplifies the problem before searching for solutions
    boolean before(Solver solver);

    // Chooses the next variable to instantiate
    Variable findVariable(Solver solver);

    // Determines the step size when exploring the domain of a variable
    int step(Variable v);

    // Checks constraints after exploring the domain
    boolean check(Solver solver);

    // New methods for backup and restoration
    Backup createBackup(List<Variable> variables);
    void restoreBackup(Backup backup, List<Variable> variables);
}
