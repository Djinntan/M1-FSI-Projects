package fr.univamu.solver;

public record Assignment(String variableName, int value) {

    @Override
    public String toString() {
        return String.format("%s = %d", variableName, value);
    }
}
