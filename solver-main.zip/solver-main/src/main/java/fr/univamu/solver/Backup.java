package fr.univamu.solver;

import java.util.List;

public class Backup {
    private final List<VariableSnapshot> snapshots;

    public Backup(List<Variable> variables) {
        this.snapshots = variables.stream()
                .map(VariableSnapshot::new)
                .toList();
    }

    public void restore(List<Variable> variables) {
        for (int i = 0; i < variables.size(); i++) {
            snapshots.get(i).restore(variables.get(i));
        }
    }

    private static class VariableSnapshot {
        private final int min;
        private final int max;

        public VariableSnapshot(Variable variable) {
            this.min = variable.getMin();
            this.max = variable.getMax();
        }

        public void restore(Variable variable) {
            variable.setMin(min);
            variable.setMax(max);
        }
    }
}
