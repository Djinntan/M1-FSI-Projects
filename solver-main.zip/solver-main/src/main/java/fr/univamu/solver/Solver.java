package fr.univamu.solver;

import java.util.ArrayList;
import java.util.List;

public class Solver {

    private IStrategy strategy;
    private List<Variable> variables;
    private List<Constraint> constraints;
    private long nodesCounter = 0;
    private long maxNodes = 1000_000_000L;

    // Default constructor with initialization of variables and constraints
    public Solver() {
        // Use a default strategy and a default builder
        this(new DefaultStrategy(), new Builder());
    }
    
    public Solver(IStrategy strategy) {
        // Use the provided strategy but still create a default builder
        this(strategy, new Builder());
    }
    
    // New constructor to accept both a strategy and a builder
    public Solver(IStrategy strategy, Builder builder) {
        this.strategy = strategy;  // Override strategy if provided
        this.variables = builder.getVariables();  // Use variables from the Builder
        this.constraints = builder.getConstraints();  // Use constraints from the Builder
    }
    

    // Set a new strategy
    public void setStrategy(IStrategy strategy) {
        this.strategy = strategy;
    }

    // Getter for node count
    public long getNodesCounter() {
        return nodesCounter;
    }

    // Solve method
    public Solutions solve(boolean displaySolutions) {
        Solutions solutions = new Solutions(displaySolutions);
        nodesCounter = 0;

        // Check before solving using the strategy
        if (!strategy.before(this)) {
            return solutions;
        }

        // Find all solutions
        findSolutions(solutions);
        return solutions;
    }

    // Recursive method to find solutions
    public boolean findSolutions(Solutions solutions) {
        // Check node limits
        if (++nodesCounter > maxNodes) {
            throw new IllegalStateException("too many nodes");
        }

        // Check constraints using the strategy
        if (!strategy.check(this)) {
            return false;
        }

        // Find next variable to solve for
        var v = strategy.findVariable(this);
        if (v == null) {
            // If no variables left, add the solution
            List<Assignment> solution = new ArrayList<>();
            for (Variable variable : variables) {
                if (variable.isNamed()) {
                    solution.add(new Assignment(variable.getName(), variable.getFixedValue()));
                }
            }
            solutions.addSolution(solution);  // Add solution to Solutions object
            return true;
        }

        // Create a backup before trying values for the variable
        Backup backup = strategy.createBackup(variables);

        boolean result = false;
        int min = v.getMin();
        int max = v.getMax();

        // Try all values within the variable's domain
        for (int value = min; value <= max; value += strategy.step(v)) {
            v.setMin(value);
            v.setMax(value);
            if (findSolutions(solutions)) {
                result = true;
            }
            // Restore the state of variables after each step
            strategy.restoreBackup(backup, variables);
        }

        return result;
    }

    // Getter for variables
    public List<Variable> getVariables() {
        return variables;
    }

    // Getter for constraints
    public List<Constraint> getConstraints() {
        return constraints;
    }

    // Reduction method (implementation in Reducer)
    public void reduce() {
        // Reduction logic, e.g., using the Reducer class
    }
}
