package fr.univamu.solver;

public enum ConstraintType {
    ADD,        // For '+'
    SUB,        // For '-'
    MUL,        // For '*'
    DIV,        // For '/'
    EQ,         // For '='
    GT,         // For '>'
    GTE,        // For '>='
    LT,         // For '<'
    LTE,        // For '<='
    DIFF        // For '<>'
}
