# Solver

## Membres du projet

- KASMI Badreddine
- BESBES Mohamed

## Description des emprunts

- TP1 réalisé sans emprunts de chatGPT
- TP2 et TP3 ont été réalisés avec emprunts de chatGPT 