package fr.univ_amu.m1info.client.util.model.groupe;

import fr.univ_amu.m1info.client.model.groupe.Groupe;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GroupeTest {

    @Test
    void testGroupe_CreationAndGetters() {
        Groupe groupe = new Groupe(1, "Groupe A");

        assertEquals(1, groupe.getId());
        assertEquals("Groupe A", groupe.getNom());
    }

    @Test
    void testToString_Format() {
        Groupe groupe = new Groupe(2, "Groupe B");

        String result = groupe.toString();

        assertEquals("Groupe B", result);
    }
}
