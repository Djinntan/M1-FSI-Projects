package fr.univ_amu.m1info.client.util.service.dao;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import fr.univ_amu.m1info.client.service.dao.EtudiantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EtudiantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EtudiantServiceDAOTest {

    private static final int PORT = 8080;
    private static WireMockServer wireMockServer;
    private EtudiantServiceDAO etudiantServiceDAO;

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final GroupeDTO mockGroupe = new GroupeDTO(1, "Groupe A");

    @BeforeAll
    static void setupServer() {
        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(PORT));
        wireMockServer.start();
        WireMock.configureFor("localhost", PORT);
    }

    @AfterAll
    static void stopServer() {
        wireMockServer.stop();
        wireMockServer.resetAll();
    }

    @BeforeEach
    void setUp() {
        etudiantServiceDAO = new EtudiantServiceDAO(httpClient);
        wireMockServer.resetAll();
    }

    @Test
    void testGetAllEtudiants_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Doe\",\"prenom\":\"John\",\"email\":\"john.doe@example.com\"}]")
                        .withHeader("Content-Type", "application/json")));

        List<EtudiantDTO> etudiants = etudiantServiceDAO.getAllEtudiants();

        assertNotNull(etudiants);
        assertFalse(etudiants.isEmpty());
        assertEquals(1, etudiants.size());
        assertEquals("Doe", etudiants.get(0).nom());

        verify(getRequestedFor(urlEqualTo("/etudiants")));
    }

    @Test
    void testGetAllEtudiants_EmptyList() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")
                        .withHeader("Content-Type", "application/json")));

        List<EtudiantDTO> etudiants = etudiantServiceDAO.getAllEtudiants();

        assertNotNull(etudiants);
        assertTrue(etudiants.isEmpty());

        verify(getRequestedFor(urlEqualTo("/etudiants")));
    }

    @Test
    void testDeleteEtudiant_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Doe\",\"prenom\":\"John\",\"email\":\"john.doe@example.com\"}]")));

        stubFor(delete(urlEqualTo("/etudiants/1"))
                .willReturn(aResponse()
                        .withStatus(204)));

        boolean deleted = etudiantServiceDAO.deleteEtudiant("john.doe@example.com");

        assertTrue(deleted, "Expected deletion to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/etudiants")));
        verify(deleteRequestedFor(urlEqualTo("/etudiants/1")));
    }

    @Test
    void testDeleteEtudiant_NotFound() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]"))); // Empty array

        boolean deleted = etudiantServiceDAO.deleteEtudiant("unknown@example.com");

        assertFalse(deleted);

        //verify(getRequestedFor(urlEqualTo("/etudiants")));
    }

    @Test
    void testCreateOrUpdateEtudiant_Success() throws IOException, InterruptedException {
        System.out.println("🔍 [DEBUG] Starting testCreateOrUpdateEtudiant_Success...");

        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));
        System.out.println("✅ [MOCK] GET /etudiants -> 200 OK, Body: []");

        stubFor(put(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)));
        System.out.println("✅ [MOCK] PUT /etudiants -> 200 OK");

        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);
        System.out.println("🔍 [DEBUG] Etudiant to create/update: " + etudiant);

        boolean result = etudiantServiceDAO.createOrUpdateEtudiant(etudiant);
        System.out.println("🔍 [DEBUG] createOrUpdateEtudiant() result: " + result);

        assertTrue(result, "❌ Expected update to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/etudiants")));
        verify(putRequestedFor(urlEqualTo("/etudiants")));

        System.out.println("✅ [SUCCESS] Test passed.");
    }

    @Test
    void testCreateOrUpdateEtudiant_Failure() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        stubFor(put(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(400)));

        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);

        boolean result = etudiantServiceDAO.createOrUpdateEtudiant(etudiant);

        assertFalse(result, "Expected update to fail but it succeeded!");

        verify(getRequestedFor(urlEqualTo("/etudiants")));
        verify(putRequestedFor(urlEqualTo("/etudiants")));
    }

    @Test
    void testUpdateEtudiant_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/etudiants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Doe\",\"prenom\":\"John\",\"email\":\"john.doe@example.com\"}]")));

        stubFor(put(urlEqualTo("/etudiants/1"))
                .willReturn(aResponse()
                        .withStatus(200)));

        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);

        boolean result = etudiantServiceDAO.updateEtudiant(etudiant);

        assertTrue(result, "Expected update to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/etudiants")));
        verify(putRequestedFor(urlEqualTo("/etudiants/1")));
    }
}
