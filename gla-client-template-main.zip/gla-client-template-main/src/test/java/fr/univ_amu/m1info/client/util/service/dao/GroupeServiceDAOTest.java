package fr.univ_amu.m1info.client.util.service.dao;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class GroupeServiceDAOTest {

    private static final int PORT = 8080; // ✅ WireMock runs on port 8080
    private static WireMockServer wireMockServer;
    private GroupeServiceDAO groupeServiceDAO;
    private final HttpClient httpClient = HttpClient.newHttpClient();

    @BeforeAll
    static void setupServer() {
        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(PORT));
        wireMockServer.start();
        WireMock.configureFor("localhost", PORT);
    }

    @AfterAll
    static void stopServer() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        groupeServiceDAO = new GroupeServiceDAO(httpClient);
        wireMockServer.resetAll();
    }

    @Test
    void testGetAllGroupes_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Groupe A\"}]")
                        .withHeader("Content-Type", "application/json")));

        List<GroupeDTO> groupes = groupeServiceDAO.getAllGroupes();

        assertNotNull(groupes);
        assertFalse(groupes.isEmpty());
        assertEquals(1, groupes.size());
        assertEquals("Groupe A", groupes.get(0).nom());

        verify(getRequestedFor(urlEqualTo("/groupes")));
    }

    @Test
    void testGetAllGroupes_EmptyList() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")
                        .withHeader("Content-Type", "application/json")));

        List<GroupeDTO> groupes = groupeServiceDAO.getAllGroupes();

        assertNotNull(groupes);
        assertTrue(groupes.isEmpty());

        verify(getRequestedFor(urlEqualTo("/groupes")));
    }

    @Test
    void testDeleteGroupe_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Groupe A\"}]")));

        stubFor(delete(urlEqualTo("/groupes/1"))
                .willReturn(aResponse()
                        .withStatus(204)));

        boolean deleted = groupeServiceDAO.deleteGroupe("Groupe A");

        assertTrue(deleted, "Expected deletion to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/groupes")));
        verify(deleteRequestedFor(urlEqualTo("/groupes/1")));
    }

    @Test
    void testDeleteGroupe_NotFound() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        boolean deleted = groupeServiceDAO.deleteGroupe("NonExistentGroup");

        assertFalse(deleted, "Expected deletion to fail but it succeeded!");

        verify(getRequestedFor(urlEqualTo("/groupes")));
    }

    @Test
    void testCreateOrUpdateGroupe_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        stubFor(put(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(201)));

        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");

        boolean result = groupeServiceDAO.createOrUpdateGroupe(groupe);

        assertTrue(result, "❌ Expected create/update to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/groupes")));
        verify(putRequestedFor(urlEqualTo("/groupes")));
    }

    @Test
    void testCreateOrUpdateGroupe_Failure() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        stubFor(put(urlEqualTo("/groupes"))
                .willReturn(aResponse()
                        .withStatus(400)));

        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");

        boolean result = groupeServiceDAO.createOrUpdateGroupe(groupe);

        assertFalse(result, "❌ Expected create/update to fail but it succeeded!");

        verify(getRequestedFor(urlEqualTo("/groupes")));
        verify(putRequestedFor(urlEqualTo("/groupes")));
    }
}
