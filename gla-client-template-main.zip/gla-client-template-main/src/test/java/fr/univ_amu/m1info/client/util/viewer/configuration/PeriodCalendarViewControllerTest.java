/*package fr.univ_amu.m1info.client.util.viewer.configuration;

import fr.univ_amu.m1info.client.model.Calendar;
import fr.univ_amu.m1info.client.util.day.DayGenerator;
import fr.univ_amu.m1info.client.viewer.configuration.CalendarViewConfiguration;
import fr.univ_amu.m1info.client.viewer.configuration.PeriodCalendarViewController;
import fr.univ_amu.m1info.client.viewer.controller.AdminManagementController;
import fr.univ_amu.m1info.client.viewer.manager.SlotManager;
import fr.univ_amu.m1info.client.viewer.presenter.CalendarPresenter;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import fr.univ_amu.m1info.client.util.timeInterval.TimeIntervalGenerator;
import fr.univ_amu.m1info.client.util.duration.DurationGenerator;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PeriodCalendarViewControllerTest {

    @Mock
    private TimeIntervalGenerator mockTimeIntervalGenerator;

    @Mock
    private DurationGenerator mockDurationGenerator;

    @Mock
    private Calendar mockCalendar;

    @Mock
    private CalendarViewConfiguration mockConfig;

    @Mock
    private Stage mockStage;

    @Mock
    private CalendarPresenter mockCalendarPresenter;

    @Mock
    private SlotManager mockSlotManager;

    @Mock
    private AdminManagementController mockAdminController;
    @Mock
    private Duration mockDuration;
    private PeriodCalendarViewController controller;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        when(mockConfig.getTimeIntervalGenerator()).thenReturn(mockTimeIntervalGenerator);
        when(mockTimeIntervalGenerator.getStartTimesOfIntervals()).thenReturn(List.of(LocalTime.of(8, 0), LocalTime.of(9, 0)));

        when(mockConfig.getPossibleDurations()).thenReturn(mockDurationGenerator);
        when(mockDurationGenerator.getDurations()).thenReturn(List.of(Duration.ofMinutes(30), Duration.ofMinutes(60)));

        when(mockConfig.getPeriodStartDateContaining(any())).thenReturn(LocalDate.of(2025, 2, 12));
        when(mockConfig.getPrintablePeriod()).thenReturn(java.time.Period.ofDays(7));
        when(mockConfig.getTotalPeriod()).thenReturn(java.time.Period.ofDays(7));

        controller = new PeriodCalendarViewController(mockCalendar, mockConfig, mockStage);

        ReflectionTestUtils.setField(controller, "slotManager", mockSlotManager);
        ReflectionTestUtils.setField(controller, "adminController", mockAdminController);
        ReflectionTestUtils.setField(controller, "calendarPresenter", mockCalendarPresenter);
    }


    @Test
    void testHandleNext() {
        controller.handleNext();

        verify(mockCalendarPresenter, times(1)).updateDays(any(DayGenerator.class));
        verify(mockSlotManager, times(1)).refreshSlots(any(LocalDate.class), any(LocalDate.class));
    }

    @Test
    void testHandlePrevious() {
        controller.handlePrevious();

        verify(mockCalendarPresenter, times(1)).updateDays(any(DayGenerator.class));
        verify(mockSlotManager, times(1)).refreshSlots(any(LocalDate.class), any(LocalDate.class));
    }

    @Test
    void testHandleSlotEdition() {
        controller.handleSlotEdition(5);

        verify(mockSlotManager, times(1)).handleSlotEdition(5);
    }

    @Test
    void testHandleSlotCreation() {
        controller.handleSlotCreation();

        verify(mockSlotManager, times(1)).handleSlotCreation();
    }

    @Test
    void testHandleAdminManagement() {
        controller.handleAdminManagement();

        verify(mockAdminController, times(1)).showAdminView(mockStage);
    }

    @Test
    void testGetScene() {
        Scene scene = controller.getScene();

        assertNotNull(scene);
        verify(mockCalendarPresenter, times(1)).updateDays(any(DayGenerator.class));
        verify(mockCalendarPresenter, times(1)).updateTimeIntervals(any());
        verify(mockSlotManager, times(1)).refreshSlots(any(LocalDate.class), any(LocalDate.class));
    }
}*/
