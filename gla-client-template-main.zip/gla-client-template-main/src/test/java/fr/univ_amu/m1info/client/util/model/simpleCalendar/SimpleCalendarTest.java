package fr.univ_amu.m1info.client.util.model.simpleCalendar;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.simpleCalendar.SimpleCalendar;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlot;
import fr.univ_amu.m1info.client.service.dao.CalendarServiceDAO;
import fr.univ_amu.m1info.client.service.dao.exceptions.ConnexionException;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.service.dto.DateTimeInterval;
import fr.univ_amu.m1info.client.service.dto.SlotDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SimpleCalendarTest {

    @Mock
    private CalendarServiceDAO mockCalendarDAO;

    @InjectMocks
    private SimpleCalendar simpleCalendar;

    private Slot sampleSlot;
    private SlotDTO sampleSlotDTO;

    @BeforeEach
    void setUp() {
        simpleCalendar = new SimpleCalendar(mockCalendarDAO);

        LocalDateTime start = LocalDateTime.of(2025, 2, 12, 10, 0);
        sampleSlot = new SimpleSlot("Math Class", start, Duration.ofHours(2), 1, 1, null, null, null);
        sampleSlotDTO = new SlotDTO(1, "Math Class", new DateTimeInterval(start, start.plusHours(2)), 1, null, null, null);
    }

    @Test
    void testGetAllSlotsBetween_Success() throws ConnexionException {
        LocalDate startDate = LocalDate.of(2025, 2, 10);
        LocalDate endDate = LocalDate.of(2025, 2, 15);
        when(mockCalendarDAO.getAllSlotsIn(startDate, endDate)).thenReturn(List.of(sampleSlotDTO));

        List<Slot> slots = (List<Slot>) simpleCalendar.getAllSlotsBetween(startDate, endDate);

        assertNotNull(slots);
        assertEquals(1, slots.size());
        assertEquals("Math Class", slots.get(0).description());

        verify(mockCalendarDAO, times(1)).getAllSlotsIn(startDate, endDate);
    }

    @Test
    void testGetAllSlotsBetween_CacheHit() throws ConnexionException {
        LocalDate startDate = LocalDate.of(2025, 2, 10);
        LocalDate endDate = LocalDate.of(2025, 2, 15);
        when(mockCalendarDAO.getAllSlotsIn(startDate, endDate)).thenReturn(List.of(sampleSlotDTO));

        simpleCalendar.getAllSlotsBetween(startDate, endDate);
        reset(mockCalendarDAO);

        List<Slot> cachedSlots = (List<Slot>) simpleCalendar.getAllSlotsBetween(startDate, endDate);

        assertNotNull(cachedSlots);
        assertEquals(1, cachedSlots.size());
        assertEquals("Math Class", cachedSlots.get(0).description());

        verify(mockCalendarDAO, times(0)).getAllSlotsIn(any(), any());
    }

    @Test
    void testCreate_Success() throws ConnexionException {
        when(mockCalendarDAO.create(sampleSlotDTO)).thenReturn(1);

        Slot createdSlot = simpleCalendar.create(sampleSlot);

        assertNotNull(createdSlot);
        assertEquals(1, createdSlot.id());

        verify(mockCalendarDAO, times(1)).create(sampleSlotDTO);
    }

    @Test
    void testCreate_Failure_ConnexionException() throws ConnexionException {
        when(mockCalendarDAO.create(sampleSlotDTO)).thenThrow(new ConnexionException());

        Slot result = simpleCalendar.create(sampleSlot);

        assertNull(result);

        verify(mockCalendarDAO, times(1)).create(sampleSlotDTO);
    }

    @Test
    void testUpdate_Success() throws WrongVersionException, UnknownElementException, ConnexionException {
        when(mockCalendarDAO.update(sampleSlotDTO)).thenReturn(1);

        Slot updatedSlot = simpleCalendar.update(sampleSlot);

        assertNotNull(updatedSlot);
        assertEquals(1, updatedSlot.id());

        verify(mockCalendarDAO, times(1)).update(sampleSlotDTO);
    }

    @Test
    void testUpdate_Failure_ConnexionException() throws WrongVersionException, UnknownElementException, ConnexionException {
        when(mockCalendarDAO.update(sampleSlotDTO)).thenThrow(new ConnexionException());

        Slot result = simpleCalendar.update(sampleSlot);

        assertNull(result);

        verify(mockCalendarDAO, times(1)).update(sampleSlotDTO);
    }

    @Test
    void testDelete_Success() throws WrongVersionException, UnknownElementException, ConnexionException {
        boolean result = simpleCalendar.delete(sampleSlot);

        assertTrue(result);

        verify(mockCalendarDAO, times(1)).delete(sampleSlotDTO);
    }

    @Test
    void testDelete_Failure_Exception() throws WrongVersionException, UnknownElementException, ConnexionException {
        doThrow(new UnknownElementException("Slot Not Found", 1)).when(mockCalendarDAO).delete(sampleSlotDTO);

        boolean result = simpleCalendar.delete(sampleSlot);

        assertFalse(result);

        verify(mockCalendarDAO, times(1)).delete(sampleSlotDTO);
    }

    /*@Test
    void testInvalidateCache() throws ConnexionException {
        LocalDate startDate = LocalDate.of(2025, 2, 10);
        LocalDate endDate = LocalDate.of(2025, 2, 15);
        when(mockCalendarDAO.getAllSlotsIn(startDate, endDate)).thenReturn(List.of(sampleSlotDTO));

        simpleCalendar.getAllSlotsBetween(startDate, endDate);
        assertFalse(simpleCalendar.getAllSlotsBetween(startDate, endDate).isEmpty());

        simpleCalendar.delete(sampleSlot);

        assertTrue(simpleCalendar.getAllSlotsBetween(startDate, endDate).isEmpty());
    }*/
}

