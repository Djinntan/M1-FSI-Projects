package fr.univ_amu.m1info.client.util.service.dao;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.service.dao.SimpleCalendarServiceDAO;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.service.dto.*;
import fr.univ_amu.m1info.client.util.timeInterval.TimeInterval;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SimpleCalendarDAOTest {

    private static final int PORT = 8080; // WireMock must match the DAO's base URL
    private static WireMockServer wireMockServer;
    private SimpleCalendarServiceDAO calendarServiceDAO;
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private static DateTimeInterval mockTimeInterval;
    private static SalleDTO mockSalle;
    private static EnseignantDTO mockEnseignant;
    private static GroupeDTO mockGroupe;


    @BeforeAll
    static void setupServer() {
        LocalDateTime start = LocalDateTime.of(2025, 2, 12, 10, 0);
        LocalDateTime end = LocalDateTime.of(2025, 2, 12, 12, 0);
        mockTimeInterval = new DateTimeInterval(start, end);
        mockEnseignant = new EnseignantDTO(1, "John", "Adams", "JohnAdams@Presidency.com");
        mockSalle = new SalleDTO(1,"Salle 1", "Batimen A","Campus Luminy",true,50, TypeSalle.AMPHITHEATRE);
        mockGroupe = new GroupeDTO(1, "Groupe 1");

        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(PORT));
        wireMockServer.start();
        WireMock.configureFor("localhost", PORT);
    }

    @AfterAll
    static void stopServer() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        calendarServiceDAO = new SimpleCalendarServiceDAO(httpClient);
        wireMockServer.resetAll();
    }

    @Test
    void testGetSlotById_Success() throws IOException, InterruptedException, UnknownElementException {
        stubFor(get(urlEqualTo("/timeslots/1"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("""
                        {
                            "id": 1,
                            "description": "Test Slot",
                            "timeInterval": {
                                "start": "2025-02-12T10:00:00",
                                "end": "2025-02-12T12:00:00"
                            }
                        }
                        """)
                        .withHeader("Content-Type", "application/json")));

        Optional<SlotDTO> slot = calendarServiceDAO.get(1);

        assertTrue(slot.isPresent(), "❌ Expected slot to be present but it was empty!");
        assertEquals(1, slot.get().id(), "❌ Expected slot ID 1 but got " + slot.get().id());

        verify(getRequestedFor(urlEqualTo("/timeslots/1")));
    }

    @Test
    void testGetSlotById_NotFound() {

        stubFor(get(urlEqualTo("/timeslots/99"))
                .willReturn(aResponse()
                        .withStatus(404)));


        try {
            calendarServiceDAO.get(99);
            fail("Expected UnknownElementException but no exception was thrown!");
        } catch (UnknownElementException e) {
            assertTrue(e.getMessage().contains("Slot with ID 99 not found"),
                    "Exception message was incorrect: " + e.getMessage());
        } catch (Exception e) {
            fail(" Unexpected exception thrown: " + e);
        }

        verify(getRequestedFor(urlEqualTo("/timeslots/99")));
    }



    @Test
    void testGetAllSlotsIn_Success() {
        stubFor(get(urlPathMatching("/calendar/request"))
                .withQueryParam("start", equalTo("2025-02-10"))
                .withQueryParam("end", equalTo("2025-02-15"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("""
                        {
                            "calendarSlots": [
                                {
                                    "id": 1,
                                    "description": "Test Slot",
                                    "timeInterval": {
                                        "start": "2025-02-12T10:00:00",
                                        "end": "2025-02-12T12:00:00"
                                    }
                                }
                            ]
                        }
                        """)
                        .withHeader("Content-Type", "application/json")));

        List<SlotDTO> slots = (List<SlotDTO>) calendarServiceDAO.getAllSlotsIn(LocalDate.of(2025, 2, 10), LocalDate.of(2025, 2, 15));

        assertNotNull(slots, "❌ Expected non-null list but got null!");
        assertFalse(slots.isEmpty(), "❌ Expected at least one slot but got an empty list!");
        assertEquals(1, slots.get(0).id(), "❌ Expected slot ID 1 but got " + slots.get(0).id());

        verify(getRequestedFor(urlPathMatching("/calendar/request"))
                .withQueryParam("start", equalTo("2025-02-10"))
                .withQueryParam("end", equalTo("2025-02-15")));
    }

    @Test
    void testCreateSlot_Success() throws IOException, InterruptedException {
        stubFor(post(urlEqualTo("/timeslots"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withBody("{\"id\":1}")
                        .withHeader("Content-Type", "application/json")));

        SlotDTO newSlot = new SlotDTO(1, "Test Slot", mockTimeInterval,1,mockSalle,mockEnseignant,mockGroupe);

        int createdId = calendarServiceDAO.create(newSlot);

        assertEquals(1, createdId);

        verify(postRequestedFor(urlEqualTo("/timeslots"))
                .withHeader("Content-Type", equalTo("application/json")));
    }

    @Test
    void testUpdateSlot_Success() throws IOException, InterruptedException, UnknownElementException, WrongVersionException {
        stubFor(put(urlEqualTo("/timeslots/1"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("{\"id\":1}")
                        .withHeader("Content-Type", "application/json")));

        SlotDTO slotToUpdate = new SlotDTO(1, "Test Slot", mockTimeInterval,1,mockSalle,mockEnseignant,mockGroupe);

        int updatedId = calendarServiceDAO.update(slotToUpdate);

        assertEquals(1, updatedId);

        verify(putRequestedFor(urlEqualTo("/timeslots/1"))
                .withHeader("Content-Type", equalTo("application/json")));
    }

    @Test
    void testDeleteSlot_Success() throws IOException, InterruptedException, UnknownElementException {
        stubFor(delete(urlEqualTo("/timeslots/1"))
                .willReturn(aResponse()
                        .withStatus(204))); // 204 No Content means successful deletion

        SlotDTO slotToDelete = new SlotDTO(1, "Test Slot", mockTimeInterval,1,mockSalle,mockEnseignant,mockGroupe);

        assertDoesNotThrow(() -> calendarServiceDAO.delete(slotToDelete));

        verify(deleteRequestedFor(urlEqualTo("/timeslots/1")));
    }
}
