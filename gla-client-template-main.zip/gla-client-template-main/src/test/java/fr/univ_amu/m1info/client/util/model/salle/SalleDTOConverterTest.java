package fr.univ_amu.m1info.client.util.model.salle;

import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.model.salle.SalleDTOConverter;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SalleDTOConverterTest {

    @Test
    void testFromDTO_ValidSalleDTO() {
        SalleDTO salleDTO = new SalleDTO(1, "Salle A", "B1", "Campus X", true, 50, TypeSalle.AMPHITHEATRE);

        Salle salle = SalleDTOConverter.fromDTO(salleDTO);

        assertNotNull(salle);
        assertEquals(1, salle.getId());
        assertEquals("Salle A", salle.getNom());
        assertEquals("B1", salle.getBatiment());
        assertEquals("Campus X", salle.getCampus());
        assertTrue(salle.hasVideoProjecteur());
        assertEquals(50, salle.getCapacite());
        assertEquals(TypeSalle.AMPHITHEATRE, salle.getTypeSalle());
    }

    @Test
    void testFromDTO_NullSalleDTO() {
        Salle result = SalleDTOConverter.fromDTO(null);

        assertNull(result);
    }

    @Test
    void testToSalleDTO_ValidSalle() {
        Salle salle = new Salle(2, "Salle B", "B2", "Campus Y", false, 30, TypeSalle.AMPHITHEATRE);

        SalleDTO salleDTO = SalleDTOConverter.toSalleDTO(salle);

        assertNotNull(salleDTO);
        assertEquals(2, salleDTO.id());
        assertEquals("Salle B", salleDTO.nom());
        assertEquals("B2", salleDTO.batiment());
        assertEquals("Campus Y", salleDTO.campus());
        assertFalse(salleDTO.videoProjecteur());
        assertEquals(30, salleDTO.capacite());
        assertEquals(TypeSalle.AMPHITHEATRE, salleDTO.typeSalle());
    }

    @Test
    void testToSalleDTO_NullSalle() {
        SalleDTO result = SalleDTOConverter.toSalleDTO(null);

        assertNull(result);
    }
}

