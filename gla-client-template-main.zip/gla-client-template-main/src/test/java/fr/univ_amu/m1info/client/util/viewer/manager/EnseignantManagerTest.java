package fr.univ_amu.m1info.client.util.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormResult;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.manager.EnseignantManager;
import javafx.scene.control.Dialog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EnseignantManagerTest {

    private EnseignantManager enseignantManager;

    @Mock
    private EnseignantServiceDAO enseignantServiceDAO;

    @Mock
    private EnseignantFormFactory enseignantFormFactory;

    @Mock
    private Dialog<EnseignantFormResult> mockDialog;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        enseignantManager = new EnseignantManager(enseignantServiceDAO, enseignantFormFactory);

        when(enseignantFormFactory.createEnseignantManagementDialog()).thenReturn(mockDialog);
    }

    @Test
    void testHandleManageEnseignants_Cancel() {
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EnseignantFormResult(FormAction.CANCEL, null)));

        enseignantManager.handleManageEnseignants();

        verify(enseignantServiceDAO, never()).deleteEnseignant(any());
        verify(enseignantServiceDAO, never()).createOrUpdateEnseignant(any());
    }

    @Test
    void testHandleManageEnseignants_Delete() {
        EnseignantFormContent content = new EnseignantFormContent(1, "John", "Doe", "john.doe@example.com");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EnseignantFormResult(FormAction.DELETE, content)));
        when(enseignantServiceDAO.deleteEnseignant("john.doe@example.com")).thenReturn(true);

        enseignantManager.handleManageEnseignants();

        verify(enseignantServiceDAO).deleteEnseignant("john.doe@example.com");
    }

    @Test
    void testHandleManageEnseignants_Confirm() {
        EnseignantFormContent content = new EnseignantFormContent(1, "Jane", "Doe", "jane.doe@example.com");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EnseignantFormResult(FormAction.CONFIRM, content)));
        when(enseignantServiceDAO.createOrUpdateEnseignant(any(EnseignantDTO.class))).thenReturn(true);

        enseignantManager.handleManageEnseignants();

        ArgumentCaptor<EnseignantDTO> captor = ArgumentCaptor.forClass(EnseignantDTO.class);
        verify(enseignantServiceDAO).createOrUpdateEnseignant(captor.capture());

        EnseignantDTO capturedEnseignant = captor.getValue();
        assertEquals("Jane", capturedEnseignant.nom());
        assertEquals("Doe", capturedEnseignant.prenom());
        assertEquals("jane.doe@example.com", capturedEnseignant.email());
    }

    @Test
    void testHandleManageEnseignants_Confirm_Failed() {
        EnseignantFormContent content = new EnseignantFormContent(1, "Jane", "Doe", "jane.doe@example.com");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EnseignantFormResult(FormAction.CONFIRM, content)));
        when(enseignantServiceDAO.createOrUpdateEnseignant(any(EnseignantDTO.class))).thenReturn(false);

        enseignantManager.handleManageEnseignants();

        verify(enseignantServiceDAO).createOrUpdateEnseignant(any(EnseignantDTO.class));
    }
}

