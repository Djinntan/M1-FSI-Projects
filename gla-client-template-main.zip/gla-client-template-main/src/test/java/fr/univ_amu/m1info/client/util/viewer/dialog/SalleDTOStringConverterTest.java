package fr.univ_amu.m1info.client.util.viewer.dialog;

import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.viewer.dialog.SalleDTOStringConverter;
import javafx.util.StringConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SalleDTOStringConverterTest {
    private SalleDTOStringConverter converter;
    private SalleDTO salle;

    @BeforeEach
    void setUp() {
        converter = new SalleDTOStringConverter();
        salle = new SalleDTO(1, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);
    }

    @Test
    void testToString() {
        assertEquals("Salle A - Batiment B - Campus X", converter.toString(salle));
        assertEquals("Aucune salle", converter.toString(null));
    }

    @Test
    void testFromString() {
        assertNull(converter.fromString("Salle A - Batiment B - Campus X"));
        assertNull(converter.fromString(null));
    }
}
