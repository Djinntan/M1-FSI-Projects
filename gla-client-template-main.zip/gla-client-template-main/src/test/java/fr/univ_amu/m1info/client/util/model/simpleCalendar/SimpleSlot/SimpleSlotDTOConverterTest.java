package fr.univ_amu.m1info.client.util.model.simpleCalendar.SimpleSlot;


import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlot;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlotDTOConverter;
import fr.univ_amu.m1info.client.service.dto.*;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.*;

class SimpleSlotDTOConverterTest {

    private final SimpleSlotDTOConverter converter = new SimpleSlotDTOConverter();

    @Test
    void testFromDTO_ValidSlotDTO() {
        LocalDateTime start = LocalDateTime.of(2025, 2, 12, 10, 0);
        LocalDateTime end = start.plusHours(2);
        DateTimeInterval interval = new DateTimeInterval(start, end);

        SalleDTO salleDTO = new SalleDTO(1, "Salle A", "B1", "Campus X", true, 50, TypeSalle.AMPHITHEATRE);
        EnseignantDTO enseignantDTO = new EnseignantDTO(2, "Dupont", "Jean", "jean.dupont@example.com");
        GroupeDTO groupeDTO = new GroupeDTO(3, "Groupe A");

        SlotDTO slotDTO = new SlotDTO(1, "Math Class", interval, 1, salleDTO, enseignantDTO, groupeDTO);

        Slot slot = converter.fromDTO(slotDTO);

        assertNotNull(slot);
        assertEquals(1, slot.id());
        assertEquals("Math Class", slot.description());
        assertEquals(start, slot.startDateTime());
        assertEquals(Duration.ofHours(2), slot.duration());

        assertNotNull(slot.salle());
        assertEquals(1, slot.salle().getId());
        assertEquals("Salle A", slot.salle().getNom());

        assertNotNull(slot.enseignant());
        assertEquals(2, slot.enseignant().getId());
        assertEquals("Dupont", slot.enseignant().getNom());

        assertNotNull(slot.groupe());
        assertEquals(3, slot.groupe().getId());
        assertEquals("Groupe A", slot.groupe().getNom());
    }
    @Test
    void testToDTO_NullValues() {
        LocalDateTime start = LocalDateTime.of(2025, 5, 20, 16, 0);
        Slot slot = new SimpleSlot("Chemistry Experiment", start, Duration.ofMinutes(45), 4, 3, null, null, null);

        SlotDTO slotDTO = converter.toDTO(slot);

        assertNotNull(slotDTO);
        assertEquals(4, slotDTO.id());
        assertEquals("Chemistry Experiment", slotDTO.description());
        assertEquals(start, slotDTO.timeInterval().start());
        assertEquals(start.plusMinutes(45), slotDTO.timeInterval().end());

        assertNull(slotDTO.salle());
        assertNull(slotDTO.enseignant());
        assertNull(slotDTO.groupe());
    }
}
