package fr.univ_amu.m1info.client.util.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormFactory;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormResult;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SimpleSalleFormFactory;
import fr.univ_amu.m1info.client.viewer.manager.SalleManager;
import javafx.scene.control.Dialog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SalleManagerTest {

    private SalleManager salleManager;

    @Mock
    private SalleServiceDAO salleServiceDAO;

    @Mock
    private SimpleSalleFormFactory salleFormFactory;

    @Mock
    private Dialog<SalleFormResult> mockDialog;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        salleManager = new SalleManager(salleServiceDAO, salleFormFactory);

        when(salleFormFactory.createSalleManagementDialog()).thenReturn(mockDialog);
    }

    @Test
    void testHandleManageSalles_Cancel() {
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SalleFormResult(FormAction.CANCEL, null)));

        salleManager.handleManageSalles();

        verify(salleServiceDAO, never()).deleteSalle(any(), any(), any());
        verify(salleServiceDAO, never()).createOrUpdateSalle(any());
    }

    @Test
    void testHandleManageSalles_Delete() {
        SalleFormContent content = new SalleFormContent(1,"Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SalleFormResult(FormAction.DELETE, content)));
        when(salleServiceDAO.deleteSalle("Salle A", "Batiment B", "Campus X")).thenReturn(true);

        salleManager.handleManageSalles();

        verify(salleServiceDAO).deleteSalle("Salle A", "Batiment B", "Campus X");
    }

    @Test
    void testHandleManageSalles_Confirm() {
        SalleFormContent content = new SalleFormContent(1,"Salle B", "Batiment C", "Campus Y", false, 80, TypeSalle.TD);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SalleFormResult(FormAction.CONFIRM, content)));
        when(salleServiceDAO.createOrUpdateSalle(any(SalleDTO.class))).thenReturn(true);

        salleManager.handleManageSalles();

        ArgumentCaptor<SalleDTO> captor = ArgumentCaptor.forClass(SalleDTO.class);
        verify(salleServiceDAO).createOrUpdateSalle(captor.capture());

        SalleDTO capturedSalle = captor.getValue();
        assertEquals("Salle B", capturedSalle.nom());
        assertEquals("Batiment C", capturedSalle.batiment());
        assertEquals("Campus Y", capturedSalle.campus());
        assertEquals(80, capturedSalle.capacite());
        assertEquals(TypeSalle.TD, capturedSalle.typeSalle());
    }

    @Test
    void testHandleManageSalles_Confirm_Failed() {
        SalleFormContent content = new SalleFormContent(1,"Salle C", "Batiment D", "Campus Z", true, 50, TypeSalle.TD);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SalleFormResult(FormAction.CONFIRM, content)));
        when(salleServiceDAO.createOrUpdateSalle(any(SalleDTO.class))).thenReturn(false);

        salleManager.handleManageSalles();

        verify(salleServiceDAO).createOrUpdateSalle(any(SalleDTO.class));
    }
}

