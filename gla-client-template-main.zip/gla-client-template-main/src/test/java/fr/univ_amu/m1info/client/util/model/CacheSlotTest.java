package fr.univ_amu.m1info.client.util.model;

import fr.univ_amu.m1info.client.model.CacheSlot;
import fr.univ_amu.m1info.client.service.dto.DateTimeInterval;
import fr.univ_amu.m1info.client.service.dto.SlotDTO;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CacheSlotTest {

    @Test
    void testCacheSlot_StoresSlotsCorrectly() {
        LocalDateTime start = LocalDateTime.of(2025, 2, 12, 10, 0);
        LocalDateTime end = start.plusHours(2);
        DateTimeInterval interval = new DateTimeInterval(start, end);
        SlotDTO slot1 = new SlotDTO(1, "Math Class", interval, 1, null, null, null);
        SlotDTO slot2 = new SlotDTO(2, "Physics Lab", interval, 2, null, null, null);
        CacheSlot cacheSlot = new CacheSlot(List.of(slot1, slot2), 10);

        List<SlotDTO> cachedSlots = (List<SlotDTO>) cacheSlot.getSlots();

        assertNotNull(cachedSlots);
        assertEquals(2, cachedSlots.size());
        assertEquals("Math Class", cachedSlots.get(0).description());
        assertEquals("Physics Lab", cachedSlots.get(1).description());
    }

    @Test
    void testCacheSlot_IsNotExpiredImmediately() {
        CacheSlot cacheSlot = new CacheSlot(List.of(), 10); // Cache for 10 minutes

        assertFalse(cacheSlot.isExpired(), "❌ Cache should NOT be expired immediately");
    }

    @Test
    void testCacheSlot_ExpiresAfterDuration() {
        CacheSlot cacheSlot = new CacheSlot(List.of(), -1); // Expired 1 minute ago

        assertTrue(cacheSlot.isExpired(), "❌ Cache should be expired after the set duration");
    }
}

