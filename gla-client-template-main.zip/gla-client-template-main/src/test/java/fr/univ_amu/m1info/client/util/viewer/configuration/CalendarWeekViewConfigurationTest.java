/*package fr.univ_amu.m1info.client.util.viewer.configuration;


import fr.univ_amu.m1info.client.util.duration.DurationGenerator;
import fr.univ_amu.m1info.client.util.timeInterval.TimeIntervalGenerator;
import fr.univ_amu.m1info.client.viewer.configuration.CalendarWeekViewConfiguration;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CalendarWeekViewConfigurationTest {

    private CalendarWeekViewConfiguration config;

    @Mock
    private TimeIntervalGenerator mockTimeIntervalGenerator;

    @Mock
    private DurationGenerator mockDurationGenerator;

    private final LocalTime startTime = LocalTime.of(8, 0);
    private final LocalTime endTime = LocalTime.of(18, 0);
    private final Duration timeUnit = Duration.ofMinutes(30);
    private final Duration maxDuration = Duration.ofHours(2);
    private final Duration defaultDuration = Duration.ofMinutes(60);
    private final Color slotColor = Color.BLUE;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        when(mockTimeIntervalGenerator.getStartTimesOfIntervals()).thenReturn(List.of(startTime, startTime.plus(timeUnit)));
        when(mockDurationGenerator.getDurations()).thenReturn(List.of(timeUnit, maxDuration));

        config = new CalendarWeekViewConfiguration(startTime, endTime, timeUnit, maxDuration, defaultDuration, slotColor);
    }

    @Test
    void testGetTotalPeriod() {
        assertEquals(Period.ofDays(7), config.getTotalPeriod());
    }

    @Test
    void testGetPrintablePeriod() {
        assertEquals(Period.ofDays(5), config.getPrintablePeriod());
    }

    @Test
    void testGetTimeIntervalGenerator() {
        assertNotNull(config.getTimeIntervalGenerator());
    }

    @Test
    void testGetPossibleDurations() {
        assertNotNull(config.getPossibleDurations());
    }

    @Test
    void testGetPeriodStartDateContaining() {
        LocalDate date = LocalDate.of(2025, 2, 12);
        LocalDate expectedStartDate = date.minusDays(date.getDayOfWeek().getValue() - 1);
        assertEquals(expectedStartDate, config.getPeriodStartDateContaining(date));
    }

    @Test
    void testGetDefaultDurationIndex() {
        assertEquals(1, config.getDefaultDurationIndex());
    }

    @Test
    void testColorOfSlots() {
        assertEquals(slotColor, config.colorOfSlots());
    }
}*/
