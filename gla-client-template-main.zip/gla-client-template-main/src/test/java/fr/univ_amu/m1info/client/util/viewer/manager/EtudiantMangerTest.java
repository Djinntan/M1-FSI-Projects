package fr.univ_amu.m1info.client.util.viewer.manager;

import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.service.dao.EtudiantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EtudiantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormResult;
import fr.univ_amu.m1info.client.viewer.manager.EtudiantManager;
import javafx.scene.control.Dialog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EtudiantManagerTest {

    private EtudiantManager etudiantManager;

    @Mock
    private EtudiantServiceDAO etudiantServiceDAO;

    @Mock
    private EtudiantFormFactory etudiantFormFactory;

    @Mock
    private Dialog<EtudiantFormResult> mockDialog;

    @Mock
    private GroupeDTO mockGroupe;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        etudiantManager = new EtudiantManager(etudiantServiceDAO, etudiantFormFactory);

        when(etudiantFormFactory.createEtudiantManagementDialog()).thenReturn(mockDialog);
    }

    @Test
    void testHandleManageEtudiants_Cancel() {
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EtudiantFormResult(FormAction.CANCEL, null)));

        etudiantManager.handleManageEtudiants();

        verify(etudiantServiceDAO, never()).deleteEtudiant(any());
        verify(etudiantServiceDAO, never()).createOrUpdateEtudiant(any());
    }

    @Test
    void testHandleManageEtudiants_Delete() {
        EtudiantFormContent content = new EtudiantFormContent(1, "John", "Doe", "john.doe@example.com", mockGroupe);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EtudiantFormResult(FormAction.DELETE, content)));
        when(etudiantServiceDAO.deleteEtudiant("john.doe@example.com")).thenReturn(true);

        etudiantManager.handleManageEtudiants();

        verify(etudiantServiceDAO).deleteEtudiant("john.doe@example.com");
    }

    @Test
    void testHandleManageEtudiants_Confirm() {
        EtudiantFormContent content = new EtudiantFormContent(1, "Jane", "Doe", "jane.doe@example.com", mockGroupe);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EtudiantFormResult(FormAction.CONFIRM, content)));
        when(etudiantServiceDAO.createOrUpdateEtudiant(any(EtudiantDTO.class))).thenReturn(true);

        etudiantManager.handleManageEtudiants();

        ArgumentCaptor<EtudiantDTO> captor = ArgumentCaptor.forClass(EtudiantDTO.class);
        verify(etudiantServiceDAO).createOrUpdateEtudiant(captor.capture());

        EtudiantDTO capturedEtudiant = captor.getValue();
        assertEquals("Jane", capturedEtudiant.nom());
        assertEquals("Doe", capturedEtudiant.prenom());
        assertEquals("jane.doe@example.com", capturedEtudiant.email());
        assertEquals(mockGroupe, capturedEtudiant.groupe());
    }

    @Test
    void testHandleManageEtudiants_Confirm_Failed() {
        EtudiantFormContent content = new EtudiantFormContent(1, "Jane", "Doe", "jane.doe@example.com", mockGroupe);
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new EtudiantFormResult(FormAction.CONFIRM, content)));
        when(etudiantServiceDAO.createOrUpdateEtudiant(any(EtudiantDTO.class))).thenReturn(false);

        etudiantManager.handleManageEtudiants();

        verify(etudiantServiceDAO).createOrUpdateEtudiant(any(EtudiantDTO.class));
    }
}

