package fr.univ_amu.m1info.client.util.viewer.dialog;

import fr.univ_amu.m1info.client.viewer.dialog.DurationStringConverter;
import javafx.util.StringConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

class DurationStringConverterTest {
    private DurationStringConverter converter;

    @BeforeEach
    void setUp() {
        converter = new DurationStringConverter();
    }

    @Test
    void testToString() {
        assertEquals("1h", converter.toString(Duration.ofHours(1)));
        assertEquals("30m", converter.toString(Duration.ofMinutes(30)));
        assertEquals("", converter.toString(null));
    }

    @Test
    void testFromString() {
        assertEquals(Duration.ofHours(1), converter.fromString("1h"));
        assertEquals(Duration.ofMinutes(30), converter.fromString("30m"));
    }
}

