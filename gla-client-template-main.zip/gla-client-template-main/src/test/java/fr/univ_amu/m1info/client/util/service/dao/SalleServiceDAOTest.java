package fr.univ_amu.m1info.client.util.service.dao;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.List;
import java.util.Optional;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SalleServiceDAOTest {

    private static final int PORT = 8080;
    private static WireMockServer wireMockServer;
    private SalleServiceDAO salleServiceDAO;
    private final HttpClient httpClient = HttpClient.newHttpClient();

    @BeforeAll
    static void setupServer() {
        wireMockServer = new WireMockServer(WireMockConfiguration.wireMockConfig().port(PORT));
        wireMockServer.start();
        WireMock.configureFor("localhost", PORT);
    }

    @AfterAll
    static void stopServer() {
        wireMockServer.stop();
    }

    @BeforeEach
    void setUp() {
        salleServiceDAO = new SalleServiceDAO(httpClient);
        wireMockServer.resetAll();
    }


    /**
     * ✅ Tests retrieving all salles
     */
    @Test
    void testGetAllSalles_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/salles"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Salle A\",\"batiment\":\"B1\",\"campus\":\"Campus X\"}]")
                        .withHeader("Content-Type", "application/json")));

        List<SalleDTO> salles = salleServiceDAO.getAllSalles();

        assertNotNull(salles);
        assertFalse(salles.isEmpty());
        assertEquals(1, salles.size());
        assertEquals("Salle A", salles.get(0).nom());

        verify(getRequestedFor(urlEqualTo("/salles")));
    }

    /**
     * ✅ Tests retrieving a salle by ID
     */
    @Test
    void testGetSalleById_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/salles/1"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("{\"id\":1,\"nom\":\"Salle A\",\"batiment\":\"B1\",\"campus\":\"Campus X\"}")
                        .withHeader("Content-Type", "application/json")));

        Optional<SalleDTO> salle = salleServiceDAO.getSalleById(1);

        assertTrue(salle.isPresent());
        assertEquals("Salle A", salle.get().nom());

        verify(getRequestedFor(urlEqualTo("/salles/1")));
    }

    /**
     * ✅ Tests deleting a salle
     */
    @Test
    void testDeleteSalle_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/salles"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Salle A\",\"batiment\":\"B1\",\"campus\":\"Campus X\"}]")));

        stubFor(delete(urlEqualTo("/salles/1"))
                .willReturn(aResponse()
                        .withStatus(204)));

        boolean deleted = salleServiceDAO.deleteSalle("Salle A", "B1", "Campus X");

        assertTrue(deleted, "Expected deletion to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/salles")));
        verify(deleteRequestedFor(urlEqualTo("/salles/1")));
    }

    /**
     * ✅ Tests creating a salle
     */
    @Test
    void testCreateSalle_Success() throws IOException, InterruptedException {
        // ✅ Mock POST response
        stubFor(post(urlEqualTo("/salles"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withBody("{\"id\":1,\"nom\":\"Salle A\",\"batiment\":\"B1\",\"campus\":\"Campus Luminy\"}")
                        .withHeader("Content-Type", "application/json")));

        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus Luminy", true, 50, TypeSalle.AMPHITHEATRE);

        SalleDTO createdSalle = salleServiceDAO.createSalle(salle);

        assertNotNull(createdSalle);
        assertEquals("Salle A", createdSalle.nom());

        verify(postRequestedFor(urlEqualTo("/salles")));
    }

    /**
     * ✅ Tests updating a salle
     */
    @Test
    void testUpdateSalle_Success() throws IOException, InterruptedException {
        stubFor(put(urlEqualTo("/salles/1"))
                .willReturn(aResponse()
                        .withStatus(200)));

        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus Luminy", true, 50, TypeSalle.AMPHITHEATRE);

        boolean updated = salleServiceDAO.updateSalle(salle);

        assertTrue(updated, "Expected update to succeed but it failed!");

        verify(putRequestedFor(urlEqualTo("/salles/1")));
    }

    /**
     * ✅ Tests createOrUpdateSalle (PUT request)
     */
    @Test
    void testCreateOrUpdateSalle_Success() throws IOException, InterruptedException {

        //stubFor(get(urlEqualTo("/salles"))
                //.willReturn(aResponse()
                        //.withStatus(200)
                        //.withBody("[]") // Empty list, meaning salle doesn't exist
                        //.withHeader("Content-Type", "application/json")));

        stubFor(put(urlEqualTo("/salles"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus Luminy", true, 50, TypeSalle.AMPHITHEATRE);

        boolean result = salleServiceDAO.createOrUpdateSalle(salle);

        assertTrue(result, "❌ Expected createOrUpdate to succeed but it failed!");

        //verify(getRequestedFor(urlEqualTo("/salles")));

        verify(putRequestedFor(urlEqualTo("/salles"))
                .withHeader("Content-Type", equalTo("application/json")));

    }


}
