package fr.univ_amu.m1info.client.util.service.dao;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import org.junit.jupiter.api.*;
import java.io.IOException;
import java.net.http.HttpClient;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EnseignantServiceDAOTest {

    private WireMockServer wireMockServer;
    private EnseignantServiceDAO enseignantServiceDAO;

    @BeforeAll
    void setupWireMock() {
        wireMockServer = new WireMockServer(8080);
        wireMockServer.start();
        WireMock.configureFor("localhost", 8080);

        enseignantServiceDAO = new EnseignantServiceDAO(HttpClient.newHttpClient());
    }

    @AfterAll
    void stopWireMock() {
        wireMockServer.stop();
        wireMockServer.resetAll();
    }

    @BeforeEach
    void resetWireMock() {
        wireMockServer.resetAll();
    }

    @Test
    void testGetAllEnseignants_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("[{\"id\":1,\"nom\":\"Dupont\",\"prenom\":\"Jean\",\"email\":\"jean.dupont@example.com\"}]")));

        List<EnseignantDTO> enseignants = enseignantServiceDAO.getAllEnseignants();

        assertNotNull(enseignants);
        assertFalse(enseignants.isEmpty());
        assertEquals(1, enseignants.size());
        assertEquals("Dupont", enseignants.get(0).nom());

        verify(getRequestedFor(urlEqualTo("/enseignants")));
    }

    @Test
    void testGetAllEnseignants_EmptyList() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        List<EnseignantDTO> enseignants = enseignantServiceDAO.getAllEnseignants();

        assertNotNull(enseignants);
        assertTrue(enseignants.isEmpty());

        verify(getRequestedFor(urlEqualTo("/enseignants")));
    }

    @Test
    void testGetAllEnseignants_ApiFailure() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(500)));

        List<EnseignantDTO> enseignants = enseignantServiceDAO.getAllEnseignants();

        assertNotNull(enseignants);
        assertTrue(enseignants.isEmpty(), "❌ Expected empty list on API failure!");

        verify(getRequestedFor(urlEqualTo("/enseignants")));
    }


    @Test
    void testDeleteEnseignant_Success() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Dupont\",\"prenom\":\"Jean\",\"email\":\"jean.dupont@example.com\"}]")));

        stubFor(delete(urlEqualTo("/enseignants/1"))
                .willReturn(aResponse()
                        .withStatus(204)));

        boolean deleted = enseignantServiceDAO.deleteEnseignant("jean.dupont@example.com");

        assertTrue(deleted, "Expected deletion to succeed but it failed!");

        verify(getRequestedFor(urlEqualTo("/enseignants")));
        verify(deleteRequestedFor(urlEqualTo("/enseignants/1")));
    }

    @Test
    void testDeleteEnseignant_NotFound() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[]")));

        boolean deleted = enseignantServiceDAO.deleteEnseignant("unknown@example.com");

        assertFalse(deleted);

        verify(getRequestedFor(urlEqualTo("/enseignants")));
        verify(0, deleteRequestedFor(anyUrl()));  // Ensure DELETE was not attempted
    }
    @Test
    void testDeleteEnseignant_ApiFailure() throws IOException, InterruptedException {
        stubFor(get(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("[{\"id\":1,\"nom\":\"Dupont\",\"prenom\":\"Jean\",\"email\":\"jean.dupont@example.com\"}]")));

        stubFor(delete(urlEqualTo("/enseignants/1"))
                .willReturn(aResponse()
                        .withStatus(500)));

        boolean deleted = enseignantServiceDAO.deleteEnseignant("jean.dupont@example.com");

        assertFalse(deleted, "❌ Expected deletion to fail but it succeeded!");

        verify(getRequestedFor(urlEqualTo("/enseignants")));

        verify(deleteRequestedFor(urlEqualTo("/enseignants/1")));
    }


    @Test
    void testCreateOrUpdateEnseignant_Success() throws IOException, InterruptedException {
        EnseignantDTO enseignant = new EnseignantDTO(1, "Dupont", "Jean", "jean.dupont@example.com");

        stubFor(put(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));

        boolean result = enseignantServiceDAO.createOrUpdateEnseignant(enseignant);

        assertTrue(result);

        verify(putRequestedFor(urlEqualTo("/enseignants"))
                .withHeader("Content-Type", equalTo("application/json"))
                .withRequestBody(containing("\"nom\":\"Dupont\"")));  // Ensure correct data is sent
    }

    @Test
    void testCreateOrUpdateEnseignant_Failure() throws IOException, InterruptedException {
        stubFor(put(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(400)));

        EnseignantDTO enseignant = new EnseignantDTO(1, "Dupont", "Jean", "jean.dupont@example.com");

        boolean result = enseignantServiceDAO.createOrUpdateEnseignant(enseignant);

        assertFalse(result);

        verify(putRequestedFor(urlEqualTo("/enseignants")));
    }
    @Test
    void testCreateOrUpdateEnseignant_AlreadyExists() throws IOException, InterruptedException {
        System.out.println("🔍 [DEBUG] Starting testCreateOrUpdateEnseignant_AlreadyExists...");

        //stubFor(get(urlEqualTo("/enseignants"))
                //.willReturn(aResponse()
                        //.withStatus(200)
                        //.withBody("[{\"id\":1,\"nom\":\"Dupont\",\"prenom\":\"Jean\",\"email\":\"jean.dupont@example.com\"}]")
                        //.withHeader("Content-Type", "application/json")));

        System.out.println("✅ DEBYUG [MOCK] GET /enseignants -> 200 OK");

        stubFor(put(urlEqualTo("/enseignants"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));

        System.out.println("✅ DEBYUG [MOCK] PUT /enseignants/1 -> 200 OK");

        EnseignantDTO enseignant = new EnseignantDTO(1, "Dupont", "Jean", "jean.dupont@example.com");

        System.out.println("🔍 [DEBYUG] Calling createOrUpdateEnseignant...");
        boolean result = enseignantServiceDAO.createOrUpdateEnseignant(enseignant);

        wireMockServer.getAllServeEvents().forEach(event -> {
        });

        assertTrue(result, "❌ Expected createOrUpdateEnseignant to return true, but got false!");


        verify(putRequestedFor(urlEqualTo("/enseignants")));

    }

}
