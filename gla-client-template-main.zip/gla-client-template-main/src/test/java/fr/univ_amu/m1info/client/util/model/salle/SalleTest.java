package fr.univ_amu.m1info.client.util.model.salle;

import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SalleTest {

    @Test
    void testSalle_CreationAndGetters() {
        // ✅ Arrange
        Salle salle = new Salle(1, "Salle A", "B1", "Campus X", true, 50, TypeSalle.AMPHITHEATRE);

        // ✅ Act & Assert
        assertEquals(1, salle.getId());
        assertEquals("Salle A", salle.getNom());
        assertEquals("B1", salle.getBatiment());
        assertEquals("Campus X", salle.getCampus());
        assertTrue(salle.hasVideoProjecteur());
        assertEquals(50, salle.getCapacite());
        assertEquals(TypeSalle.AMPHITHEATRE, salle.getTypeSalle());
    }

    @Test
    void testSalle_Setters() {
        Salle salle = new Salle(2, "Salle B", "B2", "Campus Y", false, 30, TypeSalle.AMPHITHEATRE);
        salle.setId(3);
        salle.setNom("Salle C");
        salle.setBatiment("B3");
        salle.setCampus("Campus Z");
        salle.setVideoProjecteur(true);
        salle.setCapacite(100);
        salle.setTypeSalle(TypeSalle.AMPHITHEATRE);

        assertEquals(3, salle.getId());
        assertEquals("Salle C", salle.getNom());
        assertEquals("B3", salle.getBatiment());
        assertEquals("Campus Z", salle.getCampus());
        assertTrue(salle.hasVideoProjecteur());
        assertEquals(100, salle.getCapacite());
        assertEquals(TypeSalle.AMPHITHEATRE, salle.getTypeSalle());
    }
}
