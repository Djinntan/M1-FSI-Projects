package fr.univ_amu.m1info.client.util.viewer.controller;

import fr.univ_amu.m1info.client.viewer.controller.AdminManagementController;
import fr.univ_amu.m1info.client.viewer.controller.AdminView;
import fr.univ_amu.m1info.client.viewer.manager.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdminManagementControllerTest {

    @Mock
    private SalleManager mockSalleManager;

    @Mock
    private EnseignantManager mockEnseignantManager;

    @Mock
    private EtudiantManager mockEtudiantManager;

    @Mock
    private GroupeManager mockGroupeManager;

    @InjectMocks
    private AdminManagementController adminController;

    @BeforeAll
    static void initJavaFX() {
        System.out.println("🔍 [DEBUG] Initializing JavaFX toolkit...");
        javafx.application.Platform.startup(() -> {});
    }

    @BeforeEach
    void setUp() {
        adminController = new AdminManagementController(mockSalleManager, mockEnseignantManager, mockEtudiantManager, mockGroupeManager);
    }


    @Test
    void testManageSalles_CallsSalleManager() {
        mockSalleManager.handleManageSalles();

        verify(mockSalleManager).handleManageSalles();
    }

    @Test
    void testManageEnseignants_CallsEnseignantManager() {
        mockEnseignantManager.handleManageEnseignants();

        verify(mockEnseignantManager).handleManageEnseignants();
    }

    @Test
    void testManageEtudiants_CallsEtudiantManager() {
        mockEtudiantManager.handleManageEtudiants();

        verify(mockEtudiantManager).handleManageEtudiants();
    }

    @Test
    void testManageGroupes_CallsGroupeManager() {
        mockGroupeManager.handleManageGroupes();

        verify(mockGroupeManager).handleManageGroupes();
    }
}
