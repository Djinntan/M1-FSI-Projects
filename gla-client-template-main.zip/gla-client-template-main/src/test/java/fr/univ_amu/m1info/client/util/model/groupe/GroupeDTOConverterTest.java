package fr.univ_amu.m1info.client.util.model.groupe;

import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.groupe.GroupeDTOConverter;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GroupeDTOConverterTest {

    @Test
    void testFromDTO_ValidGroupeDTO() {
        GroupeDTO groupeDTO = new GroupeDTO(1, "Groupe A");

        Groupe groupe = GroupeDTOConverter.fromDTO(groupeDTO);

        assertNotNull(groupe);
        assertEquals(1, groupe.getId());
        assertEquals("Groupe A", groupe.getNom());
    }

    @Test
    void testFromDTO_NullGroupeDTO() {
        Groupe result = GroupeDTOConverter.fromDTO(null);

        assertNull(result);
    }

    @Test
    void testToGroupeDTO_ValidGroupe() {
        Groupe groupe = new Groupe(2, "Groupe B");

        GroupeDTO groupeDTO = GroupeDTOConverter.toGroupeDTO(groupe);

        assertNotNull(groupeDTO);
        assertEquals(2, groupeDTO.id());
        assertEquals("Groupe B", groupeDTO.nom());
    }

    @Test
    void testToGroupeDTO_NullGroupe() {
        GroupeDTO result = GroupeDTOConverter.toGroupeDTO(null);

        assertNull(result);
    }
}

