package fr.univ_amu.m1info.client.util.viewer.dialog;

import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.viewer.dialog.EnseignantDTOStringConverter;
import javafx.util.StringConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnseignantDTOStringConverterTest {
    private EnseignantDTOStringConverter converter;

    @BeforeEach
    void setUp() {
        converter = new EnseignantDTOStringConverter();
    }

    @Test
    void testToStringWithValidEnseignant() {
        EnseignantDTO enseignant = new EnseignantDTO(1, "Doe", "John", "john.doe@example.com");
        assertEquals("Doe John", converter.toString(enseignant));
    }

    @Test
    void testToStringWithNullEnseignant() {
        assertEquals("Aucun enseignant", converter.toString(null));
    }

    @Test
    void testFromStringAlwaysReturnsNull() {
        assertNull(converter.fromString("Doe John"));
        assertNull(converter.fromString(""));
    }
}

