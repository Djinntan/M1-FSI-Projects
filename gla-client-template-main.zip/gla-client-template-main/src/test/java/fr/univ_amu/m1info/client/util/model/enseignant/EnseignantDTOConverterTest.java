package fr.univ_amu.m1info.client.util.model.enseignant;

import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.enseignant.EnseignantDTOConverter;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EnseignantDTOConverterTest {

    @Test
    void testFromDTO_ValidDTO() {
        EnseignantDTO dto = new EnseignantDTO(1, "Dupont", "Jean", "jean.dupont@example.com");

        Enseignant enseignant = EnseignantDTOConverter.fromDTO(dto);

        assertNotNull(enseignant, "❌ Conversion result should not be null!");
        assertEquals(1, enseignant.getId(), "❌ ID mismatch!");
        assertEquals("Dupont", enseignant.getNom(), "❌ Nom mismatch!");
        assertEquals("Jean", enseignant.getPrenom(), "❌ Prénom mismatch!");
        assertEquals("jean.dupont@example.com", enseignant.getEmail(), "❌ Email mismatch!");
    }

    @Test
    void testFromDTO_NullInput() {
        Enseignant enseignant = EnseignantDTOConverter.fromDTO(null);

        assertNull(enseignant, "❌ Converting null should return null!");
    }

    @Test
    void testToDTO_ValidEnseignant() {
        Enseignant enseignant = new Enseignant(2, "Martin", "Alice", "alice.martin@example.com");

        EnseignantDTO dto = EnseignantDTOConverter.toEnseignantDTO(enseignant);

        assertNotNull(dto, "❌ Conversion result should not be null!");
        assertEquals(2, dto.id(), "❌ ID mismatch!");
        assertEquals("Martin", dto.nom(), "❌ Nom mismatch!");
        assertEquals("Alice", dto.prenom(), "❌ Prénom mismatch!");
        assertEquals("alice.martin@example.com", dto.email(), "❌ Email mismatch!");
    }

    @Test
    void testToDTO_NullInput() {
        EnseignantDTO dto = EnseignantDTOConverter.toEnseignantDTO(null);

        assertNull(dto, "❌ Converting null should return null!");
    }
}