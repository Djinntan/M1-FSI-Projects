package fr.univ_amu.m1info.client.util.model.enseignant;

import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EnseignantTest {

    @Test
    void testEnseignantCreation() {
        Enseignant enseignant = new Enseignant(1, "Dupont", "Jean", "jean.dupont@example.com");

        assertEquals(1, enseignant.getId(), "❌ ID mismatch!");
        assertEquals("Dupont", enseignant.getNom(), "❌ Nom mismatch!");
        assertEquals("Jean", enseignant.getPrenom(), "❌ Prénom mismatch!");
        assertEquals("jean.dupont@example.com", enseignant.getEmail(), "❌ Email mismatch!");
    }

    @Test
    void testToString() {
        Enseignant enseignant = new Enseignant(2, "Martin", "Alice", "alice.martin@example.com");

        String result = enseignant.toString();

        assertEquals("Martin Alice (alice.martin@example.com)", result, "❌ toString() output mismatch!");
    }
}

