package fr.univ_amu.m1info.client.util.model.etudiant;

import fr.univ_amu.m1info.client.model.etudiant.Etudiant;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EtudiantTest {

    @Test
    void testEtudiant_CreationAndGetters() {
        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");
        Etudiant etudiant = new Etudiant(1, "Doe", "John", "john.doe@example.com", groupe);

        assertEquals(1, etudiant.getId());
        assertEquals("Doe", etudiant.getNom());
        assertEquals("John", etudiant.getPrenom());
        assertEquals("john.doe@example.com", etudiant.getEmail());
    }

    @Test
    void testToString_Format() {
        GroupeDTO groupe = new GroupeDTO(2, "Groupe B");
        Etudiant etudiant = new Etudiant(2, "Smith", "Alice", "alice.smith@example.com", groupe);

        String result = etudiant.toString();

        assertEquals("Smith Alice (alice.smith@example.com)", result);
    }
}

