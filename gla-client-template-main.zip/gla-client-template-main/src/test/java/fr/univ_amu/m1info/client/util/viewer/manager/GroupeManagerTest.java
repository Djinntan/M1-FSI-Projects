package fr.univ_amu.m1info.client.util.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormResult;
import fr.univ_amu.m1info.client.viewer.manager.GroupeManager;
import javafx.scene.control.Dialog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GroupeManagerTest {

    private GroupeManager groupeManager;

    @Mock
    private GroupeServiceDAO groupeServiceDAO;

    @Mock
    private GroupeFormFactory groupeFormFactory;

    @Mock
    private Dialog<GroupeFormResult> mockDialog;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        groupeManager = new GroupeManager(groupeServiceDAO, groupeFormFactory);

        when(groupeFormFactory.createGroupeManagementDialog()).thenReturn(mockDialog);
    }

    @Test
    void testHandleManageGroupes_Cancel() {
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new GroupeFormResult(FormAction.CANCEL, null)));

        groupeManager.handleManageGroupes();

        verify(groupeServiceDAO, never()).deleteGroupe(any());
        verify(groupeServiceDAO, never()).createOrUpdateGroupe(any());
    }

    @Test
    void testHandleManageGroupes_Delete() {
        GroupeFormContent content = new GroupeFormContent(1, "Groupe");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new GroupeFormResult(FormAction.DELETE, content)));
        when(groupeServiceDAO.deleteGroupe("Groupe")).thenReturn(true);

        groupeManager.handleManageGroupes();

        verify(groupeServiceDAO).deleteGroupe("Groupe");
    }

    @Test
    void testHandleManageGroupes_Confirm() {
        GroupeFormContent content = new GroupeFormContent(1, "Groupe");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new GroupeFormResult(FormAction.CONFIRM, content)));
        when(groupeServiceDAO.createOrUpdateGroupe(any(GroupeDTO.class))).thenReturn(true);

        groupeManager.handleManageGroupes();

        ArgumentCaptor<GroupeDTO> captor = ArgumentCaptor.forClass(GroupeDTO.class);
        verify(groupeServiceDAO).createOrUpdateGroupe(captor.capture());

        GroupeDTO capturedGroupe = captor.getValue();
        assertEquals("Groupe", capturedGroupe.nom());
    }

    @Test
    void testHandleManageGroupes_Confirm_Failed() {
        GroupeFormContent content = new GroupeFormContent(1, "Groupe");
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new GroupeFormResult(FormAction.CONFIRM, content)));
        when(groupeServiceDAO.createOrUpdateGroupe(any(GroupeDTO.class))).thenReturn(false);

        groupeManager.handleManageGroupes();

        verify(groupeServiceDAO).createOrUpdateGroupe(any(GroupeDTO.class));
    }
}

