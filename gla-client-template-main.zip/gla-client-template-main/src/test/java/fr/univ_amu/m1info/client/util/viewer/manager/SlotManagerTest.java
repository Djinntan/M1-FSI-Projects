package fr.univ_amu.m1info.client.util.viewer.manager;

import fr.univ_amu.m1info.client.model.Calendar;
import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlot;
import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.configuration.CalendarViewConfiguration;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormResult;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormContent;
import fr.univ_amu.m1info.client.viewer.manager.SlotManager;
import fr.univ_amu.m1info.client.viewer.presenter.CalendarPresenter;
import javafx.scene.control.Dialog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SlotManagerTest {
    private SlotManager slotManager;

    @Mock
    private Calendar calendar;

    @Mock
    private SalleServiceDAO salleServiceDAO;

    @Mock
    private EnseignantServiceDAO enseignantServiceDAO;

    @Mock
    private SlotFormFactory slotFormFactory;

    @Mock
    private CalendarPresenter calendarPresenter;

    @Mock
    private CalendarViewConfiguration calendarViewConfiguration;

    @Mock
    private Dialog<SlotFormResult> mockDialog;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        slotManager = new SlotManager(calendar, salleServiceDAO, slotFormFactory, calendarPresenter, calendarViewConfiguration, enseignantServiceDAO);

        when(slotFormFactory.createCalendarEventDialog(any(LocalDateTime.class), anyInt())).thenReturn(mockDialog);
    }

    @Test
    void testHandleSlotCreation_Cancel() {
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SlotFormResult(FormAction.CANCEL, null)));

        slotManager.handleSlotCreation();

        verify(calendar, never()).create(any());
        verify(calendarPresenter, never()).addSlotView(any(), any(), any());
    }

    @Test
    void testHandleSlotCreation_Confirm() {
        SlotFormContent formContent = new SlotFormContent(
                LocalTime.of(9, 0),
                LocalDate.now(),
                Duration.ofHours(2),
                "Some description",
                new SalleDTO(1, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE),
                new EnseignantDTO(1, "Dupont", "Jean", "jean.dupont@example.com"),
                new GroupeDTO(1, "Groupe 1") // Mocked GroupeDTO
        );
        when(mockDialog.showAndWait()).thenReturn(Optional.of(new SlotFormResult(FormAction.CONFIRM, formContent)));

        Slot createdSlot = new SimpleSlot("Cours", LocalDateTime.now(), Duration.ofHours(2), 1, 0, mock(Salle.class), mock(Enseignant.class), mock(Groupe.class));
        when(calendar.create(any(Slot.class))).thenReturn(createdSlot);

        slotManager.handleSlotCreation();

        verify(calendar).create(any(Slot.class));
        verify(calendarPresenter).addSlotView(any(Slot.class), any(), any());
    }

    @Test
    void testHandleSlotEdition_Cancel() throws WrongVersionException, UnknownElementException {
        Slot existingSlot = new SimpleSlot("TD", LocalDateTime.now(), Duration.ofMinutes(90), 1, 1, mock(Salle.class), mock(Enseignant.class), mock(Groupe.class));
        slotManager.handleSlotEdition(1);

        verify(slotFormFactory, never()).createCalendarEventDialog(any(Slot.class));
        verify(calendar, never()).update(any(Slot.class));
    }

    @Test
    void testHandleSlotEdition_Confirm() throws WrongVersionException, UnknownElementException {
        // Arrange: Mock existing slot and add it to slotManager
        Slot existingSlot = new SimpleSlot(
                "TD",
                LocalDateTime.now(),
                Duration.ofMinutes(90),
                1,
                1,
                mock(Salle.class),
                mock(Enseignant.class),
                mock(Groupe.class)
        );

        slotManager.slotsById.put(1, existingSlot);

        // Mock the dialog
        Dialog<SlotFormResult> mockEditDialog = mock(Dialog.class);
        when(slotFormFactory.createCalendarEventDialog(existingSlot)).thenReturn(mockEditDialog);

        // Mock form result
        SlotFormContent formContent = new SlotFormContent(
                LocalDateTime.now().toLocalTime(),
                LocalDate.now(),
                Duration.ofMinutes(120),
                "Updated TD",
                mock(SalleDTO.class),
                mock(EnseignantDTO.class),
                mock(GroupeDTO.class)
        );
        when(mockEditDialog.showAndWait()).thenReturn(Optional.of(new SlotFormResult(FormAction.CONFIRM, formContent)));

        // Mock updated slot
        Slot updatedSlot = new SimpleSlot(
                "Updated TD",
                LocalDateTime.now(),
                Duration.ofMinutes(120),
                1,
                1,
                mock(Salle.class),
                mock(Enseignant.class),
                mock(Groupe.class)
        );
        when(calendar.update(any(Slot.class))).thenReturn(updatedSlot);

        // Act
        slotManager.handleSlotEdition(1);

        // Assert
        verify(calendar).update(any(Slot.class)); // Ensure update is called
        verify(calendarPresenter).removeSlotView(1); // Ensure old slot is removed
        verify(calendarPresenter).addSlotView(any(Slot.class), any(), any()); // Ensure new slot is added
    }

    @Test
    void testHandleSlotEdition_Delete() {
        // Arrange: Create and add the existing slot to slotManager
        Slot existingSlot = new SimpleSlot(
                "TD",
                LocalDateTime.now(),
                Duration.ofMinutes(90),
                1,
                1,
                mock(Salle.class),
                mock(Enseignant.class),
                mock(Groupe.class)
        );

        slotManager.slotsById.put(1, existingSlot); // Ensure slot exists

        Dialog<SlotFormResult> mockEditDialog = mock(Dialog.class);
        when(slotFormFactory.createCalendarEventDialog(existingSlot)).thenReturn(mockEditDialog);
        when(mockEditDialog.showAndWait()).thenReturn(Optional.of(new SlotFormResult(FormAction.DELETE, null)));

        when(calendar.delete(any(Slot.class))).thenReturn(true);

        slotManager.handleSlotEdition(1);

        verify(calendar).delete(any(Slot.class)); // Ensure delete is called
        verify(calendarPresenter).removeSlotView(1); // Ensure UI is updated
    }


    @Test
    void testRefreshSlots() {
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusDays(7);

        Slot slot1 = new SimpleSlot("CM", LocalDateTime.now(), Duration.ofMinutes(60), 1, 1, mock(Salle.class), mock(Enseignant.class), mock(Groupe.class));
        Slot slot2 = new SimpleSlot("TP", LocalDateTime.now(), Duration.ofMinutes(120), 2, 1, mock(Salle.class), mock(Enseignant.class), mock(Groupe.class));

        when(calendar.getAllSlotsBetween(startDate, endDate.minusDays(1))).thenReturn(java.util.List.of(slot1, slot2));

        slotManager.refreshSlots(startDate, endDate);

        verify(calendarPresenter).clearSlotViews();
        verify(calendarPresenter, times(2)).addSlotView(any(Slot.class), any(), any());
    }
}

