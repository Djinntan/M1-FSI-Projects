package fr.univ_amu.m1info.client.viewer.dialog.salle;

import javafx.scene.control.Dialog;

public interface SalleFormFactory {
    Dialog<SalleFormResult> createSalleManagementDialog();
}
