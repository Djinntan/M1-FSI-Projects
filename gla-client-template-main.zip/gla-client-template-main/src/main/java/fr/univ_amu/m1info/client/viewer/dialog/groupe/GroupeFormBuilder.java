package fr.univ_amu.m1info.client.viewer.dialog.groupe;

import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormBuilder;
import javafx.scene.control.*;

public class GroupeFormBuilder extends FormBuilder<GroupeFormResult> {
    private TextField nomField;
    private Label errorLabel;
    private int groupeId;


    public GroupeFormBuilder reset() {
        super.reset();
        groupeId = -1;

        nomField = new TextField();

        errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        grid.add(new Label("Nom :"), 0, 0);
        grid.add(nomField, 1, 0);
        grid.add(errorLabel, 1, 3);

        return this;
    }

    public GroupeFormBuilder buildTitle(String title) {
        dialog.setTitle(title);
        return this;
    }

    public GroupeFormBuilder buildHeader(String headerText) {
        dialog.setHeaderText(headerText);
        return this;
    }

    public GroupeFormBuilder buildCancelButton() {
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        return this;
    }

    public GroupeFormBuilder buildDeleteButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OTHER));
        return this;
    }

    public GroupeFormBuilder buildConfirmButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OK_DONE));
        return this;
    }

    public Dialog<GroupeFormResult> getDialog() {
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OK_DONE) {
                return new GroupeFormResult(FormAction.CONFIRM, new GroupeFormContent(
                        groupeId,
                        nomField.getText()
                ));
            }
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OTHER) {
                return new GroupeFormResult(FormAction.DELETE, new GroupeFormContent(
                        groupeId, nomField.getText()
                ));
            }
            return new GroupeFormResult(FormAction.CANCEL, null);
        });
        return dialog;
    }
}
