package fr.univ_amu.m1info.client.viewer.dialog.slot;

public record SlotFormResult(fr.univ_amu.m1info.client.viewer.dialog.common.FormAction slotFormAction, SlotFormContent slotFormContent) {
}
