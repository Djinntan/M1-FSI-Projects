package fr.univ_amu.m1info.client.viewer.dialog.enseignant;

import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormBuilder;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormResult;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.net.http.HttpClient;

public class EnseignantFormBuilder extends FormBuilder<EnseignantFormResult> {
    private TextField nomField, prenomField, emailField;
    private Label errorLabel;
    private int enseignantId;
    private HttpClient httpClient = HttpClient.newHttpClient();
    private final EnseignantServiceDAO enseignantServiceDAO = new EnseignantServiceDAO(httpClient);


    public EnseignantFormBuilder reset() {
        super.reset();
        enseignantId = -1;

        nomField = new TextField();
        prenomField = new TextField();
        emailField = new TextField();

        errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        grid.add(new Label("Nom :"), 0, 0);
        grid.add(nomField, 1, 0);
        grid.add(new Label("Prénom :"), 0, 1);
        grid.add(prenomField, 1, 1);
        grid.add(new Label("Email :"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(errorLabel, 1, 3);

        return this;
    }

    public EnseignantFormBuilder buildTitle(String title) {
        dialog.setTitle(title);
        return this;
    }

    public EnseignantFormBuilder buildHeader(String headerText) {
        dialog.setHeaderText(headerText);
        return this;
    }

    public EnseignantFormBuilder buildCancelButton() {
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        return this;
    }

    public EnseignantFormBuilder buildDeleteButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OTHER));
        return this;
    }

    public EnseignantFormBuilder buildConfirmButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OK_DONE));
        return this;
    }

    public Dialog<EnseignantFormResult> getDialog() {
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OK_DONE) {
                return new EnseignantFormResult(FormAction.CONFIRM, new EnseignantFormContent(
                        enseignantId,
                        nomField.getText(),
                        prenomField.getText(),
                        emailField.getText()
                ));
            }
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OTHER) {
                return new EnseignantFormResult(FormAction.DELETE, new EnseignantFormContent(
                        enseignantId, nomField.getText(), prenomField.getText(), emailField.getText()
                ));
            }
            return new EnseignantFormResult(FormAction.CANCEL, null);
        });
        return dialog;
    }
}
