package fr.univ_amu.m1info.client.viewer.dialog.etudiant;

import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.dialog.GroupeDTOStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.SalleDTOStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormBuilder;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormBuilder;
import javafx.scene.Node;
import javafx.scene.control.*;

import java.util.List;

public class EtudiantFormBuilder extends FormBuilder<EtudiantFormResult> {
    private TextField nomField, prenomField, emailField;
    private Label errorLabel;
    private int etudiantId;
    private ComboBox<GroupeDTO> groupePicker;


    public EtudiantFormBuilder reset() {
        super.reset();
        groupePicker = null;
        etudiantId = -1;

        nomField = new TextField();
        prenomField = new TextField();
        emailField = new TextField();

        errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        grid.add(new Label("Nom :"), 0, 0);
        grid.add(nomField, 1, 0);
        grid.add(new Label("Prénom :"), 0, 1);
        grid.add(prenomField, 1, 1);
        grid.add(new Label("Email :"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(errorLabel, 1, 3);

        return this;
    }

    public EtudiantFormBuilder buildTitle(String title) {
        dialog.setTitle(title);
        return this;
    }

    public EtudiantFormBuilder buildHeader(String headerText) {
        dialog.setHeaderText(headerText);
        return this;
    }

    public EtudiantFormBuilder buildCancelButton() {
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        return this;
    }

    public EtudiantFormBuilder buildDeleteButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OTHER));
        return this;
    }

    public EtudiantFormBuilder buildConfirmButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OK_DONE));
        return this;
    }

    public EtudiantFormBuilder buildGroupePicker(String description, List<GroupeDTO> groupes, GroupeDTO selectedGroupe) {
        groupePicker = new ComboBox<>();
        groupePicker.getItems().add(null);
        groupePicker.getItems().addAll(groupes);
        groupePicker.setValue(selectedGroupe);
        groupePicker.setConverter(new GroupeDTOStringConverter()); // Convertisseur pour affichage
        addElementToDialog(description, groupePicker);
        return this;
    }

    public Dialog<EtudiantFormResult> getDialog() {
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OK_DONE) {
                return new EtudiantFormResult(FormAction.CONFIRM, new EtudiantFormContent(
                        etudiantId,
                        nomField.getText(),
                        prenomField.getText(),
                        emailField.getText(),
                        groupePicker.getValue()
                ));
            }
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OTHER) {
                return new EtudiantFormResult(FormAction.DELETE, new EtudiantFormContent(
                        etudiantId, nomField.getText(), prenomField.getText(), emailField.getText(), groupePicker.getValue()
                ));
            }
            return new EtudiantFormResult(FormAction.CANCEL, null);
        });
        return dialog;
    }
    private void addElementToDialog(String description, Node content){
        grid.add(new Label(description), 0, 3);
        grid.add(content, 1, 3);
    }
}
