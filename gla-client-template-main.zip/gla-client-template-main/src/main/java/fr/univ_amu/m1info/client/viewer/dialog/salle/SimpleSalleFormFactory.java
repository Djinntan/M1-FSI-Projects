package fr.univ_amu.m1info.client.viewer.dialog.salle;

import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import javafx.scene.control.*;

public class SimpleSalleFormFactory implements SalleFormFactory {
    private final SalleFormBuilder salleFormBuilder = new SalleFormBuilder();

    @Override
    public Dialog<SalleFormResult> createSalleManagementDialog() {
        return salleFormBuilder.reset()
                .buildTitle("Gestion des Salles")
                .buildHeader("Créer, Modifier ou Supprimer une Salle")
                .buildTextFieldWithPrompt("Nom de la Salle :", "Nom")
                .buildTextFieldWithPrompt("Bâtiment :", "Bâtiment")
                .buildTextFieldWithPrompt("Campus :", "Campus")
                .buildBooleanField("Vidéo-projecteur :", false)
                .buildIntegerField("Capacité :", 25)
                .buildTypeSallePicker("Type de Salle :", TypeSalle.TD)
                .buildCancelButton()
                .buildDeleteButton("Supprimer Salle")
                .buildConfirmButton("Sauvegarder Salle")
                .getDialog();
    }
}
