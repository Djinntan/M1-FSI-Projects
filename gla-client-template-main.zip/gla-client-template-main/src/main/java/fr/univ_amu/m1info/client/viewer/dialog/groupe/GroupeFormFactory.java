package fr.univ_amu.m1info.client.viewer.dialog.groupe;

import javafx.scene.control.Dialog;

public interface GroupeFormFactory {
    Dialog<GroupeFormResult> createGroupeManagementDialog();
}
