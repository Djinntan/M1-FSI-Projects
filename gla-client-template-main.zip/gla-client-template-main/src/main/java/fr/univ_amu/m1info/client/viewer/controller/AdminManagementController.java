package fr.univ_amu.m1info.client.viewer.controller;

import fr.univ_amu.m1info.client.model.Calendar;
import fr.univ_amu.m1info.client.model.simpleCalendar.SimpleCalendar;
import fr.univ_amu.m1info.client.service.dao.*;
import fr.univ_amu.m1info.client.viewer.configuration.CalendarWeekViewConfiguration;
import fr.univ_amu.m1info.client.viewer.configuration.PeriodCalendarViewController;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.SimpleEnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.SimpleEtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.SimpleGroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.manager.EnseignantManager;
import fr.univ_amu.m1info.client.viewer.manager.EtudiantManager;
import fr.univ_amu.m1info.client.viewer.manager.GroupeManager;
import fr.univ_amu.m1info.client.viewer.manager.SalleManager;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SimpleSalleFormFactory;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.net.http.HttpClient;
import java.time.Duration;
import java.time.LocalTime;

public class AdminManagementController {

    private final SalleManager salleManager;
    private final EnseignantManager enseignantManager;
    private final EtudiantManager etudiantManager;
    private final GroupeManager groupeManager;

    public AdminManagementController(SalleServiceDAO salleServiceDAO, EnseignantServiceDAO enseignantServiceDAO, EtudiantServiceDAO etudiantServiceDAO, GroupeServiceDAO groupeServiceDAO,
                                     SimpleSalleFormFactory salleFormFactory, EnseignantFormFactory enseignantFormFactory, EtudiantFormFactory etudiantFormFactory, GroupeFormFactory groupeFormFactory) {
        this.salleManager = new SalleManager(salleServiceDAO, salleFormFactory);
        this.enseignantManager = new EnseignantManager(enseignantServiceDAO, enseignantFormFactory);
        this.etudiantManager= new EtudiantManager(etudiantServiceDAO, etudiantFormFactory);
        this.groupeManager = new GroupeManager(groupeServiceDAO,groupeFormFactory);
    }

    public AdminManagementController(SalleManager salleManager, EnseignantManager enseignantManager, EtudiantManager etudiantManager,GroupeManager groupeManager) {
        this.salleManager = salleManager;
        this.enseignantManager = enseignantManager;
        this.etudiantManager= etudiantManager;
        this.groupeManager = groupeManager;
    }


    public void showAdminView(Stage primaryStage) {
        AdminView adminView = new AdminView();

        adminView.setOnManageSalles(salleManager::handleManageSalles);
        adminView.setOnManageEnseignants(enseignantManager::handleManageEnseignants);
        adminView.setOnManageEtudiants(etudiantManager::handleManageEtudiants);
        adminView.setOnManageGroupes(groupeManager::handleManageGroupes);

        adminView.setOnLaunchCalendar(() -> launchCalendar(primaryStage));

        Scene scene = adminView.getScene();
        primaryStage.setTitle("Accueil");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private void launchCalendar(Stage primaryStage) {
        HttpClient httpClient = HttpClient.newHttpClient();
            Calendar calendar = new SimpleCalendar(new SimpleCalendarServiceDAO(httpClient));
        CalendarViewController calendarController = new PeriodCalendarViewController(
                calendar,
                new CalendarWeekViewConfiguration(
                        LocalTime.of(8, 0),
                        LocalTime.of(19, 0),
                        Duration.ofMinutes(15),
                        Duration.ofHours(4),
                        Duration.ofHours(1),
                        Color.AQUA
                ),
                primaryStage
        );

        primaryStage.setTitle("ADE");
        primaryStage.setScene(calendarController.getScene());
        primaryStage.setResizable(true);
        primaryStage.show();
    }
}
