package fr.univ_amu.m1info.client.viewer.dialog.common;

public enum FormAction {
    DELETE, CONFIRM, CANCEL
}
