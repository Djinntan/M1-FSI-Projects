package fr.univ_amu.m1info.client.viewer.configuration;

import fr.univ_amu.m1info.client.util.duration.DurationGenerator;
import fr.univ_amu.m1info.client.util.timeInterval.TimeIntervalGenerator;
import javafx.scene.paint.Color;

import java.time.LocalDate;
import java.time.Period;

public interface CalendarViewConfiguration {
    Period getTotalPeriod();
    Period getPrintablePeriod();
    TimeIntervalGenerator getTimeIntervalGenerator();
    DurationGenerator getPossibleDurations();
    LocalDate getPeriodStartDateContaining(LocalDate date);
    int getDefaultDurationIndex();
    Color colorOfSlots();
}
