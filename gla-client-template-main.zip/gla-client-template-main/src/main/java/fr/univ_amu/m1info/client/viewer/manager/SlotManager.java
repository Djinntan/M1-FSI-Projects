package fr.univ_amu.m1info.client.viewer.manager;

import fr.univ_amu.m1info.client.model.Calendar;
import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.enseignant.EnseignantDTOConverter;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.groupe.GroupeDTOConverter;
import fr.univ_amu.m1info.client.model.salle.SalleDTOConverter;
import fr.univ_amu.m1info.client.model.simpleCalendar.SimpleCalendar;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlot;
import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.viewer.configuration.CalendarViewConfiguration;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormResult;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormContent;
import fr.univ_amu.m1info.client.viewer.presenter.CalendarPresenter;
import javafx.scene.control.Dialog;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class SlotManager {
    public final Calendar calendar;
    private final SalleServiceDAO salleServiceDAO;
    private final EnseignantServiceDAO enseignantServiceDAO;
    private final SlotFormFactory slotFormFactory;
    private final CalendarPresenter calendarPresenter;
    private final CalendarViewConfiguration calendarViewConfiguration;
    public final Map<Integer, Slot> slotsById = new HashMap<>();

    public SlotManager(Calendar calendar, SalleServiceDAO salleServiceDAO,
                       SlotFormFactory slotFormFactory, CalendarPresenter calendarPresenter,
                       CalendarViewConfiguration calendarViewConfiguration, EnseignantServiceDAO enseignantServiceDAO) {
        this.calendar = calendar;
        this.salleServiceDAO = salleServiceDAO;
        this.enseignantServiceDAO = enseignantServiceDAO;
        this.slotFormFactory = slotFormFactory;
        this.calendarPresenter = calendarPresenter;
        this.calendarViewConfiguration = calendarViewConfiguration;
    }

    public void handleSlotEdition(int idSlot) {
        Slot slot = slotsById.get(idSlot);
        if (slot == null) return;

        Dialog<SlotFormResult> dialog = slotFormFactory.createCalendarEventDialog(slot);
        dialog.showAndWait().ifPresent(r -> {
            try {
                handleFormResult(r, slot);
            } catch (WrongVersionException | UnknownElementException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void handleFormResult(SlotFormResult result, Slot slot)
            throws WrongVersionException, UnknownElementException {
        SlotFormContent form = result.slotFormContent();
        switch (result.slotFormAction()) {
            case DELETE -> deleteSlot(slot.id());
            case CONFIRM -> {
                if (form != null) {
                    LocalDateTime start = LocalDateTime.of(form.startDate(), form.startTime());
                    Salle salle = SalleDTOConverter.fromDTO(form.salle());
                    Enseignant enseignant = EnseignantDTOConverter.fromDTO(form.enseignant());
                    Groupe groupe = GroupeDTOConverter.fromDTO(form.groupe());

                    Slot editedSlot = new SimpleSlot(form.description(), start, form.duration(),
                            slot.id(), slot.versionNumber(), salle,enseignant,groupe);
                    updateSlot(editedSlot);
                }
            }
            case CANCEL -> {}
        }
    }

    private void deleteSlot(int id) {
        if (calendar.delete(slotsById.get(id))) {
            slotsById.remove(id);
            calendarPresenter.removeSlotView(id);
        }
    }

    public void handleSlotCreation() {
        Dialog<SlotFormResult> dialog = slotFormFactory.createCalendarEventDialog(
                LocalDateTime.now(), calendarViewConfiguration.getDefaultDurationIndex());
        dialog.showAndWait().ifPresent(this::processSlotCreation);
    }

    private void processSlotCreation(SlotFormResult result) {
        SlotFormContent form = result.slotFormContent();
        if (form != null && result.slotFormAction() == FormAction.CONFIRM) {
            LocalDateTime start = LocalDateTime.of(form.startDate(), form.startTime());
            Salle salle = SalleDTOConverter.fromDTO(form.salle());
            Enseignant enseignant = EnseignantDTOConverter.fromDTO(form.enseignant());
            Groupe groupe = GroupeDTOConverter.fromDTO(form.groupe());
            Slot newSlot = new SimpleSlot(form.description(), start, form.duration(), -1, 0, salle,enseignant,groupe);
            createSlot(newSlot);
        }
    }

    private void createSlot(Slot slot) {
        Slot created = calendar.create(slot);
        if (created != null) {
            slotsById.put(created.id(), created);
            addSlotToView(created);
        }
    }

    private void updateSlot(Slot slot) throws WrongVersionException, UnknownElementException {
        Slot updated = calendar.update(slot);
        if (updated != null) {
            slotsById.put(updated.id(), updated);
            calendarPresenter.removeSlotView(updated.id());
            addSlotToView(updated);
        }
    }

    private void addSlotToView(Slot slot) {
        calendarPresenter.addSlotView(slot, calendarViewConfiguration.colorOfSlots(), this::handleSlotEdition);
    }

    public void invalidateCache() {
        if (calendar instanceof SimpleCalendar) {
            ((SimpleCalendar) calendar).invalidateCache();
        }
    }

    public void refreshSlots(LocalDate startDate, LocalDate endDate) {
        slotsById.clear();
        calendarPresenter.clearSlotViews();
        calendar.getAllSlotsBetween(startDate, endDate.minusDays(1))
                .forEach(this::addSlotToView);
    }
}