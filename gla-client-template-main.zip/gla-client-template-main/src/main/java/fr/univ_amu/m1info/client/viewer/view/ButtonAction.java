package fr.univ_amu.m1info.client.viewer.view;

public interface ButtonAction {
    void action();
}
