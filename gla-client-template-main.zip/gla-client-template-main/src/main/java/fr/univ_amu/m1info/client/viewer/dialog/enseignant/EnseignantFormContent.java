package fr.univ_amu.m1info.client.viewer.dialog.enseignant;


public record EnseignantFormContent(
        int id,
        String nom,
        String prenom,
        String email
) {}

