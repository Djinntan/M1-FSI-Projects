package fr.univ_amu.m1info.client.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.EnseignantFormResult;
import javafx.scene.control.Dialog;

public class EnseignantManager {

    private final EnseignantServiceDAO enseignantServiceDAO;
    private final EnseignantFormFactory enseignantFormFactory;

    public EnseignantManager(EnseignantServiceDAO enseignantServiceDAO,EnseignantFormFactory enseignantFormFactory) {
        this.enseignantServiceDAO = enseignantServiceDAO;
        this.enseignantFormFactory = enseignantFormFactory;

    }

    public void handleManageEnseignants() {
        Dialog<EnseignantFormResult> dialog = enseignantFormFactory.createEnseignantManagementDialog();
        var result = dialog.showAndWait();
        result.ifPresent(this::handleEnseignantFormResult);
    }

    private void handleEnseignantFormResult(EnseignantFormResult r) {
        switch (r.enseignantFormAction()) {
            case CANCEL -> {}
            case DELETE -> deleteEnseignant(r.enseignantFormContent());
            case CONFIRM -> {
                if (r.enseignantFormContent() != null) {
                    createOrUpdateEnseignant(r.enseignantFormContent());
                }
            }
        }
    }

    private void deleteEnseignant(EnseignantFormContent enseignantContent) {
        boolean deleted = enseignantServiceDAO.deleteEnseignant(enseignantContent.email());

        if (deleted) {
            System.out.println("Enseignant supprimé : " + enseignantContent.nom() + " " + enseignantContent.prenom());
        } else {
            System.out.println("Impossible de supprimer l'enseignant, il n'existe pas.");
        }
    }

    private void createOrUpdateEnseignant(EnseignantFormContent enseignantContent) {
        if (enseignantContent != null) {
            EnseignantDTO enseignantDTO = new EnseignantDTO(
                    -1, // ❌ L'ID est géré par le serveur
                    enseignantContent.nom(),
                    enseignantContent.prenom(),
                    enseignantContent.email()
            );

            boolean success = enseignantServiceDAO.createOrUpdateEnseignant(enseignantDTO);
            if (success) {
                System.out.println("Enseignant créé ou mis à jour avec succès : " + enseignantDTO.nom() + " " + enseignantDTO.prenom());
            } else {
                System.out.println("Erreur lors de la création/mise à jour de l'enseignant.");
            }
        }
    }
}

