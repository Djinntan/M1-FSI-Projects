package fr.univ_amu.m1info.client.model;

import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.salle.Salle;

import java.time.Duration;
import java.time.LocalDateTime;

public interface Slot {
    String description() ;
    int id();
    LocalDateTime startDateTime();
    Duration duration();
    LocalDateTime getEndDateTime();
    int versionNumber();
    Salle salle();
    Enseignant enseignant();
    Groupe groupe();
    String getSalleName();
    String getEnseignantName();
    String getGroupeName();
}
