package fr.univ_amu.m1info.client.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.GroupeFormResult;
import javafx.scene.control.Dialog;

public class GroupeManager {

    private final GroupeServiceDAO groupeServiceDAO;
    private final GroupeFormFactory groupeFormFactory;

    public GroupeManager(GroupeServiceDAO groupeServiceDAO, GroupeFormFactory groupeFormFactory) {
        this.groupeServiceDAO = groupeServiceDAO;
        this.groupeFormFactory = groupeFormFactory;
    }

    public void handleManageGroupes() {
        Dialog<GroupeFormResult> dialog = groupeFormFactory.createGroupeManagementDialog();
        var result = dialog.showAndWait();
        result.ifPresent(this::handleGroupeFormResult);
    }

    private void handleGroupeFormResult(GroupeFormResult r) {
        switch (r.groupeFormAction()) {
            case CANCEL -> {}
            case DELETE -> deleteGroupe(r.groupeFormContent());
            case CONFIRM -> {
                if (r.groupeFormContent() != null) {
                    createOrUpdateGroupe(r.groupeFormContent());
                }
            }
        }
    }

    private void deleteGroupe(GroupeFormContent groupeContent) {
        boolean deleted = groupeServiceDAO.deleteGroupe(
                groupeContent.nom()
        );

        if (deleted) {
            System.out.println("Groupe supprimée : " + groupeContent.nom());
        } else {
            System.out.println("Impossible de supprimer la groupe, elle n'existe pas.");
        }
    }

    private void createOrUpdateGroupe(GroupeFormContent groupeContent) {
        if (groupeContent != null) {
            GroupeDTO groupeDTO = new GroupeDTO(
                    -1,
                    groupeContent.nom()
            );

            boolean success = groupeServiceDAO.createOrUpdateGroupe(groupeDTO);
            if (success) {
                System.out.println("Groupe créée ou mise à jour avec succès : " + groupeDTO.nom());
            } else {
                System.out.println("Erreur lors de la création/mise à jour de la groupe.");
            }
        }
    }
}
