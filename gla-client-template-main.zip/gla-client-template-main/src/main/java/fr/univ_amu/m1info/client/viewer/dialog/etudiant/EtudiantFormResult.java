package fr.univ_amu.m1info.client.viewer.dialog.etudiant;

import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;

public record EtudiantFormResult(FormAction etudiantFormAction, EtudiantFormContent etudiantFormContent) {
}

