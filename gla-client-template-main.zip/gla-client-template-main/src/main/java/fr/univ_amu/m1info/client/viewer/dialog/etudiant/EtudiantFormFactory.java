package fr.univ_amu.m1info.client.viewer.dialog.etudiant;

import javafx.scene.control.Dialog;

public interface EtudiantFormFactory {
    Dialog<EtudiantFormResult> createEtudiantManagementDialog();
}
