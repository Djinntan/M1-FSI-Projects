package fr.univ_amu.m1info.client.service.dto;

public record GroupeDTO(int id, String nom) {
}
