package fr.univ_amu.m1info.client.model;

import fr.univ_amu.m1info.client.service.dto.SlotDTO;

import java.time.LocalDateTime;
import java.util.Collection;

public class CacheSlot {
    private final Collection<SlotDTO> slots;
    private final LocalDateTime expirationTime;

    public CacheSlot(Collection<SlotDTO> slots, int cacheDurationMinutes) {
        this.slots = slots;
        this.expirationTime = LocalDateTime.now().plusMinutes(cacheDurationMinutes);
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expirationTime);
    }

    public Collection<SlotDTO> getSlots() {
        return slots;
    }
}
