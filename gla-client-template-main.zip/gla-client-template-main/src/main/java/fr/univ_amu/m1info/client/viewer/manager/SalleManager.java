package fr.univ_amu.m1info.client.viewer.manager;

import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormFactory;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SalleFormResult;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SimpleSalleFormFactory;
import javafx.scene.control.Dialog;

public class SalleManager {

    private final SalleServiceDAO salleServiceDAO;
    private final SalleFormFactory salleFormFactory;

    public SalleManager(SalleServiceDAO salleServiceDAO, SimpleSalleFormFactory salleFormFactory) {
        this.salleServiceDAO = salleServiceDAO;
        this.salleFormFactory = salleFormFactory;
    }

    public void handleManageSalles() {
        Dialog<SalleFormResult> dialog = salleFormFactory.createSalleManagementDialog();
        var result = dialog.showAndWait();
        result.ifPresent(this::handleSalleFormResult);
    }

    private void handleSalleFormResult(SalleFormResult r) {
        switch (r.salleFormAction()) {
            case CANCEL -> {}
            case DELETE -> deleteSalle(r.salleFormContent());
            case CONFIRM -> {
                if (r.salleFormContent() != null) {
                    createOrUpdateSalle(r.salleFormContent());
                }
            }
        }
    }

    private void deleteSalle(SalleFormContent salleContent) {
        boolean deleted = salleServiceDAO.deleteSalle(
                salleContent.nom(),
                salleContent.batiment(),
                salleContent.campus()
        );

        if (deleted) {
            System.out.println("Salle supprimée : " + salleContent.nom());
        } else {
            System.out.println("Impossible de supprimer la salle, elle n'existe pas.");
        }
    }

    private void createOrUpdateSalle(SalleFormContent salleContent) {
        if (salleContent != null) {
            SalleDTO salleDTO = new SalleDTO(
                    -1, // ❌ On ignore l'ID ici, c'est le serveur qui le gère
                    salleContent.nom(),
                    salleContent.batiment(),
                    salleContent.campus(),
                    salleContent.videoProjecteur(),
                    salleContent.capacite(),
                    salleContent.typeSalle()
            );

            boolean success = salleServiceDAO.createOrUpdateSalle(salleDTO);
            if (success) {
                System.out.println("Salle créée ou mise à jour avec succès : " + salleDTO.nom());
            } else {
                System.out.println("Erreur lors de la création/mise à jour de la salle.");
            }
        }
    }
}
