package fr.univ_amu.m1info.client.viewer.presenter;
import fr.univ_amu.m1info.client.util.timeInterval.TimeInterval;
import fr.univ_amu.m1info.client.viewer.view.ButtonConfiguration;
import fr.univ_amu.m1info.client.viewer.view.GridCalendarView;
import fr.univ_amu.m1info.client.viewer.view.SlotView;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;

import java.time.LocalDate;
import java.util.List;

public interface ViewElementFactory {
    Label createDateLabel(LocalDate date);
    Label createTimeIntervalLabel(TimeInterval timeInterval);
    SlotView createSlotView(SlotViewData slotViewData, Color backgroundColor);
    GridCalendarView createGrid(int rows, int columns,
                                int widthFirstColumn,
                                int widthSecondToLastColumn,
                                int heightFirstRow,
                                int heightSecondToLastRow,
                                Color linesColor,
                                Color backgroundColor);
    HBox createButtonBox(List<ButtonConfiguration> buttons);
}
