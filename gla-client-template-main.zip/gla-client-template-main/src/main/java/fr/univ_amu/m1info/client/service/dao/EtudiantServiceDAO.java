package fr.univ_amu.m1info.client.service.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.EtudiantDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Optional;

public class EtudiantServiceDAO {
    private static final String URL_SERVER = "http://localhost:8080/etudiants";
    private static final Logger logger = LogManager.getLogger(EtudiantServiceDAO.class);

    private final HttpClient client;
    private final ObjectMapper objectMapper;
    public EtudiantServiceDAO(HttpClient client) {
        this.client = client;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .enable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING)
                .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    public List<EtudiantDTO> getAllEtudiants() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return List.of(objectMapper.readValue(response.body(), EtudiantDTO[].class));
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la récupération des etudiants", e);
            return List.of();
        }
    }


    public boolean deleteEtudiant(String email) {
        if (email == null || email.isBlank()) {
            logger.warn("❌ Suppression échouée : email vide ou null.");
            return false;
        }


        Optional<EtudiantDTO> etudiantOpt = getAllEtudiants().stream()
                .filter(etudiant -> etudiant.email().equalsIgnoreCase(email)) // ✅ Comparaison insensible à la casse
                .findFirst();

        if (etudiantOpt.isPresent()) {
            int id = etudiantOpt.get().id();
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI(URL_SERVER + "/" + id))
                        .DELETE()
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                boolean success = response.statusCode() == 204;
                if (success) {
                    logger.info("✅ Etudiant supprimé : " + email);
                } else {
                    logger.warn("⚠️ Suppression de l'etudiant a échoué avec statut : " + response.statusCode());
                }
                return success;
            } catch (IOException | InterruptedException | URISyntaxException e) {
                logger.error("Erreur lors de la suppression de l'etudiant", e);
            }
        } else {
            logger.warn("⚠️ Etudiant '" + email + "' non trouvé, suppression impossible.");
        }
        return false;
    }


    public boolean createOrUpdateEtudiant(EtudiantDTO etudiant) {
        if (etudiant == null) {
            logger.error("❌ Erreur : etudiant null.");
            return false;
        }

        if (!isValidEmail(etudiant.email())) {
            logger.warn("⚠️ Email invalide : " + etudiant.email());
            return false;
        }


        boolean emailExists = getAllEtudiants().stream()
                .anyMatch(e -> e.email().equalsIgnoreCase(etudiant.email()) && e.id() != etudiant.id());

        if (emailExists) {
            logger.warn("⚠️ Email déjà utilisé : " + etudiant.email());
            return updateEtudiant(etudiant);
        }

        try {
            String jsonBody = objectMapper.writeValueAsString(etudiant);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.statusCode() == 200 || response.statusCode() == 201;
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la création/mise à jour de l'etudiant", e);
            return false;
        }
    }


    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email != null && email.matches(emailRegex);
    }

    public boolean updateEtudiant(EtudiantDTO etudiant) {
        int id= etudiant.id();
        Optional<EtudiantDTO> etudiantOpt = getAllEtudiants().stream()
                .filter(etudiants -> etudiants.email().equalsIgnoreCase(etudiant.email())) // ✅ Comparaison insensible à la casse
                .findFirst();

        if (etudiantOpt.isPresent()) {
             id = etudiantOpt.get().id();

        }

        try {
            String jsonBody = objectMapper.writeValueAsString(etudiant);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + id))
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.statusCode() == 200;
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Erreur lors de la mise à jour de l'étudiant", e);
            return false;
        }
    }

}
