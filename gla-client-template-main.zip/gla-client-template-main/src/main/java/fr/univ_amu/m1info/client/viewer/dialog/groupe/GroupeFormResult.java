package fr.univ_amu.m1info.client.viewer.dialog.groupe;

import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;

public record GroupeFormResult(FormAction groupeFormAction, GroupeFormContent groupeFormContent) {
}

