package fr.univ_amu.m1info.client.viewer.view;

public record ButtonConfiguration(String Label, ButtonAction buttonAction) {
}
