package fr.univ_amu.m1info.client.viewer.dialog.etudiant;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import javafx.scene.control.Dialog;

import java.net.http.HttpClient;
import java.util.List;

public class SimpleEtudiantFormFactory implements EtudiantFormFactory {
    private HttpClient httpClient = HttpClient.newHttpClient();
    private final EtudiantFormBuilder formBuilder = new EtudiantFormBuilder();
    private final GroupeServiceDAO groupeServiceDAO = new GroupeServiceDAO(httpClient);

    @Override
    public Dialog<EtudiantFormResult> createEtudiantManagementDialog() {
        List<GroupeDTO> groupes = groupeServiceDAO.getAllGroupes();
        return formBuilder.reset()
                .buildTitle("Gestion des etudiants")
                .buildHeader("Ajout, modification ou suppression d'un etudiant")
                .buildGroupePicker("Groupe", groupes, null)
                .buildCancelButton()
                .buildDeleteButton("Supprimer etudiant")
                .buildConfirmButton("Enregistrer etudiant")
                .getDialog();
    }
}
