package fr.univ_amu.m1info.client.service.dao.exceptions;

import java.io.IOException;

public class ConnexionException extends IOException {
}
