package fr.univ_amu.m1info.client.service.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Optional;

public class EnseignantServiceDAO {
    private static final String URL_SERVER = "http://localhost:8080/enseignants";
    private static final Logger logger = LogManager.getLogger(EnseignantServiceDAO.class);

    private final HttpClient client;
    private final ObjectMapper objectMapper;

    public EnseignantServiceDAO(HttpClient client) {
        this.client = client;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .enable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING)
                .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    public List<EnseignantDTO> getAllEnseignants() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            int statusCode = response.statusCode();
            logger.info("📡 HTTP Response Status Code: " + statusCode);

            if (statusCode != 200) {
                logger.warn("⚠️ Unexpected response code: " + statusCode);
                return List.of();
            }

            return List.of(objectMapper.readValue(response.body(), EnseignantDTO[].class));
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la récupération des enseignants", e);
            return List.of();
        }
    }

    public boolean deleteEnseignant(String email) {
        if (email == null || email.isBlank()) {
            logger.warn("❌ Suppression échouée : email vide ou null.");
            return false;
        }

        Optional<EnseignantDTO> enseignantOpt = getAllEnseignants().stream()
                .filter(enseignant -> enseignant.email().equalsIgnoreCase(email))
                .findFirst();

        if (enseignantOpt.isEmpty()) {
            logger.warn("⚠️ Enseignant '" + email + "' non trouvé, suppression impossible.");
            return false;
        }

        int id = enseignantOpt.get().id();
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + id))
                    .DELETE()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            boolean success = response.statusCode() == 204;
            if (success) {
                logger.info("✅ Enseignant supprimé : " + email);
            } else {
                logger.warn("⚠️ Suppression de l'enseignant a échoué avec statut : " + response.statusCode());
            }
            return success;
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la suppression de l'enseignant", e);
            return false;
        }
    }

    public boolean createOrUpdateEnseignant(EnseignantDTO enseignant) {
        if (enseignant == null) {
            logger.error("❌ Erreur : enseignant null.");
            return false;
        }

        if (!isValidEmail(enseignant.email())) {
            logger.warn("⚠️ Email invalide : " + enseignant.email());
            return false;
        }

        try {
            String jsonBody = objectMapper.writeValueAsString(enseignant);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200 || response.statusCode() == 201) {
                logger.info("✅ Enseignant ajouté/mis à jour : " + enseignant.email());
                return true;
            } else {
                logger.warn("⚠️ Échec de la création/mise à jour avec statut: " + response.statusCode());
                return false;
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la création/mise à jour de l'enseignant", e);
            return false;
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email != null && email.matches(emailRegex);
    }
}
