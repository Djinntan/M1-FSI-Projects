package fr.univ_amu.m1info.client.model.enseignant;

import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;

public class EnseignantDTOConverter {
    public static Enseignant fromDTO(EnseignantDTO enseignantDTO) {
        if (enseignantDTO == null) return null;
        return new Enseignant(
                enseignantDTO.id(),
                enseignantDTO.nom(),
                enseignantDTO.prenom(),
                enseignantDTO.email()
        );
    }

    public static EnseignantDTO toEnseignantDTO(Enseignant enseignant) {
        if (enseignant == null) return null;
        return new EnseignantDTO(
                enseignant.getId(),
                enseignant.getNom(),
                enseignant.getPrenom(),
                enseignant.getEmail()
        );
    }
}
