package fr.univ_amu.m1info.client.viewer.manager;

import fr.univ_amu.m1info.client.service.dao.EtudiantServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EtudiantDTO;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormContent;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.EtudiantFormResult;
import javafx.scene.control.Dialog;

public class EtudiantManager {

    private final EtudiantServiceDAO etudiantServiceDAO;
    private final EtudiantFormFactory etudiantFormFactory;

    public EtudiantManager(EtudiantServiceDAO etudiantServiceDAO, EtudiantFormFactory etudiantFormFactory) {
        this.etudiantServiceDAO = etudiantServiceDAO;
        this.etudiantFormFactory = etudiantFormFactory;

    }


    public void handleManageEtudiants() {
        Dialog<EtudiantFormResult> dialog = etudiantFormFactory.createEtudiantManagementDialog();
        var result = dialog.showAndWait();
        result.ifPresent(this::handleEtudiantFormResult);
    }

    private void handleEtudiantFormResult(EtudiantFormResult r) {
        switch (r.etudiantFormAction()) {
            case CANCEL -> {}
            case DELETE -> deleteEtudiant(r.etudiantFormContent());
            case CONFIRM -> {
                if (r.etudiantFormContent() != null) {
                    createOrUpdateEtudiant(r.etudiantFormContent());
                }
            }
        }
    }

    private void deleteEtudiant(EtudiantFormContent etudiantContent) {
        boolean deleted = etudiantServiceDAO.deleteEtudiant(etudiantContent.email());

        if (deleted) {
            System.out.println("Etudiant supprimé : " + etudiantContent.nom() + " " + etudiantContent.prenom());
        } else {
            System.out.println("Impossible de supprimer l'etudiant, il n'existe pas.");
        }
    }

    private void createOrUpdateEtudiant(EtudiantFormContent etudiantContent) {
        if (etudiantContent != null) {
            EtudiantDTO etudiantDTO = new EtudiantDTO(
                    -1, // ❌ L'ID est géré par le serveur
                    etudiantContent.nom(),
                    etudiantContent.prenom(),
                    etudiantContent.email(),
                    etudiantContent.groupe()
            );

            boolean success = etudiantServiceDAO.createOrUpdateEtudiant(etudiantDTO);
            if (success) {
                System.out.println("Etudiant créé ou mis à jour avec succès : " + etudiantDTO.nom() + " " + etudiantDTO.prenom());
            } else {
                System.out.println("Erreur lors de la création/mise à jour de l'etudiant.");
            }
        }
    }
}

