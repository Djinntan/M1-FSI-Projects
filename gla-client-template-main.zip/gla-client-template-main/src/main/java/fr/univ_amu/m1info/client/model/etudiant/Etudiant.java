package fr.univ_amu.m1info.client.model.etudiant;

import fr.univ_amu.m1info.client.service.dto.GroupeDTO;

public class Etudiant {
    private int id;
    private String nom;
    private String prenom;
    private String email;
    private GroupeDTO groupe;

    public Etudiant(int id, String nom, String prenom, String email, GroupeDTO groupe) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.groupe = groupe;
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return nom + " " + prenom + " (" + email + ")";
    }
}
