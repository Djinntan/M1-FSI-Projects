package fr.univ_amu.m1info.client.viewer.dialog.salle;

import fr.univ_amu.m1info.client.model.salle.TypeSalle;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormBuilder;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

public class SalleFormBuilder extends FormBuilder<SalleFormResult> {
    private TextField nomField, batimentField, campusField;
    private CheckBox videoProjecteurCheckBox;
    private Spinner<Integer> capaciteSpinner;
    private ComboBox<TypeSalle> typeSalleComboBox;
    private int salleId;

    public SalleFormBuilder reset() {
       super.reset();
        salleId= -1;
        nomField = new TextField();
        batimentField = new TextField();
        campusField = new TextField();
        videoProjecteurCheckBox = new CheckBox();
        capaciteSpinner = new Spinner<>(1, 500, 50);
        typeSalleComboBox = new ComboBox<>();
        typeSalleComboBox.getItems().setAll(TypeSalle.values());

        grid.add(new Label("Nom :"), 0, 0);
        grid.add(nomField, 1, 0);
        grid.add(new Label("Bâtiment :"), 0, 1);
        grid.add(batimentField, 1, 1);
        grid.add(new Label("Campus :"), 0, 2);
        grid.add(campusField, 1, 2);
        grid.add(new Label("Vidéo-projecteur :"), 0, 3);
        grid.add(videoProjecteurCheckBox, 1, 3);
        grid.add(new Label("Capacité :"), 0, 4);
        grid.add(capaciteSpinner, 1, 4);
        grid.add(new Label("Type de Salle :"), 0, 5);
        grid.add(typeSalleComboBox, 1, 5);

        return this;
    }

    public SalleFormBuilder setId(int id) {
        this.salleId = id;
        return this;
    }


    public SalleFormBuilder buildTitle(String title) {
        dialog.setTitle(title);
        return this;
    }

    public SalleFormBuilder buildHeader(String headerText) {
        dialog.setHeaderText(headerText);
        return this;
    }

    public SalleFormBuilder buildTextFieldWithPrompt(String label, String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        return this;
    }

    public SalleFormBuilder buildBooleanField(String label, boolean defaultValue) {
        videoProjecteurCheckBox.setSelected(defaultValue);
        return this;
    }

    public SalleFormBuilder buildIntegerField(String label, int defaultValue) {
        capaciteSpinner.getValueFactory().setValue(defaultValue);
        return this;
    }

    public SalleFormBuilder buildTypeSallePicker(String label, TypeSalle defaultValue) {
        typeSalleComboBox.setValue(defaultValue);
        return this;
    }

    public SalleFormBuilder buildCancelButton() {
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        return this;
    }

    public SalleFormBuilder buildDeleteButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OTHER));
        return this;
    }

    public SalleFormBuilder buildConfirmButton(String label) {
        dialog.getDialogPane().getButtonTypes().add(new ButtonType(label, ButtonBar.ButtonData.OK_DONE));
        return this;
    }

    public Dialog<SalleFormResult> getDialog() {
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OK_DONE) {
                return new SalleFormResult(FormAction.CONFIRM, new SalleFormContent( salleId,
                        nomField.getText(), batimentField.getText(), campusField.getText(),
                        videoProjecteurCheckBox.isSelected(), capaciteSpinner.getValue(), typeSalleComboBox.getValue()
                ));
            }
            if (dialogButton.getButtonData() == ButtonBar.ButtonData.OTHER) {
                return new SalleFormResult(FormAction.DELETE, new SalleFormContent( salleId,
                        nomField.getText(), batimentField.getText(),
                        campusField.getText(), false, 0, null
                ));
            }
            return new SalleFormResult(FormAction.CANCEL, null);
        });
        return dialog;
    }
}
