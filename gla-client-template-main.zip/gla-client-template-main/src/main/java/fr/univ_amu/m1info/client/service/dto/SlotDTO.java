package fr.univ_amu.m1info.client.service.dto;

import fr.univ_amu.m1info.client.model.Slot;

public record SlotDTO(int id, String description, DateTimeInterval timeInterval, int version, SalleDTO salle, EnseignantDTO enseignant, GroupeDTO groupe) {
}
