package fr.univ_amu.m1info.client.viewer.dialog.common;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;

public abstract class FormBuilder<T>  {

    protected Dialog<T> dialog;
    protected GridPane grid;

    public FormBuilder<T> reset() {
        dialog = new Dialog<>();
        grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));
        dialog.getDialogPane().setContent(grid);
        return this;
    }

    public abstract Dialog<T> getDialog();
}
