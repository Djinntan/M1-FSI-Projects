package fr.univ_amu.m1info.client.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;

public record SalleDTO(int id, String nom, String batiment, String campus, boolean videoProjecteur, int capacite,  @JsonFormat(shape = JsonFormat.Shape.STRING) TypeSalle typeSalle) {
}

