package fr.univ_amu.m1info.client.util.timeInterval;

import java.time.LocalTime;

public record TimeInterval(LocalTime start, LocalTime end) {
}
