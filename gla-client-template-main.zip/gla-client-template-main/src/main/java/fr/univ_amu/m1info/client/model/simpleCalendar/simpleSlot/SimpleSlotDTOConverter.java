package fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.SlotDTOConverter;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.enseignant.EnseignantDTOConverter;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.salle.Salle;
import fr.univ_amu.m1info.client.model.salle.SalleDTOConverter;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SlotDTO;
import fr.univ_amu.m1info.client.service.dto.DateTimeInterval;

import java.time.Duration;

public class SimpleSlotDTOConverter implements SlotDTOConverter {

    public Slot fromDTO(SlotDTO slotDTO) {
        Salle salle = slotDTO.salle() != null ? new Salle(
                slotDTO.salle().id(),
                slotDTO.salle().nom(),
                slotDTO.salle().batiment(),
                slotDTO.salle().campus(),
                slotDTO.salle().videoProjecteur(),
                slotDTO.salle().capacite(),
                slotDTO.salle().typeSalle()
        ) : null;

        Enseignant enseignant = slotDTO.enseignant() != null ? new Enseignant(
                slotDTO.enseignant().id(),
                slotDTO.enseignant().nom(),
                slotDTO.enseignant().prenom(),
                slotDTO.enseignant().email()
        ) : null;

        Groupe groupe = slotDTO.groupe() != null ? new Groupe(
                slotDTO.groupe().id(),
                slotDTO.groupe().nom()
        ) : null;



        return new SimpleSlot(
                slotDTO.description(),
                slotDTO.timeInterval().start(),
                Duration.between(slotDTO.timeInterval().start(), slotDTO.timeInterval().end()),
                slotDTO.id(),
                slotDTO.version(),
                salle,
                enseignant,
                groupe
        );
    }

    @Override
    public SlotDTO toDTO(Slot slot) {
        return new SlotDTO(
                slot.id(),
                slot.description(),
                new DateTimeInterval(slot.startDateTime(), slot.getEndDateTime()),
                slot.versionNumber(),
                slot.salle() != null ? SalleDTOConverter.toSalleDTO(slot.salle()) : null,
                slot.enseignant() != null ? EnseignantDTOConverter.toEnseignantDTO(slot.enseignant()) : null,
                slot.groupe() != null ? new GroupeDTO(
                        slot.groupe().getId(),
                        slot.groupe().getNom()
                ) : null);
    }
}


