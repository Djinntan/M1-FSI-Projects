package fr.univ_amu.m1info.client.viewer.dialog.slot;

import fr.univ_amu.m1info.client.model.Slot;
import javafx.scene.control.Dialog;

import java.time.LocalDateTime;

public interface SlotFormFactory {

    Dialog<SlotFormResult> createCalendarEventDialog(Slot slotInfo);

    Dialog<SlotFormResult> createCalendarEventDialog(LocalDateTime defaultLocalDateTime,
                                                     int defaultPossibleDurationIndex);
}
