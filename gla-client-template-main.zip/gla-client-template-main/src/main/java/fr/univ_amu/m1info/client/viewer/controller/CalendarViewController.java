package fr.univ_amu.m1info.client.viewer.controller;

import javafx.scene.Scene;
import javafx.stage.Stage;

public interface CalendarViewController {
    void handleNext();
    void handlePrevious();
    void handleSlotEdition(int idSlot);
    void handleSlotCreation();
    Scene getScene();
    void handleAdminManagement();
    void refreshSlots();
}
