package fr.univ_amu.m1info.client.viewer.presenter;

import fr.univ_amu.m1info.client.util.timeInterval.TimeInterval;
import fr.univ_amu.m1info.client.viewer.view.ButtonConfiguration;
import fr.univ_amu.m1info.client.viewer.view.GridCalendarView;
import fr.univ_amu.m1info.client.viewer.view.SlotView;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;

public class SimpleViewElementFactory implements ViewElementFactory {

    private static final Color[] SLOT_COLORS = {
            Color.PINK,
            Color.POWDERBLUE,
            Color.ORANGERED,
            Color.LIGHTGREEN,
            Color.CRIMSON,
            Color.DARKCYAN,
            Color.LIGHTGREEN,
            Color.CORAL
    };


    private final Random random = new Random();


    private Color getRandomSlotColor() {
        return SLOT_COLORS[random.nextInt(SLOT_COLORS.length)];
    }

    @Override
    public Label createDateLabel(LocalDate date) {
        DateTimeFormatter dayFormatter = DateTimeFormatter.ofPattern("E\nMMM d");
        Label label = new Label(date.format(dayFormatter));
        label.setPadding(new Insets(1));
        label.setTextAlignment(TextAlignment.CENTER);
        GridPane.setHalignment(label, HPos.CENTER);

        label.setStyle("-fx-font-size: 14px;-fx-font-weight: bold; -fx-font-family: 'Times New Roman'; -fx-text-fill: #454444;");

        return label;
    }

    @Override
    public Label createTimeIntervalLabel(TimeInterval timeInterval) {
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        Label label = new Label(timeInterval.start().format(timeFormatter) + "-" + timeInterval.end().format(timeFormatter));
        GridPane.setHalignment(label, HPos.CENTER);

        label.setStyle("-fx-text-fill: #454444;");

        return label;
    }

    @Override
    public SlotView createSlotView(SlotViewData slotViewData, Color backgroundColor) {
        Color randomColor = getRandomSlotColor();
        return new SlotView(slotViewData, randomColor);
    }

    @Override
    public GridCalendarView createGrid(int columns, int rows,
                                       int widthFirstColumn,
                                       int widthSecondToLastColumn,
                                       int heightFirstRow,
                                       int heightSecondToLastRow,
                                       Color linesColor,
                                       Color backgroundColor) {
        GridCalendarView grid = new GridCalendarView();
        grid.setBackground(new Background(new BackgroundFill(linesColor, null, null)));
        grid.setHgap(1);
        grid.setVgap(1);

        grid.setStyle("-fx-text-fill: #454444;");

        ColumnConstraints columnConstraints = new ColumnConstraints(widthFirstColumn+40);
        grid.getColumnConstraints().add(columnConstraints);
        for(int i = 1; i < columns; i++) {
            ColumnConstraints column = new ColumnConstraints(widthSecondToLastColumn+10);
            grid.getColumnConstraints().add(column);
        }
        RowConstraints row = new RowConstraints(heightFirstRow+40);
        grid.getRowConstraints().add(row);
        for(int i = 1; i < rows; i++) {
            row = new RowConstraints(heightSecondToLastRow+10);
            grid.getRowConstraints().add(row);
        }
        for(int i = 0; i < columns; i++) {
            for(int j = 0; j < rows; j++) {
                Pane child = new Pane();
                child.setBackground(new Background(new BackgroundFill(backgroundColor, null, null)));
                child.setStyle("-fx-text-fill: #454444;");
                grid.add(child, i, j);
            }
        }
        return grid;
    }

    @Override
    public HBox createButtonBox(List<ButtonConfiguration> buttons) {
        HBox hBox = new HBox();
        hBox.setSpacing(2);
        hBox.setAlignment(Pos.CENTER);
        for (ButtonConfiguration buttonConfiguration : buttons) {
            Button button = new Button(buttonConfiguration.Label());
            String defaultStyle = "-fx-font-weight: bold; " +
                    "-fx-font-size: 14px; " +
                    "-fx-text-fill: white; " +
                    "-fx-background-color: #5e8357; " +
                    "-fx-border-color: #999; " +
                    "-fx-border-radius: 5px;";

            String hoverStyle = "-fx-font-weight: bold; " +
                    "-fx-font-size: 14px; " +
                    "-fx-text-fill: white; " +
                    "-fx-background-color: #6fa26f; " +
                    "-fx-border-color: #999; " +
                    "-fx-border-radius: 5px;";
            button.setStyle(defaultStyle);
            button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
            button.setOnMouseExited(e -> button.setStyle(defaultStyle));

            button.setOnMouseClicked(_ -> buttonConfiguration.buttonAction().action());
            hBox.getChildren().add(button);
        }
        return hBox;
    }
}
