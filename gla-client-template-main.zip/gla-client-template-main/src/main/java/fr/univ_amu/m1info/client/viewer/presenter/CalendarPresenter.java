package fr.univ_amu.m1info.client.viewer.presenter;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.util.day.DayGenerator;
import fr.univ_amu.m1info.client.util.timeInterval.TimeIntervalGenerator;
import javafx.scene.Scene;
import javafx.scene.paint.Color;

import java.util.function.Consumer;

public interface CalendarPresenter {
    Scene getScene();
    void clearSlotViews();
    void addSlotView(Slot slot, Color backGroundColor, Consumer<Integer> actionOnClick);
    void removeSlotView(int idSlot);
    void updateDays(DayGenerator days);
    void updateTimeIntervals(TimeIntervalGenerator timeIntervals);
}
