package fr.univ_amu.m1info.client.service.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Optional;

public class SalleServiceDAO {
    private static final String URL_SERVER = "http://localhost:8080/salles";
    private static final Logger logger = LogManager.getLogger(SalleServiceDAO.class);


    private final HttpClient client;
    private final ObjectMapper objectMapper;
    public SalleServiceDAO(HttpClient client) {
        this.client = client;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .enable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING)
                .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
    public List<SalleDTO> getAllSalles() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return List.of(objectMapper.readValue(response.body(), SalleDTO[].class));
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Erreur lors de la récupération des salles", e);
            return List.of();
        }
    }

    public Optional<SalleDTO> getSalleById(int id) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + id))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return Optional.ofNullable(objectMapper.readValue(response.body(), SalleDTO.class));
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Erreur lors de la récupération de la salle", e);
            return Optional.empty();
        }
    }

    public SalleDTO createSalle(SalleDTO salle) {
        try {
            String jsonBody = objectMapper.writeValueAsString(salle);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return objectMapper.readValue(response.body(), SalleDTO.class);
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Erreur lors de la création de la salle", e);
            return null;
        }
    }

    public boolean updateSalle(SalleDTO salle) {
        try {
            String jsonBody = objectMapper.writeValueAsString(salle);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + salle.id()))
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.statusCode() == 200;
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Erreur lors de la mise à jour de la salle", e);
            return false;
        }
    }

    public boolean deleteSalle(String nom, String batiment, String campus) {
        // 🔍 Recherche de la salle par ses informations
        Optional<SalleDTO> salleOpt = getAllSalles().stream()
                .filter(salle -> salle.nom().equalsIgnoreCase(nom) &&
                        salle.batiment().equalsIgnoreCase(batiment) &&
                        salle.campus().equalsIgnoreCase(campus))
                .findFirst();

        if (salleOpt.isPresent()) {
            int id = salleOpt.get().id(); // ✅ Récupération de l'ID

            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI(URL_SERVER + "/" + id)) // Suppression avec l'ID trouvé
                        .DELETE()
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                return response.statusCode() == 204;
            } catch (IOException | InterruptedException | URISyntaxException e) {
                logger.error("Erreur lors de la suppression de la salle", e);
            }
        } else {
            logger.warn("Salle '{}' non trouvée sur '{}' - '{}', suppression impossible.", nom, batiment, campus);
        }
        return false;
    }

    public boolean createOrUpdateSalle(SalleDTO salle) {
        try {
            String jsonBody = objectMapper.writeValueAsString(salle);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER)) // ✅ On ne met PAS d'ID !
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.statusCode() == 200 || response.statusCode() == 201; // ✅ OK si mise à jour ou création réussie
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la création/mise à jour de la salle", e);
            return false;
        }
    }


}
