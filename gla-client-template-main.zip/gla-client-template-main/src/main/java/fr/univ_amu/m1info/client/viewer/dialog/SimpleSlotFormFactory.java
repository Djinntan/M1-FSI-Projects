package fr.univ_amu.m1info.client.viewer.dialog;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.enseignant.EnseignantDTOConverter;
import fr.univ_amu.m1info.client.model.groupe.GroupeDTOConverter;
import fr.univ_amu.m1info.client.model.salle.SalleDTOConverter;
import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormBuilder;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormResult;
import javafx.scene.control.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class SimpleSlotFormFactory implements SlotFormFactory {
    private final SlotFormBuilder slotFormBuilder = new SlotFormBuilder();
    private final List<LocalTime> possibleTimes;
    private final List<Duration> possibleDurations;
    private final SalleServiceDAO salleServiceDAO;
    private final EnseignantServiceDAO enseignantServiceDAO;
    private final GroupeServiceDAO groupeServiceDAO;

    public SimpleSlotFormFactory(List<LocalTime> possibleTimes, List<Duration> possibleDurations, SalleServiceDAO salleServiceDAO, EnseignantServiceDAO enseignantServiceDAO, GroupeServiceDAO groupeServiceDAO) {
        this.possibleTimes = possibleTimes;
        this.possibleDurations = possibleDurations;
        this.salleServiceDAO = salleServiceDAO;
        this.enseignantServiceDAO = enseignantServiceDAO;
        this.groupeServiceDAO = groupeServiceDAO;
    }

    @Override
    public Dialog<SlotFormResult> createCalendarEventDialog(Slot slotInfo) {
        int indexOfSlotTime = possibleTimes.indexOf(slotInfo.startDateTime().toLocalTime());
        if (indexOfSlotTime == -1) {
            throw new IllegalArgumentException("Slot is outside range");
        }
        int indexOfSlotDuration = possibleDurations.indexOf(slotInfo.duration());

        List<SalleDTO> salles = salleServiceDAO.getAllSalles();
        List<EnseignantDTO> enseignants = enseignantServiceDAO.getAllEnseignants();
        List<GroupeDTO> groupes = groupeServiceDAO.getAllGroupes();

        return slotFormBuilder.reset()
                .buildTitle("Édition de créneau")
                .buildHeader("Édition d'un créneau du calendrier")
                .buildTextFieldWithDefaultText("Description :", slotInfo.description())
                .buildDatePicker("Date :", slotInfo.startDateTime().toLocalDate())
                .buildTimePicker("Heure :", possibleTimes, indexOfSlotTime)
                .buildDurationPicker("Durée :", possibleDurations, indexOfSlotDuration)
                .buildSallePicker("Salle :", salles, SalleDTOConverter.toSalleDTO(slotInfo.salle()))
                .buildEnseignantPicker( "Enseignant: ", enseignants, EnseignantDTOConverter.toEnseignantDTO(slotInfo.enseignant()))
                .buildGroupePicker("Groupe :", groupes, GroupeDTOConverter.toGroupeDTO(slotInfo.groupe()))
                .buildCancelButton()
                .buildDeleteButton("Supprimer créneau")
                .buildConfirmButton("Modifier créneau")
                .getDialog();
    }


    @Override
    public Dialog<SlotFormResult> createCalendarEventDialog(LocalDateTime defaultLocalDateTime,
                                                            int defaultPossibleDurationIndex) {
        int defaultTimeIndex = possibleTimes.indexOf(defaultLocalDateTime.toLocalTime());
        if(defaultTimeIndex == -1) {
            defaultTimeIndex = 0;
        }

        List<SalleDTO> salles = salleServiceDAO.getAllSalles();
        List<EnseignantDTO> enseignants = enseignantServiceDAO.getAllEnseignants();
        List<GroupeDTO> groupes = groupeServiceDAO.getAllGroupes();

        return slotFormBuilder.reset()
                .buildTitle("Création de créneau")
                .buildHeader("Création d'un créneau du calendrier")
                .buildTextFieldWithPrompt("Description :", "description du créneau")
                .buildDatePicker("Date :", defaultLocalDateTime.toLocalDate())
                .buildTimePicker("Heure :", possibleTimes, defaultTimeIndex)
                .buildDurationPicker("Durée :", possibleDurations, defaultPossibleDurationIndex)
                .buildSallePicker("Salle :", salles, null)
                .buildEnseignantPicker( "Enseignant: ", enseignants, null)
                .buildGroupePicker("Groupe :", groupes, null)
                .buildCancelButton()
                .buildConfirmButton("Créer créneau")
                .getDialog();
    }
}
