package fr.univ_amu.m1info.client.viewer.view;

import fr.univ_amu.m1info.client.viewer.presenter.SlotViewData;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class SlotView extends VBox {
    private final int slotId;

    public SlotView(SlotViewData slotViewData, Color color) {
        this.slotId = slotViewData.id();
        setBackground(new Background(new BackgroundFill(color, new CornerRadii(3), null)));
        Label label = new Label(slotViewData.description());
        label.setStyle("-fx-font-size: 14px; -fx-font-family: 'Times New Roman'; -fx-text-fill: white;");

        setAlignment(Pos.BASELINE_CENTER);
        getChildren().add(label);
        setSpacing(5);
        Label labelSalle = new Label( slotViewData.salle());
        labelSalle.setStyle("-fx-font-size: 12px; -fx-font-family: 'Times New Roman'; -fx-text-fill: #454444;");
        setAlignment(Pos.BASELINE_CENTER);
        getChildren().add(labelSalle);
        setSpacing(5);
        Label labelEnseignant = new Label( slotViewData.enseignant());
        labelEnseignant.setStyle("-fx-font-size: 12px; -fx-font-family: 'Times New Roman'; -fx-text-fill: #454444;");
        setAlignment(Pos.BASELINE_CENTER);
        getChildren().add(labelEnseignant);
        setSpacing(5);
        Label labelGroupe = new Label( slotViewData.groupe());
        labelGroupe.setStyle("-fx-font-size: 12px; -fx-font-family: 'Times New Roman'; -fx-text-fill: #454444;");
        setAlignment(Pos.BASELINE_CENTER);
        getChildren().add(labelGroupe);
    }

    public int getSlotId() {
        return slotId;
    }}