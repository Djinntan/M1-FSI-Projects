package fr.univ_amu.m1info.client.viewer.dialog;

import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import javafx.util.StringConverter;

public class EnseignantDTOStringConverter extends StringConverter<EnseignantDTO> {
    @Override
    public String toString(EnseignantDTO enseignant) {
        if (enseignant == null) {
            return "Aucun enseignant";
        }
        return enseignant.nom() + " " + enseignant.prenom() ;
    }

    @Override
    public EnseignantDTO fromString(String string) {
        return null; // Non utilisé car on sélectionne un élément dans la ComboBox
    }
}
