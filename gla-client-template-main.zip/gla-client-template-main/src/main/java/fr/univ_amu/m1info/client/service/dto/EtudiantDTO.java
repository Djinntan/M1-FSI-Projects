package fr.univ_amu.m1info.client.service.dto;

public record EtudiantDTO(int id, String nom, String prenom, String email, GroupeDTO groupe) {}
