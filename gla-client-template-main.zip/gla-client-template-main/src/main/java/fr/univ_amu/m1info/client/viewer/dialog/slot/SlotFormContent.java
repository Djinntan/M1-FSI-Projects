package fr.univ_amu.m1info.client.viewer.dialog.slot;

import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;

public record SlotFormContent(LocalTime startTime, LocalDate startDate, Duration duration, String description, SalleDTO salle, EnseignantDTO enseignant, GroupeDTO groupe) {}
