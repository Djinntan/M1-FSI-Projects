package fr.univ_amu.m1info.client.viewer.dialog.groupe;


public record GroupeFormContent(
        int id,
        String nom
) {}

