package fr.univ_amu.m1info.client.model.simpleCalendar;

import fr.univ_amu.m1info.client.model.*;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlot;
import fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot.SimpleSlotDTOConverter;
import fr.univ_amu.m1info.client.service.dao.CalendarServiceDAO;
import fr.univ_amu.m1info.client.service.dao.exceptions.ConnexionException;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.service.dto.SlotDTO;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SimpleCalendar implements Calendar {
    private static final int CACHE_DURATION_MINUTES = 20;
    private final CalendarServiceDAO calendarDAO;
    private final SlotDTOConverter slotDTOConverter = new SimpleSlotDTOConverter();

    private final Map<String, CacheSlot> cache = new HashMap<>();

    public SimpleCalendar(CalendarServiceDAO calendarDAO) {
        this.calendarDAO = calendarDAO;
    }

    @Override
    public Collection<Slot> getAllSlotsBetween(LocalDate startDate, LocalDate endDate) {
        String cacheKey = startDate + "_" + endDate;


        if (cache.containsKey(cacheKey) && !cache.get(cacheKey).isExpired()) {
            return cache.get(cacheKey).getSlots().stream()
                    .map(slotDTOConverter::fromDTO)
                    .collect(Collectors.toList());
        }
        // Sinon,on va  récupérer les données depuis le serveur et mettre à jour le cache avec les nouvelle données
        try {
            Collection<SlotDTO> slots = calendarDAO.getAllSlotsIn(startDate, endDate);
            cache.put(cacheKey, new CacheSlot(slots, CACHE_DURATION_MINUTES));
            System.out.println("###############le cache est mis a jour ########################");
            System.out.println("Contenu actuel du cache :");
            cache.forEach((key, cacheSlot) -> {
                System.out.println("Clé : " + key);
                cacheSlot.getSlots().forEach(slot ->
                        System.out.println(" - Slot: " + slot)
                );
            });

            return slots.stream().map(slotDTOConverter::fromDTO).collect(Collectors.toList());
        } catch (ConnexionException e) {
            return List.of();
        }
    }

    @Override
    public Slot create(Slot slot) {
        SlotDTO slotDTO = slotDTOConverter.toDTO(slot);
        try {

            int generatedId = calendarDAO.create(slotDTO);

            if (generatedId >= 0) {
                invalidateCache(); // Invalider le cache après modification
                return new SimpleSlot(slot.description(), slot.startDateTime(), slot.duration(), generatedId, slot.versionNumber(),slot.salle(), slot.enseignant(),slot.groupe());
            }}
        catch (ConnexionException e){
            return null;
        }
        return null;
    }

    @Override
    public Slot update(Slot slot) throws WrongVersionException, UnknownElementException {
        SlotDTO slotDTO = slotDTOConverter.toDTO(slot);
        try {

            int generatedId = calendarDAO.update(slotDTO);

            if (generatedId >= 0) {

                SlotDTO updatedSlotDTO = new SlotDTO(
                        generatedId,
                        slotDTO.description(),
                        slotDTO.timeInterval(),
                        slotDTO.version() + 1,
                        slotDTO.salle(),
                        slotDTO.enseignant(),
                        slotDTO.groupe()
                );

                invalidateCache(); // Invalider le cache après modification
                return new SimpleSlot(updatedSlotDTO.description(), slot.startDateTime(), slot.duration(), generatedId, updatedSlotDTO.version(),slot.salle(), slot.enseignant(), slot.groupe());
            }}
        catch (ConnexionException e){
            return null;
        }
        return null;
    }

    @Override
    public boolean delete(Slot slot){
        SlotDTO slotDTO = slotDTOConverter.toDTO(slot);
        try {
            calendarDAO.delete(slotDTO);
            invalidateCache();
            return true;
        }
        catch (UnknownElementException | WrongVersionException | ConnexionException e) {
            return false;
        }
    }
    public void invalidateCache() {
        cache.clear();
    }
}

