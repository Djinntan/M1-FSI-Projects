package fr.univ_amu.m1info.client.service.dto;

import java.util.List;

public record CalendarDTO(List<SlotDTO> calendarSlots) {

}
