package fr.univ_amu.m1info.client.viewer.dialog.enseignant;



import javafx.scene.control.Dialog;

public class SimpleEnseignantFormFactory implements EnseignantFormFactory {
    private final EnseignantFormBuilder formBuilder = new EnseignantFormBuilder();

    @Override
    public Dialog<EnseignantFormResult> createEnseignantManagementDialog() {
        return formBuilder.reset()
                .buildTitle("Gestion des enseignants")
                .buildHeader("Ajout, modification ou suppression d'un enseignant")
                .buildCancelButton()
                .buildDeleteButton("Supprimer enseignant")
                .buildConfirmButton("Enregistrer enseignant")
                .getDialog();
    }
}
