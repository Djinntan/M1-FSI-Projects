package fr.univ_amu.m1info.client.viewer.dialog.enseignant;

import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;

public record EnseignantFormResult(FormAction enseignantFormAction, EnseignantFormContent enseignantFormContent) {
}

