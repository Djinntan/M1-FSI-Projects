package fr.univ_amu.m1info.client.viewer.dialog.etudiant;


import fr.univ_amu.m1info.client.service.dto.GroupeDTO;

public record EtudiantFormContent(
        int id,
        String nom,
        String prenom,
        String email,
        GroupeDTO groupe
) {}

