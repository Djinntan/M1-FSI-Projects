package fr.univ_amu.m1info.client.viewer.dialog.slot;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import fr.univ_amu.m1info.client.viewer.dialog.DurationStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.EnseignantDTOStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.GroupeDTOStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.SalleDTOStringConverter;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class SlotFormBuilder {
    private Dialog<SlotFormResult> dialog;
    private TextField textField;
    private ComboBox<LocalTime> timePicker;
    private ComboBox<Duration> durationPicker;
    private ComboBox<SalleDTO> sallePicker;
    private ComboBox<EnseignantDTO> enseignantPicker;
    private ComboBox<GroupeDTO> groupePicker;
    private DatePicker datePicker;
    private int rowIndex;
    private GridPane grid;
    private ButtonType confirmButtonType;
    private ButtonType deleteButtonType;

    public SlotFormBuilder reset(){
        dialog = new Dialog<>();
        buildGrid(dialog);
        resetPickers();
        confirmButtonType = null;
        rowIndex = 0;



        return this;
    }

    private void resetPickers() {
        textField = null;
        timePicker = null;
        datePicker = null;
        durationPicker = null;
        sallePicker = null;
        enseignantPicker = null;
        groupePicker = null;
    }

    private void buildGrid(Dialog<SlotFormResult> dialog) {
        grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);
        grid.setPadding(new Insets(20, 150, 10, 10));
        dialog.getDialogPane().setContent(grid);
    }

    public SlotFormBuilder buildTitle(String title) {
        dialog.setTitle(title);
        return this;
    }

    public SlotFormBuilder buildHeader(String headerText) {
        dialog.setHeaderText(headerText);
        return this;
    }

    public SlotFormBuilder buildTextFieldWithPrompt(String description, String promptText){
        textField = new TextField();
        textField.setPromptText(promptText);
        addElementToDialog(description, textField);
        return this;
    }

    public SlotFormBuilder buildTextFieldWithDefaultText(String description, String defaultText){
        textField = new TextField();
        textField.setText(defaultText);
        addElementToDialog(description, textField);
        return this;
    }

    public SlotFormBuilder buildTimePicker(String description, List<LocalTime> possibleHours,
                                           int indexDefaultValue){
        timePicker = new ComboBox<>();
        timePicker.getItems().addAll(possibleHours);
        timePicker.getSelectionModel().select(indexDefaultValue);
        addElementToDialog(description, timePicker);
        return this;
    }

    public SlotFormBuilder buildDatePicker(String description, LocalDate defaultDate){
        datePicker = new DatePicker();
        datePicker.setValue(defaultDate);
        addElementToDialog(description, datePicker);
        return this;
    }

    public SlotFormBuilder buildDurationPicker(String description, List<Duration> possibleDurations,
                                               int indexDefaultValue){
        durationPicker = new ComboBox<>();
        durationPicker.getItems().addAll(possibleDurations);
        durationPicker.getSelectionModel().select(indexDefaultValue);
        durationPicker.setConverter(new DurationStringConverter());
        addElementToDialog(description, durationPicker);
        return this;
    }

    public SlotFormBuilder buildSallePicker(String description, List<SalleDTO> salles, SalleDTO selectedSalle) {
        sallePicker = new ComboBox<>();
        sallePicker.getItems().add(null);
        sallePicker.getItems().addAll(salles);
        sallePicker.setValue(selectedSalle);
        sallePicker.setConverter(new SalleDTOStringConverter()); // Convertisseur pour affichage
        addElementToDialog(description, sallePicker);
        return this;
    }

    public SlotFormBuilder buildEnseignantPicker(String description, List<EnseignantDTO> enseignants, EnseignantDTO selectedEnseignant) {
        enseignantPicker = new ComboBox<>();
        enseignantPicker.getItems().add(null);
        enseignantPicker.getItems().addAll(enseignants);
        enseignantPicker.setValue(selectedEnseignant);
        enseignantPicker.setConverter(new EnseignantDTOStringConverter()); // Convertisseur pour affichage
        addElementToDialog(description, enseignantPicker);
        return this;
    }

    public SlotFormBuilder buildGroupePicker(String description, List<GroupeDTO> groupes, GroupeDTO selectedGroupe) {
        groupePicker = new ComboBox<>();
        groupePicker.getItems().add(null);
        groupePicker.getItems().addAll(groupes);
        groupePicker.setValue(selectedGroupe);
        groupePicker.setConverter(new GroupeDTOStringConverter());
        addElementToDialog(description, groupePicker);
        return this;
    }


    private void addElementToDialog(String description, Node content){
        grid.add(new Label(description), 1, rowIndex);
        grid.add(content, 2, rowIndex);
        rowIndex++;
    }

    public SlotFormBuilder buildDeleteButton(String label){
        deleteButtonType = new ButtonType(label, ButtonBar.ButtonData.OTHER);
        dialog.getDialogPane().getButtonTypes().add(deleteButtonType);
        return this;
    }

    public SlotFormBuilder buildConfirmButton(String label){
        confirmButtonType = new ButtonType(label, ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(confirmButtonType);
        return this;
    }

    public SlotFormBuilder buildCancelButton(){
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        return this;
    }


    public Dialog<SlotFormResult> getDialog() {
        requireSetPickersAndButtons();
        addFormConverter();
        disableConfirmButtonWhenTextFieldIsEmpty();
        return dialog;
    }

    private void disableConfirmButtonWhenTextFieldIsEmpty() {
        Node confirmButton = dialog.getDialogPane().lookupButton(confirmButtonType);
        confirmButton.setDisable(textField.getText().trim().isEmpty());
        textField.textProperty().addListener((_, _, newValue)
                -> confirmButton.setDisable(newValue.trim().isEmpty()));
    }

    private void requireSetPickersAndButtons() {
        if(textField == null || datePicker == null || timePicker == null
                || durationPicker == null || confirmButtonType == null){
            throw new IllegalArgumentException("All the form elements must be set");
        }
    }

    private void addFormConverter() {
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == confirmButtonType) {
                SlotFormContent content = new SlotFormContent(timePicker.getValue(), datePicker.getValue(),
                        durationPicker.getValue(), textField.getText(), sallePicker.getValue(), enseignantPicker.getValue(), groupePicker.getValue());
                return new SlotFormResult(FormAction.CONFIRM, content);
            }
            if(dialogButton == deleteButtonType){
                return new SlotFormResult(FormAction.DELETE, null);
            }
            return new SlotFormResult(FormAction.CANCEL, null);
        });
    }
}
