package fr.univ_amu.m1info.client.viewer.presenter;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.viewer.controller.CalendarViewController;
import fr.univ_amu.m1info.client.util.day.DayGenerator;
import fr.univ_amu.m1info.client.util.timeInterval.TimeInterval;
import fr.univ_amu.m1info.client.util.timeInterval.TimeIntervalGenerator;
import fr.univ_amu.m1info.client.viewer.view.ButtonConfiguration;
import fr.univ_amu.m1info.client.viewer.view.CalendarView;
import fr.univ_amu.m1info.client.viewer.view.SlotView;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import java.time.*;
import java.util.List;
import java.util.function.Consumer;


public class PeriodCalendarPresenter implements CalendarPresenter {
    private final CalendarView view;
    private DayGenerator days;
    private TimeIntervalGenerator timeIntervals;
    private final ViewElementFactory viewElementFactory = new SimpleViewElementFactory();

    public PeriodCalendarPresenter(CalendarViewController calendarController,
                                   DayGenerator days,
                                   TimeIntervalGenerator timeIntervals) {
        this.view = viewElementFactory.createGrid(days.getNumberOfDays()+1, timeIntervals.getNumberOfIntervals()+1,
                100,100, 50, 10,
                Color.GREEN, Color.WHITE);
        updateButtons(List.of(
                new ButtonConfiguration("↰", calendarController::handleAdminManagement),
                new ButtonConfiguration("⬅", calendarController::handlePrevious),
                new ButtonConfiguration("➡", calendarController::handleNext),
                new ButtonConfiguration("+", calendarController::handleSlotCreation)));

        updateDays(days);
        updateTimeIntervals(timeIntervals);
    }

    private Position getPositionOf(Slot slotInfo) {
        LocalDateTime startDateTime = slotInfo.startDateTime();
        LocalTime time = startDateTime.toLocalTime();
        LocalDate date = startDateTime.toLocalDate();
        return new Position(dateIndex(date), intervalIndex(time), numberOfSlots(slotInfo.duration()));
    }

    private  record Position(int dayIndex, int intervalIndex, int numberOfIntervals) {

    }

    private int numberOfSlots(Duration duration) {
        return (int) duration.dividedBy(timeIntervals.getIntervalDuration());
    }

    private int intervalIndex(LocalTime time){
        return timeIntervals.getTimeIndex(time);
    }

    private int dateIndex(LocalDate date){
        return days.getDayIndex(date);
    }

    @Override
    public Scene getScene() {
        return view.constructScene();
    }

    @Override
    public void clearSlotViews() {
        view.clearViewSlots();
    }

    @Override
    public void addSlotView(Slot slot, Color backGroundColor, Consumer<Integer> actionOnClick) {
        SlotViewData slotViewData = new SlotViewData(slot.id(), slot.description(), slot.getSalleName(), slot.getEnseignantName(), slot.getGroupeName());
        Position position = getPositionOf(slot);
        SlotView slotView = viewElementFactory.createSlotView(slotViewData, backGroundColor);
        slotView.addEventHandler(MouseEvent.MOUSE_CLICKED, _ -> actionOnClick.accept(slot.id()));
        view.addSlotView(slotView,
                position.dayIndex()+1, position.intervalIndex()+1,
                1, position.numberOfIntervals());
    }


    @Override
    public void removeSlotView(int idSlot) {
        view.removeSlot(idSlot);
    }

    @Override
    public void updateDays(DayGenerator days) {
        clearSlotViews();
        view.clearLabelsInFirstRow();
        this.days = days;
        int dayColumnIndex = 1;
        for (LocalDate date : days) {
            Label label = viewElementFactory.createDateLabel(date);
            view.addLabelInFirstRow(label, dayColumnIndex);
            dayColumnIndex++;
        }

    }

    @Override
    public void updateTimeIntervals(TimeIntervalGenerator timeIntervals) {
        this.timeIntervals = timeIntervals;
        view.clearLabelsInFirstColumn();
        int intervalIndex = 1 ;
        for (TimeInterval timeInterval : timeIntervals){
            Label label = viewElementFactory.createTimeIntervalLabel(timeInterval);
            view.addLabelInFirstColumn(label, intervalIndex);
            intervalIndex++;
        }
    }

    public void updateButtons(List<ButtonConfiguration> buttonConfigurations) {
        HBox hBox = viewElementFactory.createButtonBox(buttonConfigurations);
        view.addButtonBoxInTopLeftCell(hBox);
    }
}
