package fr.univ_amu.m1info.client.viewer.controller;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class AdminView {
    private final VBox root;
    private final Scene scene;
    private final Button manageSallesButton;
    private final Button manageEnseignantsButton;
    private final Button manageEtudiantsButton;
    private final Button manageGroupesButton;

    private final Button launchCalendarButton;
    private final Label titleLabel;

    public AdminView() {
        root = new VBox(20);
        root.setAlignment(Pos.CENTER);

        titleLabel = new Label("Bienvenue sur l'ADE!");
        titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 50));
        titleLabel.setTextFill(Color.DARKOLIVEGREEN);

        // Création des boutons avec un style commun
        manageSallesButton = createStyledButton(" \u2699\uFE0F Gérer les salles");
        manageEnseignantsButton = createStyledButton(" \u2699\uFE0F Gérer les enseignants");
        manageEtudiantsButton = createStyledButton(" \u2699\uFE0F Gérer les etudiants");
        manageGroupesButton = createStyledButton(" \u2699\uFE0F Gérer les groupes");
        launchCalendarButton = createStyledButton("My Calendar");
        launchCalendarButton.setFont(Font.font("Roboto", 24));

        root.getChildren().addAll(titleLabel, manageSallesButton, manageEnseignantsButton,manageEtudiantsButton, manageGroupesButton,launchCalendarButton);
        scene = new Scene(root, 800, 800);
    }

    public Scene getScene() {
        return scene;
    }

    public void setOnManageSalles(Runnable action) {
        manageSallesButton.setOnAction(e -> action.run());
    }


    public void setOnManageEnseignants(Runnable action) {
        manageEnseignantsButton.setOnAction(e -> action.run());
    }

    public void setOnManageEtudiants(Runnable action) {manageEtudiantsButton.setOnAction(e -> action.run());}

    public void setOnManageGroupes(Runnable action) {manageGroupesButton.setOnAction(e -> action.run());}

    public void setOnLaunchCalendar(Runnable action) {
        launchCalendarButton.setOnAction(e -> action.run());
    }


    private Button createStyledButton(String text) {
        Button button = new Button(text);
        String defaultStyle = "-fx-font-weight: bold; -fx-font-size: 24px; -fx-text-fill: white; " +
                "-fx-background-color: #5e8357; -fx-border-color: #999; " +
                "-fx-border-radius: 5px; -fx-padding: 10px;";
        String hoverStyle = "-fx-font-weight: bold; -fx-font-size: 24px; -fx-text-fill: white; " +
                "-fx-background-color: #6fa26f; -fx-border-color: #999; " +
                "-fx-border-radius: 5px; -fx-padding: 10px;";
        button.setStyle(defaultStyle);
        button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
        button.setOnMouseExited(e -> button.setStyle(defaultStyle));
        return button;
    }
}
