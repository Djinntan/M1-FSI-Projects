package fr.univ_amu.m1info.client.service.dao;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.univ_amu.m1info.client.service.dao.exceptions.UnknownElementException;
import fr.univ_amu.m1info.client.service.dao.exceptions.WrongVersionException;
import fr.univ_amu.m1info.client.service.dto.CalendarDTO;
import fr.univ_amu.m1info.client.service.dto.SlotDTO;
import fr.univ_amu.m1info.client.service.dao.json.JsonBodyHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class SimpleCalendarServiceDAO implements CalendarServiceDAO {
    private static final String URL_SERVER = "http://localhost:8080/timeslots";
    private static final Logger logger = LogManager.getLogger(SimpleCalendarServiceDAO.class);

    private final HttpClient client;
    private final ObjectMapper objectMapper;

    public SimpleCalendarServiceDAO(HttpClient client) {
        this.client = client;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .enable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING)
                .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    private CalendarDTO getCalendarSlotBetween(LocalDate startDate, LocalDate endDate) {
        try{
            String calendarRequestUrl = "http://localhost:8080/calendar/request?start=" + startDate.toString() + "&end=" + endDate.toString();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(calendarRequestUrl))
                    .GET()
                    .build();
            try (HttpClient build = HttpClient.newBuilder().build()){
                HttpResponse<CalendarDTO> response = build
                        .send(request, new JsonBodyHandler<>(CalendarDTO.class));
                if (response.statusCode() == 200) {
                    return response.body();
                }
            }
        }
        catch (IOException | InterruptedException | URISyntaxException e){
            logger.error("Exception thrown", e);
        }
        return null;
    }
    @Override
    public Optional<SlotDTO> get(int key) throws UnknownElementException {
        logger.info("Getting calendar slot by key {}", key);
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + key))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                if (response.body().isEmpty()) {
                    logger.error(" Server returned 200 but body is empty.");
                    return Optional.empty();
                }
                SlotDTO slot = objectMapper.readValue(response.body(), SlotDTO.class);
                return Optional.of(slot);
            } else if (response.statusCode() == 404) {
                System.out.println("❌ [ERROR] Slot with ID " + key + " not found!");
                throw new UnknownElementException("Slot with ID " + key + " not found", key);
            } else {
                logger.error("Unexpected response status: {}", response.statusCode());
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Exception thrown while getting slot by key {}", key, e);
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }


    @Override
    public Collection<SlotDTO> getAllSlotsIn(LocalDate startDate, LocalDate endDate) {
        logger.info("Getting calendar slot between {} and {}", startDate, endDate);
        CalendarDTO slotDTO = getCalendarSlotBetween(startDate, endDate);
        if (slotDTO == null) {
            return List.of();
        }
        return slotDTO.calendarSlots();
    }


    @Override
    public int create(SlotDTO element) {
        logger.info("Creating calendar slot {}", element);
        try (HttpClient client = HttpClient.newHttpClient()){
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            String jsonBody = objectMapper.writeValueAsString(element);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 201) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode jsonNode = mapper.readTree(response.body());
                int id = jsonNode.path("id").asInt();

                logger.info("Successfully created SlotDTO with ID: {}", id);
                return id;
            } else if (response.statusCode() == 400) {
                logger.error("Bad Request: Invalid CalendarSlotDTO format. Response: {}", response.body());
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Error while creating slot", e);
        }
        return 0;
    }



    @Override
    public int update(SlotDTO element) throws UnknownElementException, WrongVersionException {
        logger.info("Updating calendar slot {}", element);

        int idEl = element.id();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            String jsonBody = objectMapper.writeValueAsString(element);

            try (HttpClient httpClient = HttpClient.newHttpClient()) {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI(URL_SERVER + "/" + idEl))
                        .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                        .header("Content-Type", "application/json")
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                switch (response.statusCode()) {
                    case 200 -> {
                        JsonNode jsonNode = objectMapper.readTree(response.body());
                        int id = jsonNode.path("id").asInt();
                        logger.info("Slot successfully updated with ID: {}", id);
                        return id;
                    }
                    case 404 -> throw new UnknownElementException("Slot with ID " + element.id() + " not found", element.id());
                    case 409 -> throw new WrongVersionException("Conflict when updating slot with ID " + element.id());
                    default -> logger.error("Failed to update slot. Status code: {}", response.statusCode());
                }
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Error while updating slot", e);
            throw new RuntimeException("Error while updating slot", e);
        }
        return 0;
    }

    @Override
    public void delete(SlotDTO element) throws UnknownElementException, WrongVersionException {
        logger.info("Deleting calendar slot {}", element);

        int idEl = element.id();

        try (HttpClient client = HttpClient.newHttpClient()) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER + "/" + idEl))
                    .DELETE()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            switch (response.statusCode()) {
                case 204:
                    logger.info("Slot with ID {} successfully deleted.", idEl);
                    break;
                case 400:
                    logger.error("Bad Request: Invalid ID {} for slot deletion.", idEl);
                    break;
                case 404:
                    throw new UnknownElementException("Slot with ID " + idEl + " not found", idEl);
                default:
                    logger.error("Failed to delete slot. Status code: {}", response.statusCode());
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("Error while deleting slot", e);
        }
    }


}
