package fr.univ_amu.m1info.client.model.simpleCalendar.simpleSlot;

import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.model.groupe.Groupe;
import fr.univ_amu.m1info.client.model.salle.Salle;

import java.time.Duration;
import java.time.LocalDateTime;

public record SimpleSlot(String description, LocalDateTime startDateTime, Duration duration, int id,
                         int versionNumber, Salle salle, Enseignant enseignant, Groupe groupe) implements Slot {

    @Override
    public LocalDateTime getEndDateTime() {
        return startDateTime.plus(duration);
    }


    public String getSalleName() {
        return salle != null ? salle.getNom() + " (" + salle.getBatiment() + ")" : "Aucune salle";
    }

    public String getEnseignantName() {
        return enseignant != null ? enseignant.getNom().toUpperCase() + " " + enseignant.getPrenom() : "Aucun prof";
    }

    public String getGroupeName() {
        return groupe != null ? groupe.getNom() : "Aucun groupe";
    }

}

