package fr.univ_amu.m1info.client.service.dto;

import java.time.LocalDateTime;

public record DateTimeInterval(LocalDateTime start, LocalDateTime end) {
}
