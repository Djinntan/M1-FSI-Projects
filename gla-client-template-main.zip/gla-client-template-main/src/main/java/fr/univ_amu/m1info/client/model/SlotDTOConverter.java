package fr.univ_amu.m1info.client.model;


import fr.univ_amu.m1info.client.service.dto.SlotDTO;

public interface SlotDTOConverter {
    Slot fromDTO(SlotDTO slotDTO);
    SlotDTO toDTO(Slot slot);
}
