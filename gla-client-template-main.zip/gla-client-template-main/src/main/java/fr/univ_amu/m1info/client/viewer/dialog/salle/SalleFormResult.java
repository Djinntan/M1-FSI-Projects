package fr.univ_amu.m1info.client.viewer.dialog.salle;
import fr.univ_amu.m1info.client.viewer.dialog.common.FormAction;

public record SalleFormResult(FormAction salleFormAction, SalleFormContent salleFormContent) {
}
