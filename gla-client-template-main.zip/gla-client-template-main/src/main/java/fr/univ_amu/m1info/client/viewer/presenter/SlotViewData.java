package fr.univ_amu.m1info.client.viewer.presenter;


public record SlotViewData(int id, String description, String salle, String enseignant, String groupe) {
}

