package fr.univ_amu.m1info.client.viewer.dialog.enseignant;

import javafx.scene.control.Dialog;

public interface EnseignantFormFactory {
    Dialog<EnseignantFormResult> createEnseignantManagementDialog();
}
