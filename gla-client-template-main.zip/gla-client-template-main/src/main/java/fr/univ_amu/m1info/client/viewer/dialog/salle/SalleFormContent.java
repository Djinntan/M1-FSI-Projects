package fr.univ_amu.m1info.client.viewer.dialog.salle;
import fr.univ_amu.m1info.client.model.salle.TypeSalle;

public record SalleFormContent(
        int id,
        String nom,
        String batiment,
        String campus,
        boolean videoProjecteur,
        int capacite,
        TypeSalle typeSalle
) {}
