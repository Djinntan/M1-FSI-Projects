package fr.univ_amu.m1info.client.service.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.univ_amu.m1info.client.service.dto.*;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Optional;


public class GroupeServiceDAO {
    private static final String URL_SERVER = "http://localhost:8080/groupes";
    private static final Logger logger = LogManager.getLogger(GroupeServiceDAO.class);

    private final HttpClient client;
    private final ObjectMapper objectMapper;
    public GroupeServiceDAO(HttpClient client) {
        this.client = client;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .enable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_ENUMS_USING_TO_STRING)
                .disable(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }
    public List<GroupeDTO> getAllGroupes() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return List.of(objectMapper.readValue(response.body(), GroupeDTO[].class));
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la récupération des groupes", e);
            return List.of();
        }
    }

    public boolean deleteGroupe(String nom) {
        // 🔍 Recherche de la groupe par ses informations
        Optional<GroupeDTO> groupeOpt = getAllGroupes().stream()
                .filter(groupe -> groupe.nom().equalsIgnoreCase(nom))
                .findFirst();

        if (groupeOpt.isPresent()) {
            int id = groupeOpt.get().id(); // ✅ Récupération de l'ID

            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(new URI(URL_SERVER + "/" + id)) // Suppression avec l'ID trouvé
                        .DELETE()
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                return response.statusCode() == 204;
            } catch (IOException | InterruptedException | URISyntaxException e) {
                logger.error("Erreur lors de la suppression de la groupe", e);
            }
        } else {
            logger.warn("Groupe '{}' non trouvée sur '{}' - '{}', suppression impossible.", nom);
        }
        return false;
    }


    public boolean createOrUpdateGroupe(GroupeDTO groupe) {
        try {
            // 🔍 First, check if the group already exists
            boolean groupeExists = getAllGroupes().stream()
                    .anyMatch(g -> g.nom().equalsIgnoreCase(groupe.nom()));

            // ✅ Debugging log
            logger.info("🔍 [DEBUG] Groupe '{}' exists? {}", groupe.nom(), groupeExists);

            // 🔍 If it exists, update it. Otherwise, create a new one.
            String jsonBody = objectMapper.writeValueAsString(groupe);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(URL_SERVER))
                    .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            return response.statusCode() == 200 || response.statusCode() == 201;
        } catch (IOException | InterruptedException | URISyntaxException e) {
            logger.error("❌ Erreur lors de la création/mise à jour du groupe", e);
            return false;
        }
    }


}
