package fr.univ_amu.m1info.client.model.groupe;

import fr.univ_amu.m1info.client.model.enseignant.Enseignant;
import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;

public class GroupeDTOConverter {
    public static Groupe fromDTO(GroupeDTO groupeDTO) {
        if (groupeDTO == null) return null;
        return new Groupe(
                groupeDTO.id(),
                groupeDTO.nom()
        );
    }

    public static GroupeDTO toGroupeDTO(Groupe groupe) {
        if (groupe == null) return null;
        return new GroupeDTO(
                groupe.getId(),
                groupe.getNom()
        );
    }
}
