package fr.univ_amu.m1info.client.model.salle;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum TypeSalle {
    TD, TP, AMPHITHEATRE;
    @JsonValue  // ✅ Convertit l'Enum en String lors de la sérialisation JSON
    public String toJson() {
        return name();
    }

    @JsonCreator  // ✅ Convertit la String JSON en Enum lors de la désérialisation
    public static TypeSalle fromJson(String value) {
        return TypeSalle.valueOf(value.toUpperCase()); // 🔄 Assure la correspondance (case insensitive)
    }
}