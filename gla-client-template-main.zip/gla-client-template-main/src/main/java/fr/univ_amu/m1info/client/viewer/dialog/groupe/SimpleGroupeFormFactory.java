package fr.univ_amu.m1info.client.viewer.dialog.groupe;
import javafx.scene.control.Dialog;

public class SimpleGroupeFormFactory implements GroupeFormFactory {
    private final GroupeFormBuilder formBuilder = new GroupeFormBuilder();

    @Override
    public Dialog<GroupeFormResult> createGroupeManagementDialog() {
        return formBuilder.reset()
                .buildTitle("Gestion des groupes")
                .buildHeader("Ajout, modification ou suppression d'un groupe")
                .buildCancelButton()
                .buildDeleteButton("Supprimer groupe")
                .buildConfirmButton("Enregistrer groupe")
                .getDialog();
    }
}
