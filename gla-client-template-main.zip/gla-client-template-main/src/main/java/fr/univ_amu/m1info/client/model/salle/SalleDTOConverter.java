package fr.univ_amu.m1info.client.model.salle;

import fr.univ_amu.m1info.client.service.dto.SalleDTO;

public class SalleDTOConverter {
    public static Salle fromDTO(SalleDTO salleDTO) {
        if (salleDTO == null) return null;
        return new Salle(
                salleDTO.id(),
                salleDTO.nom(),
                salleDTO.batiment(),
                salleDTO.campus(),
                salleDTO.videoProjecteur(),
                salleDTO.capacite(),
                salleDTO.typeSalle()
        );
    }

    public static SalleDTO toSalleDTO(Salle salle) {
        if (salle == null) return null;
        return new SalleDTO(
                salle.getId(),
                salle.getNom(),
                salle.getBatiment(),
                salle.getCampus(),
                salle.hasVideoProjecteur(),
                salle.getCapacite(),
                salle.getTypeSalle()
        );
    }
}
