package fr.univ_amu.m1info.client.viewer.configuration;

import fr.univ_amu.m1info.client.model.Calendar;
import fr.univ_amu.m1info.client.model.Slot;
import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.EtudiantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.util.DateInterval;
import fr.univ_amu.m1info.client.util.day.DayGenerator;
import fr.univ_amu.m1info.client.viewer.controller.AdminManagementController;
import fr.univ_amu.m1info.client.viewer.controller.CalendarViewController;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.SimpleEtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.SimpleGroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.manager.*;
import fr.univ_amu.m1info.client.viewer.dialog.SimpleSlotFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.slot.SlotFormFactory;
import fr.univ_amu.m1info.client.viewer.presenter.CalendarPresenter;
import fr.univ_amu.m1info.client.viewer.presenter.PeriodCalendarPresenter;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.SimpleEnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SimpleSalleFormFactory;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.http.HttpClient;
import java.time.LocalDate;
import java.util.Collection;

public class PeriodCalendarViewController implements CalendarViewController {
    private final CalendarPresenter calendarPresenter;
    private final CalendarViewConfiguration config;
    private DayGenerator dayGenerator;
    private final SlotManager slotManager;
    private final AdminManagementController adminController;
    private Stage stage;

    public PeriodCalendarViewController(Calendar calendar, CalendarViewConfiguration config, Stage stage) {
        this.config = config;
        this.stage = stage;
        HttpClient httpClient = HttpClient.newHttpClient();

        // Initialize dependencies
        SalleServiceDAO salleDAO = new SalleServiceDAO(httpClient);
        EnseignantServiceDAO enseignantDAO = new EnseignantServiceDAO(httpClient);
        EtudiantServiceDAO etudiantDAO = new EtudiantServiceDAO(httpClient);
        GroupeServiceDAO groupeDAO = new GroupeServiceDAO(httpClient);

        SlotFormFactory slotFormFactory = new SimpleSlotFormFactory(
                config.getTimeIntervalGenerator().getStartTimesOfIntervals(),
                config.getPossibleDurations().getDurations(),
                salleDAO,
                enseignantDAO,
                groupeDAO
        );

        // Initialiser le dayGenerator et le passer ensuite au presenter
        this.dayGenerator = createDayGenerator(config.getPeriodStartDateContaining(LocalDate.now()));
        this.calendarPresenter = new PeriodCalendarPresenter(
                this,
                dayGenerator,
                config.getTimeIntervalGenerator()
        );

        // Create managers
        this.slotManager = new SlotManager(
                calendar, salleDAO, slotFormFactory,
                calendarPresenter, config,enseignantDAO
        );
        EnseignantManager enseignantManager = new EnseignantManager(enseignantDAO, new SimpleEnseignantFormFactory());
        SalleManager salleManager = new SalleManager(salleDAO, new SimpleSalleFormFactory());
        EtudiantManager etudiantManager = new EtudiantManager(etudiantDAO, new SimpleEtudiantFormFactory());
        GroupeManager groupeManager = new GroupeManager(groupeDAO, new SimpleGroupeFormFactory());

        refreshSlots();
        this.adminController = new AdminManagementController(salleManager, enseignantManager,etudiantManager,groupeManager);
    }


    @Override
    public void handleNext() {
        updateStartDate(dayGenerator.getStartDate().plus(config.getTotalPeriod()));
        refreshSlots();
    }

    @Override
    public void handlePrevious() {
        updateStartDate(dayGenerator.getStartDate().minus(config.getTotalPeriod()));
        refreshSlots();
    }

    private void updateStartDate(LocalDate newStartDate) {
        dayGenerator = createDayGenerator(newStartDate);
        calendarPresenter.updateDays(dayGenerator);
        slotManager.refreshSlots(dayGenerator.getStartDate(), dayGenerator.getEndDate());
    }

    private DayGenerator createDayGenerator(LocalDate startDate) {
        LocalDate endDate = startDate.plus(config.getPrintablePeriod());
        return new DayGenerator(new DateInterval(startDate, endDate));
    }

    @Override
    public void handleSlotEdition(int idSlot) {
        slotManager.handleSlotEdition(idSlot);
        refreshSlots();
    }

    @Override
    public void handleSlotCreation() {
        slotManager.handleSlotCreation();
        refreshSlots();
    }

    @Override
    public Scene getScene() {
        calendarPresenter.updateDays(dayGenerator);
        calendarPresenter.updateTimeIntervals(config.getTimeIntervalGenerator());
        slotManager.refreshSlots(dayGenerator.getStartDate(), dayGenerator.getEndDate());
        refreshSlots();
        return calendarPresenter.getScene();
    }

    public void handleAdminManagement() {
        adminController.showAdminView(stage);
    }

    private void addSlotToView(Slot slot) {
        if (dayGenerator.getDayIndex(slot.startDateTime().toLocalDate()) == -1)
            return;
        slotManager.slotsById.put(slot.id(), slot);
        calendarPresenter.addSlotView(slot, config.colorOfSlots(), this::handleSlotEdition);
    }

    public void refreshSlots() {
        slotManager.slotsById.clear();
        calendarPresenter.clearSlotViews();
        Collection<Slot> slots = slotManager.calendar.getAllSlotsBetween(dayGenerator.getStartDate(),
                dayGenerator.getEndDate().minusDays(1));
        for (Slot slot : slots) {
            addSlotToView(slot);
        }
    }

}
