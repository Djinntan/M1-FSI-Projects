package fr.univ_amu.m1info.client.viewer;

import fr.univ_amu.m1info.client.service.dao.EnseignantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.EtudiantServiceDAO;
import fr.univ_amu.m1info.client.service.dao.GroupeServiceDAO;
import fr.univ_amu.m1info.client.service.dao.SalleServiceDAO;
import fr.univ_amu.m1info.client.viewer.controller.AdminManagementController;
import fr.univ_amu.m1info.client.viewer.dialog.enseignant.SimpleEnseignantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.etudiant.SimpleEtudiantFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.groupe.SimpleGroupeFormFactory;
import fr.univ_amu.m1info.client.viewer.dialog.salle.SimpleSalleFormFactory;
import javafx.application.Application;
import javafx.stage.Stage;

import java.net.http.HttpClient;

public class CalendarApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        HttpClient httpClient = HttpClient.newHttpClient(); // Create a shared instance
        AdminManagementController adminController = new AdminManagementController(
                new SalleServiceDAO(httpClient),
                new EnseignantServiceDAO(httpClient),
                new EtudiantServiceDAO(httpClient),
                new GroupeServiceDAO(httpClient),
                new SimpleSalleFormFactory(),
                new SimpleEnseignantFormFactory(),
                new SimpleEtudiantFormFactory(),
                new SimpleGroupeFormFactory()
        );
        adminController.showAdminView(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

