package fr.univ_amu.m1info.client.viewer.dialog;

import fr.univ_amu.m1info.client.service.dto.SalleDTO;
import javafx.util.StringConverter;

public class SalleDTOStringConverter extends StringConverter<SalleDTO> {
    @Override
    public String toString(SalleDTO salle) {
        if (salle == null) {
            return "Aucune salle";
        }
        return salle.nom() + " - " + salle.batiment() + " - " + salle.campus();
    }

    @Override
    public SalleDTO fromString(String string) {
        return null; // Non utilisé car on sélectionne un élément dans la ComboBox
    }
}
