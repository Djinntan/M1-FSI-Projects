package fr.univ_amu.m1info.client.viewer.dialog;

import fr.univ_amu.m1info.client.service.dto.EnseignantDTO;
import fr.univ_amu.m1info.client.service.dto.GroupeDTO;
import javafx.util.StringConverter;

public class GroupeDTOStringConverter extends StringConverter<GroupeDTO> {
    @Override
    public String toString(GroupeDTO groupe) {
        if (groupe == null) {
            return "Aucun groupe";
        }
        return groupe.nom() ;
    }

    @Override
    public GroupeDTO fromString(String string) {
        return null; // Non utilisé car on sélectionne un élément dans la ComboBox
    }}