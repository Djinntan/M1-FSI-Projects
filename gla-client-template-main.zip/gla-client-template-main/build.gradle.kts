plugins {
    id("java")
    id("application")
    id("org.openjfx.javafxplugin") version "0.1.0"
    id("jacoco")

}

group = "fr.univ_amu.m1info"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

application {
    mainModule.set("fr.univ_amu.m1info.client")
    mainClass.set("fr.univ_amu.m1info.client.viewer.CalendarApp")

}

javafx {
    version = "23.0.1"
    modules = listOf("javafx.controls", "javafx.fxml")
}

dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.11.4")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.11.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testImplementation("org.assertj:assertj-core:3.27.0")
    implementation("org.apache.logging.log4j:log4j-api:2.24.3")
    implementation("org.apache.logging.log4j:log4j-core:2.24.3")
    implementation("com.fasterxml.jackson.core:jackson-databind:2.18.1")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.18.1")
    implementation("org.jetbrains:annotations:26.0.1")

    testImplementation("org.mockito:mockito-core:5.15.2") //added mockito core
    testImplementation ("org.junit.jupiter:junit-jupiter:5.9.2")
    testImplementation ("org.mockito:mockito-inline:5.0.0") //mockito inline (différences dans final...etc)
    testImplementation ("io.javalin:javalin-testtools:6.4.0") //added testools
    testImplementation ("org.mockito:mockito-junit-jupiter:5.7.0") //Mockito specifique a Junit5
    testImplementation ("com.github.tomakehurst:wiremock-jre8:2.35.0")
    testImplementation("org.assertj:assertj-core:3.24.2")
    testImplementation("org.mockito:mockito-core:5.7.0")
    implementation ("org.slf4j:slf4j-api:2.0.9")
    implementation ("ch.qos.logback:logback-classic:1.4.11")
    testImplementation ("org.springframework:spring-test:5.3.30")
}

tasks.test {
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
}
tasks.jacocoTestReport {
    dependsOn(tasks.test)
}


