import pulp

def solve_cutting_stock():
    # Exemple simplifié de problème de découpe
    widths = [45, 36, 31, 14]
    demands = [97, 610, 395, 211]
    r = 100  # largeur initiale

    # Créer un problème de minimisation
    prob = pulp.LpProblem("CuttingStock", pulp.LpMinimize)

    # Variables de décision (xj, le nombre de fois qu'un motif est utilisé)
    x = [pulp.LpVariable(f"x{i}", lowBound=0, cat='Integer') for i in range(20)]  # Match size of a's sublists

    # Coefficients de la matrice de contraintes
    a = [
        [2, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],  # a1j
        [0, 1, 1, 0, 0, 0, 0, 0, 0, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1],  # a2j
        [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 2, 1, 1, 1, 0, 0, 0, 0],  # a3j
        [0, 1, 0, 1, 0, 3, 2, 1, 0, 2, 1, 0, 0, 2, 1, 0, 4, 3, 2, 1],  # a4j
    ]

    # Contrainte Ax = b
    for i in range(4):
        prob += pulp.lpSum([a[i][j] * x[j] for j in range(len(a[i]))]) == demands[i]  # Use actual size of a[i]

    # Fonction objectif (minimiser la somme des xj)
    prob += pulp.lpSum(x)

    # Résoudre le problème
    prob.solve()

    # Extraire et retourner les résultats
    result = [pulp.value(var) for var in x]
    return result

if __name__ == "__main__":
    result = solve_cutting_stock()
    print(result)
