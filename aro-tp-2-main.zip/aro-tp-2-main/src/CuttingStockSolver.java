import java.io.*;

public class CuttingStockSolver {

    public static void main(String[] args) {
        try {
            // Commande pour exécuter le script Python
            String command = "python src/cutting_stock.py";

            // Exécuter le script avec ProcessBuilder
            ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            // Lire la sortie du script Python
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);  // Afficher la sortie du script
            }

            // Attendre que le processus se termine
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
