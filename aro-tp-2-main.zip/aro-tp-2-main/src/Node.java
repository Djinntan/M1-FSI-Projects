import java.util.ArrayList;
import java.util.List;

public class Node {
    private final int weight, value, level;
    private final double bound;
    private final List<Loot> takenItems;

    public Node(int weight, int value, int level, double bound) {
        this.weight = weight;
        this.value = value;
        this.level = level;
        this.bound = bound;
        this.takenItems = new ArrayList<>();
    }

    public int getWeight() {
        return weight;
    }

    public int getValue() {
        return value;
    }

    public int getLevel() {
        return level;
    }

    public double getBound() {
        return bound;
    }

    public List<Loot> getTakenItems() {
        return takenItems;
    }
}
