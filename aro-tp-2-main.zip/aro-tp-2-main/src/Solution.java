import java.util.List;

public class Solution {
    private final int value;
    private final List<Loot> items;

    public Solution(int value, List<Loot> items) {
        this.value = value;
        this.items = items;
    }

    public int getValue() {
        return value;
    }

    public List<Loot> getItems() {
        return items;
    }
}