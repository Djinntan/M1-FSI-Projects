import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class InstanceReader {

    public Backpack read(String filename) throws Exception {
        File file = new File(filename);
        List<Loot> loots = new ArrayList<>();
        BufferedReader buffer = new BufferedReader(new FileReader(file));
        int capacity = Integer.parseInt(buffer.readLine());
        Stream<String> lines = buffer.lines();

        lines.forEach(s -> {
            String[] line = s.split(" ");
            loots.add(new Loot(Integer.parseInt(line[0]), Integer.parseInt(line[1])));
        });

        buffer.close();
        return new Backpack(capacity, loots);
    }
}