import java.util.*;

public class BranchAndBoundSolver {
    private final Backpack backpack;

    public BranchAndBoundSolver(Backpack backpack) {
        this.backpack = backpack;
    }

    public Solution solve() {
        List<Loot> items = backpack.getLoots();
        items.sort(Comparator.comparingDouble(Loot::getRatio).reversed());

        PriorityQueue<Node> queue = new PriorityQueue<>(Comparator.comparingDouble(Node::getBound).reversed());
        Node root = new Node(0, 0, 0, calculateBound(0, 0, 0, items));
        queue.add(root);

        int maxValue = 0;
        List<Loot> bestItems = new ArrayList<>();

        while (!queue.isEmpty()) {
            Node current = queue.poll();

            if (current.getBound() <= maxValue) continue;

            if (current.getLevel() < items.size()) {
                Loot currentItem = items.get(current.getLevel());

                // Left child (include the item)
                if (current.getWeight() + currentItem.getWeight() <= backpack.getCapacity()) {
                    int newValue = current.getValue() + currentItem.getValue();
                    int newWeight = current.getWeight() + currentItem.getWeight();
                    Node leftChild = new Node(newWeight, newValue, current.getLevel() + 1,
                            calculateBound(newWeight, newValue, current.getLevel() + 1, items));
                    leftChild.getTakenItems().addAll(current.getTakenItems());
                    leftChild.getTakenItems().add(currentItem);

                    if (newValue > maxValue) {
                        maxValue = newValue;
                        bestItems = leftChild.getTakenItems();
                    }

                    queue.add(leftChild);
                }

                // Right child (exclude the item)
                Node rightChild = new Node(current.getWeight(), current.getValue(), current.getLevel() + 1,
                        calculateBound(current.getWeight(), current.getValue(), current.getLevel() + 1, items));
                rightChild.getTakenItems().addAll(current.getTakenItems());
                queue.add(rightChild);
            }
        }

        return new Solution(maxValue, bestItems);
    }

    private double calculateBound(int weight, int value, int level, List<Loot> items) {
        if (weight >= backpack.getCapacity()) return 0;

        double bound = value;
        int remainingCapacity = backpack.getCapacity() - weight;

        for (int i = level; i < items.size() && remainingCapacity > 0; i++) {
            Loot item = items.get(i);
            if (item.getWeight() <= remainingCapacity) {
                bound += item.getValue();
                remainingCapacity -= item.getWeight();
            } else {
                bound += item.getRatio() * remainingCapacity;
                break;
            }
        }

        return bound;
    }
}

