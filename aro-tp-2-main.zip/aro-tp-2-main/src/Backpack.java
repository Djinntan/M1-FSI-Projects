import java.util.List;


public class Backpack {
    int capacity;
    List<Loot> loots;

    public Backpack(int capacity, List<Loot> loots) {
        this.capacity = capacity;
        this.loots = loots;
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Loot> getLoots() {
        return loots;
    }

    public String toString() {
        return capacity + "\n" + loots;
    }
}