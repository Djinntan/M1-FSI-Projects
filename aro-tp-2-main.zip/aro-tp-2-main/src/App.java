

public class App {
    public static void main(String[] args) throws Exception {
        for (int i = 0; i < 8; i++) {
            String filename = "src/sac" + i;
            Backpack backpack = new InstanceReader().read(filename);
            BranchAndBoundSolver solver = new BranchAndBoundSolver(backpack);
            Solution solution = solver.solve();
            System.out.println("File: " + filename);
            System.out.println("Optimal Value: " + solution.getValue());
            System.out.println("Items taken: " + solution.getItems());
            System.out.println();
        }
    }
}