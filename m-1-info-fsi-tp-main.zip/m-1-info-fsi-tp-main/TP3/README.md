# TP 1 : tests boîte noire

Les exécutables à tester sont dans le répertoire `executables`.
Les fichiers images correspondant au cas de test sont à mettre dans le répertoire `ìmages`.


Pour lancer les tests, il suffit d'utiliser la commande :

```bash
gradle run
```
