# TP 2 : tests unitaires et couverture de test

Les commandes gradle les plus utiles :

- `gradle test` pour lancer les tests (rapports dans `build/reports/tests/test`),
- `gradle jacocoTestReport` pour lancer la couverture de code via l'outil [Jacoco](https://www.eclemma.org/jacoco/) (rapport accessible en html à `build/reports/jacoco/test/html/index.html`). 

Le fichier `build.gradle` contient la configuration du projet avec notamment la définition de la classe contenant la méthode `main` à exécuter pour l'application.


## Membre(s) du projet

- NOM, prénom du premier membre du projet
- NOM, prénom du deuxième membre du projet (optionnel)
