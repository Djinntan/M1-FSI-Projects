package deque;

import java.util.NoSuchElementException;

public class ArrayDoubleEndedQueue<E> implements DoubleEndedQueue<E> {
    private final Object[] elements;
    private final int capacity;
    private int indexFirst;
    private int size;

    public ArrayDoubleEndedQueue(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be greater than 0.");
        }
        this.capacity = capacity;
        this.elements = new Object[capacity];
        this.indexFirst = 0;
        this.size = 0;
    }

    @Override
    public void addFirst(E e) {
        if (e == null) throw new NullPointerException("Element cannot be null.");
        if (size == capacity) throw new IllegalStateException("Queue is full.");

        indexFirst = (indexFirst - 1 + capacity) % capacity;
        elements[indexFirst] = e;
        size++;
    }

    @Override
    public void addLast(E e) {
        if (e == null) throw new NullPointerException("Element cannot be null.");
        if (size == capacity) throw new IllegalStateException("Queue is full.");

        int indexLast = (indexFirst + size) % capacity;
        elements[indexLast] = e;
        size++;
    }

    @Override
    public E removeFirst() {
        if (size == 0) throw new NoSuchElementException("Queue is empty.");

        @SuppressWarnings("unchecked")
        E element = (E) elements[indexFirst];
        elements[indexFirst] = null;
        indexFirst = (indexFirst + 1) % capacity;
        size--;
        return element;
    }

    @Override
    public E removeLast() {
        if (size == 0) throw new NoSuchElementException("Queue is empty.");

        int indexLast = (indexFirst + size - 1) % capacity;
        @SuppressWarnings("unchecked")
        E element = (E) elements[indexLast];
        elements[indexLast] = null;
        size--;
        return element;
    }

    @Override
    public E getFirst() {
        if (size == 0) throw new NoSuchElementException("Queue is empty.");

        return (E) elements[indexFirst];
    }

    @Override
    public E getLast() {
        if (size == 0) throw new NoSuchElementException("Queue is empty.");

        int indexLast = (indexFirst + size - 1) % capacity;
        return (E) elements[indexLast];
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean contains(Object o) {
        if (o == null) throw new NullPointerException("Element cannot be null.");

        for (int i = 0; i < size; i++) {
            int index = (indexFirst + i) % capacity;
            if (elements[index].equals(o)) {
                return true;
            }
        }
        return false;
    }
}
