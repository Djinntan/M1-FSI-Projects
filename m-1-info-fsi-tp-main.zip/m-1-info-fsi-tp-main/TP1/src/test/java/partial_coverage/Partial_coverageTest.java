package partial_coverage;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class Partial_coverageTest {
    static PartialCoverage p;
    @BeforeAll
    static void PartialCoverageSetup(){
        p = new PartialCoverage();
    }

    @Test
    void testReturnZeroOrOne (){
        /*On ne peux explorer les autres branches sans changer
         la logique de la méthode mere*/
        assertThat(p.returnZeroOrOne(10,10)).isEqualTo(0);
    }
}
