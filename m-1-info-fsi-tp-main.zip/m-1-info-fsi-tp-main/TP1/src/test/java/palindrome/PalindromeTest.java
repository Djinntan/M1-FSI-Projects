package palindrome;

import org.junit.jupiter.api.*;

import static org.assertj.core.api.Assertions.assertThat;

public class PalindromeTest {
    private static Palindrome palindrome;
  @BeforeAll
 static void testConstructor() {palindrome= new Palindrome();}
  @Test
  void testEmptyString() {
    assertThat(Palindrome.isPalindrome("")).isTrue();
  }

  @Test
  void testEvenLengthFalse() {
    assertThat(Palindrome.isPalindrome("abcd")).isFalse();
  }

  @Test
  void testEvenLengthTrue() {
    assertThat(Palindrome.isPalindrome("abba")).isTrue();
  }
  @Test
  void testOddLengthTrue() {
    assertThat(Palindrome.isPalindrome("aba")).isTrue();
  }
}
