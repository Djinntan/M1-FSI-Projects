package deque;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

public class ArrayDoubleEndedQueTest {

    @Test
    public void testConstructorWithInvalidCapacity() {
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> new ArrayDoubleEndedQueue<>(0),
                "Expected to throw IllegalArgumentException when capacity <= 0"
        );
        assertEquals("Capacity must be greater than 0.", exception.getMessage());
    }

    @Test
    public void testAddFirstWithNullElement() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NullPointerException exception = assertThrows(
                NullPointerException.class,
                () -> deque.addFirst(null),
                "Expected to throw NullPointerException when adding null to the front"
        );
        assertEquals("Element cannot be null.", exception.getMessage());
    }

    @Test
    public void testAddLastWithNullElement() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NullPointerException exception = assertThrows(
                NullPointerException.class,
                () -> deque.addLast(null),
                "Expected to throw NullPointerException when adding null to the end"
        );
        assertEquals("Element cannot be null.", exception.getMessage());
    }

    @Test
    public void testAddFirstWhenQueueIsFull() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(2);
        deque.addFirst("A");
        deque.addFirst("B");
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> deque.addFirst("C"),
                "Expected to throw IllegalStateException when adding to a full queue"
        );
        assertEquals("Queue is full.", exception.getMessage());
    }

    @Test
    public void testAddLastWhenQueueIsFull() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(2);
        deque.addLast("A");
        deque.addLast("B");
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> deque.addLast("C"),
                "Expected to throw IllegalStateException when adding to a full queue"
        );
        assertEquals("Queue is full.", exception.getMessage());
    }

    @Test
    public void testRemoveFirstWhenQueueIsEmpty() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NoSuchElementException exception = assertThrows(
                NoSuchElementException.class,
                deque::removeFirst,
                "Expected to throw NoSuchElementException when removing from an empty queue"
        );
        assertEquals("Queue is empty.", exception.getMessage());
    }

    @Test
    public void testRemoveLastWhenQueueIsEmpty() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NoSuchElementException exception = assertThrows(
                NoSuchElementException.class,
                deque::removeLast,
                "Expected to throw NoSuchElementException when removing from an empty queue"
        );
        assertEquals("Queue is empty.", exception.getMessage());
    }

    @Test
    public void testContainsWithNullElement() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NullPointerException exception = assertThrows(
                NullPointerException.class,
                () -> deque.contains(null),
                "Expected to throw NullPointerException when searching for null"
        );
        assertEquals("Element cannot be null.", exception.getMessage());
    }

    @Test
    public void testContainsWithExistingElement() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        deque.addFirst("A");
        deque.addLast("B");
        assertTrue(deque.contains("A"), "Queue should contain element 'A'");
        assertTrue(deque.contains("B"), "Queue should contain element 'B'");
    }

    @Test
    public void testContainsWithNonExistingElement() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        deque.addFirst("A");
        deque.addLast("B");
        assertFalse(deque.contains("C"), "Queue should not contain element 'C'");
    }

    @Test
    public void testGetFirst() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        deque.addFirst("A");
        deque.addFirst("B");
        assertEquals("B", deque.getFirst(), "getFirst() should return the first element 'B'");
        deque.removeFirst();
        assertEquals("A", deque.getFirst(), "getFirst() should return the next first element 'A'");
    }

    @Test
    public void testGetFirstWhenQueueIsEmpty() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NoSuchElementException exception = assertThrows(
                NoSuchElementException.class,
                deque::getFirst,
                "Expected to throw NoSuchElementException when getting first element from empty queue"
        );
        assertEquals("Queue is empty.", exception.getMessage());
    }

    @Test
    public void testGetLast() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        deque.addLast("A");
        deque.addLast("B");
        assertEquals("B", deque.getLast(), "getLast() should return the last element 'B'");
        deque.removeLast();
        assertEquals("A", deque.getLast(), "getLast() should return the next last element 'A'");
    }

    @Test
    public void testGetLastWhenQueueIsEmpty() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        NoSuchElementException exception = assertThrows(
                NoSuchElementException.class,
                deque::getLast,
                "Expected to throw NoSuchElementException when getting last element from empty queue"
        );
        assertEquals("Queue is empty.", exception.getMessage());
    }

    @Test
    public void testSize() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        assertEquals(0, deque.size(), "Initial size should be 0");
        deque.addFirst("A");
        assertEquals(1, deque.size(), "Size should be 1 after adding an element");
        deque.addLast("B");
        assertEquals(2, deque.size(), "Size should be 2 after adding another element");
        deque.removeFirst();
        assertEquals(1, deque.size(), "Size should be 1 after removing an element");
        deque.removeLast();
        assertEquals(0, deque.size(), "Size should be 0 after removing all elements");
    }

    @Test
    public void testMixedOperations() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(5);
        deque.addFirst("A");
        deque.addLast("B");
        deque.addFirst("C");
        assertEquals("C", deque.getFirst(), "getFirst() should return 'C'");
        assertEquals("B", deque.getLast(), "getLast() should return 'B'");
        deque.removeFirst();
        deque.removeLast();
        assertEquals(1, deque.size(), "Size should be 1 after removing two elements");
    }

    @Test
    public void testCapacityWrapAround() {
        ArrayDoubleEndedQueue<String> deque = new ArrayDoubleEndedQueue<>(3);
        deque.addLast("A");
        deque.addLast("B");
        deque.addLast("C");
        deque.removeFirst(); // Removes "A"
        deque.addLast("D");
        assertEquals("B", deque.getFirst(), "getFirst() should return 'B' after wrap-around");
        assertEquals("D", deque.getLast(), "getLast() should return 'D' after wrap-around");
        assertEquals(3, deque.size(), "Size should be 3 after wrap-around operations");
    }
}
