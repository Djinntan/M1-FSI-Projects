package complex;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.time.Duration;


/**
 * Test class for the complex class.
 */

class ComplexTest {
    private static final float EPSILON = 0.000001F;
    private static Complex z1;
    private static Complex z2;
    private static Complex z3;
    private static Complex z4;
    private static Complex z;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
        // TODO: add message
        System.out.println("Setup Class runs");
        z1 = new Complex(1.0F, 2.0f);
        z2 = new Complex(3.0F, 4.0F);
        z3 = new Complex(0.0F, 0.0F);
        z4 = new Complex(1.0F, 1.0F);
        z = new Complex();
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
        // TODO: add message
        System.out.println("Teardown Class runs");

    }

    @BeforeEach
    void setUp() throws Exception {
        // TODO: add message
        System.out.println("Setup runs");
    }


    @AfterEach
    void tearDown() throws Exception {
        // TODO: add message
        System.out.println("Teardown runs");

    }

    @Test
    void testGetterImaginary() {

        float expected = 2.0F;
        assertThat(z1.getImaginaryPart()).as("problem on getter imaginary")
                .isCloseTo(expected, within(EPSILON));

    }

    @Test
    void testGetterReal() {

        float expected = 1.0F;

        assertThat(z1.getRealPart()).as("problem on getter real")
                .isCloseTo(expected, within(EPSILON));

    }

    @Test
    void testSetterImaginary() {

        float expected = 3.0F;
        z.setImaginaryPart(expected);
        assertThat(z.getImaginaryPart()).as("problem on setter imaginary")
                .isCloseTo(expected, within(EPSILON));

    }


    @Test
    void testSetterReal() {

        float expected = 3.0F;
        Complex z = new Complex();
        z.setRealPart(expected);
        assertThat(z.getRealPart()).as("problem on setter real")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testZeroTrue() {
        assertThat(z3.isZero()).as("problem with isZero on Zero Complex number")
                .isTrue();
    }

    @Test
    void testZeroFalse() {
        assertThat(z4.isZero()).as("problem with isZero on non Zero Complex number")
                .isFalse();
    }

    @Test
    void testNearZeroImaginary() //Couvre en plus la derniere branche de la ligne booléenne de is Zero
    {
        Complex z0 = new Complex();
        z0.setImaginaryPart(EPSILON * 2);
        z0.setRealPart(0.0F);
        assertThat(z0.isZero()).as("").isFalse();
    }

    @Test
    void testSumReal() {
        float expected = 1.0F + 3.0F;

        Complex z = z1.sum(z2);
        assertThat(z.getRealPart()).as("problem with real part of Sum")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testInverseIllegalArg() { //Test en plus la ligne if iszero throws illegal argument
        assertThrows(IllegalArgumentException.class, () -> {
            z3.inverse();
        });
    }

    @Test
    void testSumImaginary() {

        float expected = 2.0F + 4.0F;
        Complex z = z1.sum(z2);
        assertThat(z.getImaginaryPart()).as("problem with imaginary part of Sum")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testinverserealpart() {
        float square_norm = 1.0F * 1.0F + 2.0F * 2.0F;
        float expected = 1.0F / square_norm;
        z = z1.inverse();
        assertThat(z.getRealPart()).as("problem with real part of inverse")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testinverseimaginarypart() {
        float square_norm = 1.0F * 1.0F + 2.0F * 2.0F;
        float expected = -2.0F / square_norm;
        z = z1.inverse();
        assertThat(z.getImaginaryPart()).as("problem with real part of inverse")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testProductReal() {

        float expected = 1.0F * 3.0F - 2.0F * 4.0F;

        Complex z = z1.product(z2);
        assertThat(z.getRealPart()).as("problem with real part of Product")
                .isCloseTo(expected, within(EPSILON));

    }

    @Test
    void testProductImaginary() {

        float expected = 1.0F * 4.0F + 2.0F * 3.0F;

        Complex z = z1.product(z2);
        assertThat(z.getImaginaryPart()).as("problem with imaginary part of Product")
                .isCloseTo(expected, within(EPSILON));
    }

    @Test
    void testToString() {
        String expected = "1.0+i2.0";
        String complex = z1.toString();
        assertThat(complex).as("Problem with both imaginary part and real of complex").isEqualTo(expected);
    }

    @Disabled
    final void testTimeoutInfinite() { //il est impossible de tester cette méthode ainsi nous avons preferé désactiver le test
        try {
            assertTimeoutPreemptively(Duration.ofMillis(100), () -> Complex.infinite());
        } catch (Exception e) {
            fail("NYI");
        }
    }
}
