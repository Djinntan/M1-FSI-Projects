package authentication;

public interface DirectoryInterface {
    String getMatch(String identity);
}