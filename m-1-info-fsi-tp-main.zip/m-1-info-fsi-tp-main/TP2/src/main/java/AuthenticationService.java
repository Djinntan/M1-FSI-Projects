/*package authentication;
package interfacemanualmocking;

public interface AuthenticationService {
    boolean isAMatch(String identity, String authenticationData);
    Strength dataStrength(String authenticationData);
}*/