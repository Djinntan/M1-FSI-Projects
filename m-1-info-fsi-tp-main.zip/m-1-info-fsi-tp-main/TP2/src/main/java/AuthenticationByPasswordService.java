/*package authentication;
package interfacemanualmocking;

public interface AuthenticationService {
    boolean isAMatch(String identity, String authenticationData);
    Strength dataStrength(String authenticationData);
}

// Classe AuthenticationByPasswordService
public class AuthenticationByPasswordService implements AuthenticationService {
    private final DirectoryInterface directory;
    private final StrengthEstimationServiceInterface strengthService;

    public AuthenticationByPasswordService(DirectoryInterface directory, StrengthEstimationServiceInterface strengthService) {
        this.directory = directory;
        this.strengthService = strengthService;
    }

    @Override
    public boolean isAMatch(String identity, String authenticationData) {
        return authenticationData.equals(directory.getMatch(identity));
    }

    @Override
    public Strength dataStrength(String authenticationData) {
        int bitLength = strengthService.equivalentBitLength(authenticationData.length(), authenticationData.length());
        if (bitLength < 50) return Strength.VERY_WEAK;
        if (bitLength < 80) return Strength.WEAK;
        if (bitLength < 100) return Strength.REGULAR;
        return Strength.STRONG;
    }
}*/