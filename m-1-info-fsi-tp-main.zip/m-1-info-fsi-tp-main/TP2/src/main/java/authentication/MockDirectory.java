package authentication;

public class MockDirectory implements authentication.DirectoryInterface {
    @Override
    public String getMatch(String identity) {
        if (identity == null) throw new IllegalArgumentException("Identity cannot be null");
        return "mockPassword"; // Valeur factice pour les tests
    }
}