/*package authentication;

import authentication.AuthenticationService;

public class AuthenticationByBiometryService implements AuthenticationService {
    private final DirectoryInterface directory;
    private final Strength strength;

    public AuthenticationByBiometryService(DirectoryInterface directory, Strength strength) {
        this.directory = directory;
        this.strength = strength;
    }

    @Override
    public boolean isAMatch(String identity, String authenticationData) {
        return authenticationData.equals(directory.getMatch(identity));
    }

    @Override
    public Strength dataStrength(String authenticationData) {
        return this.strength;
    }
}*/