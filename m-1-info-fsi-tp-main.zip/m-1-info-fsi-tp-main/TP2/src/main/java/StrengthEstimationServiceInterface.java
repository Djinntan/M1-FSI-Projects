/*package authentication;
package interfacemanualmocking;

public interface StrengthEstimationServiceInterface {
    int equivalentBitLength(int alphabetSize, int dataSize);
}*/