/*package authentication;
package interfacemanualmocking;

public class MockStrengthEstimationService implements StrengthEstimationServiceInterface {
    @Override
    public int equivalentBitLength(int alphabetSize, int dataSize) {
        return 75; // Valeur factice pour simuler une force "WEAK"
    }
}*/