package authentication;
public enum Strength {
    VERY_WEAK,
    WEAK,
    REGULAR,
    STRONG;
}