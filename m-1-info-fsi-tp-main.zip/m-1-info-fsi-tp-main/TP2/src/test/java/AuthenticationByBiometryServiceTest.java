/*package tests;

import authentication.AuthenticationByBiometryService;
import authentication.DirectoryInterface;
import authentication.Strength;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AuthenticationByBiometryServiceTest {

    @Test
    void testIsAMatch() {
        DirectoryInterface mockDirectory = mock(DirectoryInterface.class);

        when(mockDirectory.getMatch("user1")).thenReturn("mockPassword");

        AuthenticationByBiometryService service = new AuthenticationByBiometryService(mockDirectory, Strength.STRONG);

        assertTrue(service.isAMatch("user1", "mockPassword"));
        assertFalse(service.isAMatch("user1", "wrongPassword"));

        verify(mockDirectory, times(2)).getMatch("user1");
    }

    @Test
    void testDataStrength() {
        DirectoryInterface mockDirectory = mock(DirectoryInterface.class);

        AuthenticationByBiometryService service = new AuthenticationByBiometryService(mockDirectory, Strength.STRONG);

        assertEquals(Strength.STRONG, service.dataStrength("mockData"));
    }
}*/