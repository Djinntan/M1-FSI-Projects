package tests;

/*import authentication.Strength;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AuthenticationByPasswordServiceTest {

    @Test
    void testIsAMatch() {
        DirectoryInterface mockDirectory = mock(DirectoryInterface.class);
        StrengthEstimationServiceInterface mockStrengthService = mock(StrengthEstimationServiceInterface.class);

        when(mockDirectory.getMatch("user1")).thenReturn("mockPassword");

        AuthenticationByPasswordService service = new AuthenticationByPasswordService(mockDirectory, mockStrengthService);

        assertTrue(service.isAMatch("user1", "mockPassword"));
        assertFalse(service.isAMatch("user1", "wrongPassword"));

        verify(mockDirectory, times(2)).getMatch("user1");
    }

    @Test
    void testDataStrength() {
        DirectoryInterface mockDirectory = mock(DirectoryInterface.class);
        StrengthEstimationServiceInterface mockStrengthService = mock(StrengthEstimationServiceInterface.class);

        when(mockStrengthService.equivalentBitLength(anyInt(), anyInt())).thenReturn(75);

        AuthenticationByPasswordService service = new AuthenticationByPasswordService(mockDirectory, mockStrengthService);

        assertEquals(Strength.WEAK, service.dataStrength("mockPassword"));

        verify(mockStrengthService).equivalentBitLength(anyInt(), anyInt());
    }
}*/