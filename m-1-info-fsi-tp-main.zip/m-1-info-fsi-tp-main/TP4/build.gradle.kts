plugins {
    id("java")
    id("application")
    id("pmd")
    id("com.github.spotbugs") version "6.1.3"
    id ("name.remal.sonarlint") version "5.1.1"
}

repositories {
    mavenCentral()
}

dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.11.4")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.11.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testImplementation("org.assertj:assertj-core:3.27.0")
}

tasks.test {
    useJUnitPlatform()
}

pmd {
    isConsoleOutput = true
    toolVersion = "7.0.0-rc1"
    rulesMinimumPriority = 5
    ruleSets = listOf("rulesets/java/quickstart.xml", "category/java/errorprone.xml", "category/java/bestpractices.xml")
}

spotbugs {
    toolVersion = "4.9.0"
}

application {
    mainClass.set("Main")
}
