package main;
import java.util.logging.Logger;

public class Main {

    // Initialisation du logger
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    // Classe Point
    public static class Point {
        private float abs;
        private float ord;

        public Point() {
            this(0.0F, 0.0F); // Utilisation du constructeur avec paramètres
        }

        public Point(float abs, float ord) {
            this.abs = abs;
            this.ord = ord;
        }

        public float getAbs() {
            return abs;
        }

        public void setAbs(float abs) {
            this.abs = abs;
        }

        public float getOrd() {
            return ord;
        }

        public void setOrd(float ord) {
            this.ord = ord;
        }

        // Redéfinir equals pour comparer les objets Point par leurs coordonnées
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {return true;}
            if (obj == null || getClass() != obj.getClass()) {return false;}
            Point point = (Point) obj;
            return Float.compare(point.abs, abs) == 0 && Float.compare(point.ord, ord) == 0;
        }

        // Redéfinir hashCode pour que les objets égaux aient le même code de hachage
        @Override
        public int hashCode() {
            return 31 * Float.hashCode(abs) + Float.hashCode(ord);
        }
    }

    // Classe Rectangle
    public static class Rectangle {
        private final Point point1;
        private final Point point2;

        public Rectangle(Point point1, Point point2) {
            this.point1 = point1;
            this.point2 = point2;
        }

        public Point getPoint1() {
            return point1;
        }

        public Point getPoint2() {
            return point2;
        }
    }

    public static void main(String[] args) {

        final Point p1 = new Point(7, 8);
        final Rectangle r1 = new Rectangle(p1, new Point());
        final Rectangle r2 = r1;
        final Rectangle r3 = new Rectangle(p1, new Point());

        // Remplacer la comparaison avec == par equals
        if (r1.equals(r2)) {
            LOGGER.info("equal_ref");
        }

        // Comparaison de point1 avec equals
        if (r1.getPoint1().equals(r3.getPoint1())) {
            LOGGER.info("equal_point1Field");
        }

        r3.getPoint1().setOrd(2);
        r1.getPoint1().setOrd(r3.getPoint1().getOrd());

        if (r1.getPoint1().getOrd() == r3.getPoint1().getOrd()) {
            LOGGER.info("equal_point1Field_ordField");
        }
    }
}
