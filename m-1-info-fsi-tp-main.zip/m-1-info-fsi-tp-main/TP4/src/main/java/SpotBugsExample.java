import java.io.*;

public class SpotBugsExample {
    private final byte[] b;
    private final int length;

    SpotBugsExample() {
        length = 40;
        b = new byte[length];
    }

    public void bar() {
        try {
            FileInputStream x = new FileInputStream("z");
            int bytesRead = x.read(b, 0, length);  // Correction: on capture le nombre d'octets lus
            if (bytesRead == -1) {
                System.out.println("Erreur de lecture");
            }
            x.close();
        } catch (IOException e) {
            System.out.println("Oopsie");
        }

        for (int i = 0; i < length; i++) {  // Correction: le comparateur a changé de 1 à 0
            if (Integer.toString(50).equals(Byte.toString(b[i]))) {  // Correction: utilisation de equals pour les comparaisons de String
                System.out.print(b[i] + " ");
            }
        }
    }
}