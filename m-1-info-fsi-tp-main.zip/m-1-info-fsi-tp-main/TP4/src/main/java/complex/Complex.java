package complex;

import java.util.Objects;

public class Complex {
    private float realPart;
    private float imaginaryPart;

    public Complex() {
        super();
    }

    public Complex(float real, float imaginary) {
        this.realPart = real;
        this.imaginaryPart = imaginary;
    }

    public boolean isZero() {
        return (this.realPart == 0) && (this.imaginaryPart == 0);
    }

    public float getRealPart() {
        return this.realPart;
    }

    public float getImaginaryPart() {
        return this.imaginaryPart;
    }

    public void setRealPart(float real) {
        this.realPart = real;
    }

    public void setImaginaryPart(float imaginary) {
        this.imaginaryPart = imaginary;
    }

    public Complex sum(final Complex complex) {
        return new Complex(this.realPart + complex.getRealPart(), this.imaginaryPart + complex.getImaginaryPart());
    }

    public Complex inverse() throws IllegalArgumentException {
        final float squareNorm = (this.realPart * this.realPart + this.imaginaryPart * this.imaginaryPart);

        if (isZero()) {
            throw new IllegalArgumentException("Cannot compute the inverse of zero.");
        } else {
            return new Complex(this.realPart / squareNorm, -this.imaginaryPart / squareNorm);
        }
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Complex complex = (Complex) obj;
        return (this.realPart == complex.realPart) && (this.imaginaryPart == complex.imaginaryPart);
    }

    @Override
    public int hashCode() {
        return Objects.hash(realPart, imaginaryPart);
    }

    @Override
    public String toString() {
        return realPart + "+i" + imaginaryPart;
    }

    public static void infinite() {
        // Recursive call should be avoided or logged properly if needed.
        throw new StackOverflowError("Infinite recursion detected");
    }
}
