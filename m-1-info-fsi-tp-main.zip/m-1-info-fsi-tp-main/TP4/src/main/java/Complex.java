import java.util.Objects;

public class Complex {
    float realPart = 0;
    float imaginaryPart = 0;

    public Complex() {
        super();
    }

    public Complex(float a, float b) {
        this.realPart = a;
        this.imaginaryPart = b;
    }


    public boolean is_zero() {
        return ((this.realPart == 0) && (this.imaginaryPart == 0));
    }

    public float getRealPart() {
        return this.realPart;
    }

    public float getImaginaryPart() {
        return this.imaginaryPart;
    }

    public void setRealPart(float a) {
        this.realPart = a;
    }

    public void setImaginaryPart(float b) {
        this.imaginaryPart = b;
    }

    public Complex sum(Complex c) {
        return new Complex(this.realPart + c.getRealPart(), this.imaginaryPart + c.getImaginaryPart());
    }


    public Complex inverse() throws IllegalArgumentException {

        float square_norm = (this.realPart * this.realPart + this.imaginaryPart * this.imaginaryPart);

        if (is_zero()) throw new IllegalArgumentException();
        else return new Complex(this.realPart / square_norm, -this.imaginaryPart / square_norm);
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Complex c = (Complex) obj;
        return Double.compare(this.realPart, c.realPart) == 0 &&
                Double.compare(this.imaginaryPart, c.imaginaryPart) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(realPart, imaginaryPart);
    }

    @Override
    public String toString() {
        return realPart + "+i" + imaginaryPart;
    }

    public static void infinite() {
                //infinite();
    }

/*    //Ceci est une bouche trou car le nom des packages de TP1 font que je n'arrive pas a créer une classe de teste qui marche correctement
    public static void runTests() {
        Complex c1 = new Complex();
        c1.setRealPart(3);
        c1.setImaginaryPart(4);
        System.out.println("Real part: " + (c1.getRealPart() == 3));
        System.out.println("Imaginary part: " + (c1.getImaginaryPart() == 4));

        Complex inverse = c1.inverse();
        System.out.println("Inverse real part: " + (Math.abs(inverse.getRealPart() - 0.12) < 0.01));
        System.out.println("Inverse imaginary part: " + (Math.abs(inverse.getImaginaryPart() + 0.16) < 0.01));

        System.out.println("is_zero: " + !c1.is_zero());

        Complex.infinite();
        System.out.println("infinite method called.");
    }

    public static void main(String[] args) {
        runTests();
    }*/
}


