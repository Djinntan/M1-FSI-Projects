
public class Main {

    public static class Point{
        float abs = 0.0F;
        float ord = 0.0F;

        public Point(){
            super();
        }

        public Point(float x, float y){
            abs = x;
            ord = y;
        }
    }

    public static class Rectangle{
        Point point1;
        Point point2;

        public Rectangle(Point P1, Point P2){
            point1 = P1;
            point2 = P2;
        }
    }


    public static void main(String[] args) {

    Point P1 = new Point(7,8);
    Rectangle R1 = new Rectangle(P1, new Point());
    Rectangle R2 = R1;
    Rectangle R3 = new Rectangle(P1, new Point());

    if (R1 == R2)  System.out.println("equal_ref");

    if (R1.point1 == R3.point1) System.out.println("equal_point1Field");


    R3.point1.ord = 2;
    R1.point1.ord = R3.point1.ord;
    if (R1.point1.ord == R3.point1.ord) System.out.println("equal_point1Field_ordField");

    }

}
