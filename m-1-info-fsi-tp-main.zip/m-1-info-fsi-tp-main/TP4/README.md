# M1 INFO FSI TP 4

- Lancer PMD sur le code `main` avec la commande suivante :

    ```
    ./gradlew pmdMain
    ```
  
- Lancer PMD sur le code `test` avec la commande suivante :

    ```
    ./gradlew pmdTest
    ```

- Lancer SpotBugs sur le code `main` avec la commande suivante :

    ```
    ./gradlew spotbugsMain
    ```

- Lancer SpotBugs sur le code `test` avec la commande suivante :

    ```
    ./gradlew spotbugsTest
    ```

- Lancer sonarlint sur le code `main` avec la commande suivante :

    ```
    ./gradlew sonarlintMain
    ```

- Lancer sonarlint sur le code `test` avec la commande suivante :

    ```
    ./gradlew sonarlintTest
    ```