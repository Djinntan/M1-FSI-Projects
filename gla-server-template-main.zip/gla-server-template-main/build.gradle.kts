plugins {
    id("java")
    id("application")
    id("jacoco") //added Jacoco to get coverage
    id("com.github.spotbugs") version "6.1.3"
    id("pmd")
    id ("name.remal.sonarlint") version "5.1.1"
}

group = "fr.univ_amu.m1info"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}
spotbugs {
    toolVersion = "4.9.0"
}

pmd {
    isConsoleOutput = true
    toolVersion = "7.0.0-rc1"
    rulesMinimumPriority = 5
    ruleSets = listOf("rulesets/java/quickstart.xml", "category/java/errorprone.xml",
        "category/java/bestpractices.xml")
}

dependencies {
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.11.4")
    testImplementation("org.junit.jupiter:junit-jupiter-engine:5.11.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    implementation("org.hsqldb:hsqldb:2.7.4")
    implementation("org.hsqldb:sqltool:2.7.4")
    implementation("io.javalin:javalin:6.4.0")
    testImplementation ("org.mockito:mockito-inline:5.0.0") //mockito inline (différences dans final...etc)
    testImplementation ("io.javalin:javalin-testtools:6.4.0") //added testools
    testImplementation ("org.mockito:mockito-junit-jupiter:5.7.0") //Mockito specifique a Junit5
    //   implementation ("com.konghq:unirest-java:3.13.14")
    implementation("org.slf4j:slf4j-simple:2.0.16")
    implementation("com.fasterxml.jackson.core:jackson-databind:2.17.2")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.18.1")
    testImplementation("org.mockito:mockito-core:5.15.2") //added mockito core
    testImplementation ("org.junit.jupiter:junit-jupiter:5.9.2")
    testImplementation ("org.mockito:mockito-core:5.7.0")
    implementation("com.google.inject:guice:7.0.0")
}

application {
    mainClass.set("fr.univ_amu.m1info.server.Main")
}

tasks.test {
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)
}

tasks.jacocoTestReport {
    dependsOn(tasks.test)
}



