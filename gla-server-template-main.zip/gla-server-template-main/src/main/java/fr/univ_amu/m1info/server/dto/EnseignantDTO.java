package fr.univ_amu.m1info.server.dto;

public record EnseignantDTO(int id, String nom, String prenom, String email) {}
