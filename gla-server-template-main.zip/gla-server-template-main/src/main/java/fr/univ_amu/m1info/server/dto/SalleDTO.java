package fr.univ_amu.m1info.server.dto;

import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;

public record SalleDTO(
        int id,
        String nom,
        String batiment,
        String campus,
        boolean videoProjecteur,
        int capacite,
        TypeSalle typeSalle
) {}