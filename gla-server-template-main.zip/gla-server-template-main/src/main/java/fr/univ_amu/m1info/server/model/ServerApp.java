package fr.univ_amu.m1info.server.model;

import fr.univ_amu.m1info.server.controler.*;
import fr.univ_amu.m1info.server.routes.*;
import io.javalin.Javalin;

public class ServerApp {
    private final CalendarController calendarController;
    private final SalleController salleController;
    private final EtudiantController etudiantController;
    private final GroupeController groupeController;
    private final EnseignantController enseignantController;
    private final Javalin app;

    public ServerApp(CalendarController calendarController, SalleController salleController,
                     EtudiantController etudiantController, GroupeController groupeController, EnseignantController enseignantController) {
        this.calendarController = calendarController;
        this.salleController = salleController;
        this.etudiantController = etudiantController;
        this.groupeController = groupeController;
        this.enseignantController = enseignantController;
        this.app = Javalin.create(config -> config.bundledPlugins.enableDevLogging());
    }

    public void startServer() {
        new CalendarRoutes(calendarController).register(app);
        new SalleRoutes(salleController).register(app);
        new EtudiantRoutes(etudiantController).register(app);
        new GroupeRoutes(groupeController).register(app);
        new EnseignantRoutes(enseignantController).register(app);
        app.start(8080);
    }
}
