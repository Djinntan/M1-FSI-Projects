package fr.univ_amu.m1info.server.model.models.salle;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SalleManager {
    private final List<Salle> salles = new ArrayList<>();
    private int idSequence = 1;

    public void addSalle(Salle salle) {
        salle.setId(idSequence++);
        salles.add(salle);
    }

    public void removeSalle(int id) {
        salles.removeIf(salle -> salle.getId() == id);
    }

    public List<Salle> getSalles() {
        return new ArrayList<>(salles);
    }

    public Optional<Salle> getSalleById(int id) {
        return salles.stream().filter(salle -> salle.getId() == id).findFirst();
    }

    public boolean updateSalle(Salle salle) {
        for (int i = 0; i < salles.size(); i++) {
            if (salles.get(i).getId() == salle.getId()) {
                salles.set(i, salle);
                return true;
            }
        }
        return false;
    }

    public Optional<Salle> getSalleByNomAndLieu(String nom, String batiment, String campus) {
        return salles.stream()
                .filter(salle -> salle.getNom().equalsIgnoreCase(nom)
                        && salle.getBatiment().equalsIgnoreCase(batiment)
                        && salle.getCampus().equalsIgnoreCase(campus))
                .findFirst();
    }

}
