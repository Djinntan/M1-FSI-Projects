package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.GroupeController;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import io.javalin.Javalin;
import io.javalin.http.Context;

public class GroupeRoutes {
    private final GroupeController groupeController;

    public GroupeRoutes(GroupeController groupeController) {
        this.groupeController = groupeController;
    }

    public void register(Javalin app) {
        app.get("/groupes", this::handleGetAllGroupes);
        app.get("/groupes/{id}", this::handleGetGroupeById);
        app.post("/groupes", this::handleCreateGroupe);
        app.put("/groupes", this::handleCreateOrUpdateGroupe);
        app.put("/groupes/{id}", this::handleUpdateGroupe);

        app.delete("/groupes/{id}", this::handleDeleteGroupe);
    }

    void handleGetAllGroupes(Context ctx) {
        ctx.status(200).json(groupeController.getAllGroupes());
    }

    void handleGetGroupeById(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            GroupeDTO groupe = groupeController.getGroupeById(id);
            if (groupe != null) {
                ctx.status(200).json(groupe);
            } else {
                ctx.status(404).result("Groupe non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    void handleCreateGroupe(Context ctx) {
        try {
            GroupeDTO groupe = ctx.bodyAsClass(GroupeDTO.class);
            GroupeDTO createdGroupe = groupeController.createGroupe(groupe);
            ctx.status(201).json(createdGroupe);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    private void handleCreateOrUpdateGroupe(Context ctx) {
        try {
            GroupeDTO groupe = ctx.bodyAsClass(GroupeDTO.class);
            GroupeDTO result = groupeController.createOrUpdateGroupe(groupe);
            ctx.status(200).json(result);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    void handleDeleteGroupe(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            if (groupeController.deleteGroupe(id)) {
                ctx.status(204);
            } else {
                ctx.status(404).result("Groupe non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    void handleUpdateGroupe(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            GroupeDTO groupe = ctx.bodyAsClass(GroupeDTO.class);

            if (groupe.id() != id) {
                ctx.status(400).result("ID dans l'URL et le corps ne correspondent pas");
                return;
            }

            boolean success = groupeController.updateGroupe(id, groupe);

            if (success) {
                ctx.status(200).result("Groupe mis à jour avec succès.");
            } else {
                ctx.status(404).result("Groupe non trouvé ou mise à jour impossible.");
            }

        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        } catch (Exception e) {
            ctx.status(500).result("Erreur interne lors de la mise à jour");
        }
    }}
