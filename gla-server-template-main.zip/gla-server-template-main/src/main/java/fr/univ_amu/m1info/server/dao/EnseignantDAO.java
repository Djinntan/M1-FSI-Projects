package fr.univ_amu.m1info.server.dao;


import fr.univ_amu.m1info.server.dto.EnseignantDTO;

import java.util.List;
import java.util.Optional;

public interface EnseignantDAO {
    List<EnseignantDTO> getAllEnseignants();
    Optional<EnseignantDTO> getEnseignantById(int id);
    int createEnseignant(EnseignantDTO enseignant);
    boolean updateEnseignant(EnseignantDTO enseignant);
    boolean deleteEnseignant(int id);
    Optional<EnseignantDTO> getEnseignantByEmail(String email);

}
