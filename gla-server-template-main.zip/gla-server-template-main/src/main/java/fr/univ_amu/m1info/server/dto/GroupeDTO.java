package fr.univ_amu.m1info.server.dto;

import java.util.List;

public record GroupeDTO(int id, String nom/*, List<EtudiantDTO> etudiants*/) {}
