package fr.univ_amu.m1info.server.model.models.salle;

public enum TypeSalle {
    TD, TP, AMPHITHEATRE
}