package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.SalleDAO;
import fr.univ_amu.m1info.server.dto.SalleDTO;
import java.util.List;
import java.util.Optional;

public class SalleController {

    private final SalleDAO salleDAO;

    public SalleController(SalleDAO salleDAO) {
        this.salleDAO = salleDAO;
    }
    public List<SalleDTO> getAllSalles() {
        return salleDAO.getAllSalles();
    }

    public SalleDTO getSalleById(int id) {
        return salleDAO.getSalleById(id).orElse(null);
    }

    public SalleDTO createSalle(SalleDTO salle) {
        if (salle == null) {
            throw new IllegalArgumentException("La salle ne peut pas être null");
        }

        int id = salleDAO.createSalle(salle);
        return new SalleDTO(
                id,
                salle.nom(),
                salle.batiment(),
                salle.campus(),
                salle.videoProjecteur(),
                salle.capacite(),
                salle.typeSalle()
        );
    }

    /**
     * Mettre à jour une salle existante
     */
    public boolean updateSalle(int id, SalleDTO salle) {
        Optional<SalleDTO> existingSalleOpt = salleDAO.getSalleById(id);

        if (existingSalleOpt.isPresent()) {
            return salleDAO.updateSalle(new SalleDTO(
                    id,
                    salle.nom(),
                    salle.batiment(),
                    salle.campus(),
                    salle.videoProjecteur(),
                    salle.capacite(),
                    salle.typeSalle()
            ));
        }
        return false;
    }

    /**
     * Supprimer une salle
     */
    public boolean deleteSalle(int id) {
        return salleDAO.deleteSalle(id);
    }

    /**
     * Créer ou mettre à jour une salle en fonction de ses informations.
     * Si la salle existe déjà, elle est mise à jour, sinon elle est créée.
     */
    public SalleDTO createOrUpdateSalle(SalleDTO salle) {
        if (salle == null) {
            throw new IllegalArgumentException("La salle ne peut pas être null");
        }

        // 🔍 Vérifier si la salle existe déjà (même nom, bâtiment, campus)
        Optional<SalleDTO> existingSalleOpt = salleDAO.getSalleByNomAndLieu(
                salle.nom(), salle.batiment(), salle.campus()
        );

        if (existingSalleOpt.isPresent()) {
            // 🛠️ Mise à jour de la salle existante
            SalleDTO salleExistante = existingSalleOpt.get();
            SalleDTO salleMiseAJour = new SalleDTO(
                    salleExistante.id(), // ✅ On garde l'ID de la salle existante
                    salle.nom(),
                    salle.batiment(),
                    salle.campus(),
                    salle.videoProjecteur(),
                    salle.capacite(),
                    salle.typeSalle()
            );
            boolean updated = salleDAO.updateSalle(salleMiseAJour);
            if (updated) {
                return salleMiseAJour; // ✅ Retourne la salle mise à jour
            }
        }

        // 🏗️ Si elle n'existe pas, on la crée
        return createSalle(salle);
    }

}
