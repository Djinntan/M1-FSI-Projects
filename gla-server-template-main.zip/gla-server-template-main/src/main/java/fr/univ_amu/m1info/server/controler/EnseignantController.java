package fr.univ_amu.m1info.server.controler;



import fr.univ_amu.m1info.server.dao.EnseignantDAO;
import fr.univ_amu.m1info.server.dto.EnseignantDTO;

import java.util.List;
import java.util.Optional;

public class EnseignantController {

    private final EnseignantDAO enseignantDAO;

    public EnseignantController(EnseignantDAO enseignantDAO) {
        this.enseignantDAO = enseignantDAO;
    }

    /**
     * Récupérer tous les enseignants
     */
    public List<EnseignantDTO> getAllEnseignants() {
        return enseignantDAO.getAllEnseignants();
    }

    /**
     * Récupérer un enseignant par son ID
     */
    public EnseignantDTO getEnseignantById(int id) {
        return enseignantDAO.getEnseignantById(id).orElse(null);
    }

    /**
     * Ajouter un nouvel enseignant
     */
    public EnseignantDTO createEnseignant(EnseignantDTO enseignant) {
        if (enseignant == null) {
            throw new IllegalArgumentException("L'enseignant ne peut pas être null");
        }

        int id = enseignantDAO.createEnseignant(enseignant);
        return new EnseignantDTO(
                id,
                enseignant.nom(),
                enseignant.prenom(),
                enseignant.email()
        );
    }

    /**
     * Mettre à jour un enseignant existant
     */
    public boolean updateEnseignant(int id, EnseignantDTO enseignant) {
        Optional<EnseignantDTO> existingEnseignantOpt = enseignantDAO.getEnseignantById(id);

        if (existingEnseignantOpt.isPresent()) {
            return enseignantDAO.updateEnseignant(new EnseignantDTO(
                    id,
                    enseignant.nom(),
                    enseignant.prenom(),
                    enseignant.email()
            ));
        }
        return false;
    }


    /**
     * Supprimer un enseignant
     */
    public boolean deleteEnseignant(int id) {
        return enseignantDAO.deleteEnseignant(id);
    }

    /**
     * Créer ou mettre à jour un enseignant
     */
    public EnseignantDTO createOrUpdateEnseignant(EnseignantDTO enseignant) {
        if (enseignant == null) {
            throw new IllegalArgumentException("L'enseignant ne peut pas être null");
        }

        // Vérifie si l'enseignant existe déjà via son email
        Optional<EnseignantDTO> existingEnseignantOpt = enseignantDAO.getEnseignantByEmail(enseignant.email());

        if (existingEnseignantOpt.isPresent()) {
            // Mise à jour
            EnseignantDTO enseignantExistant = existingEnseignantOpt.get();
            EnseignantDTO enseignantMisAJour = new EnseignantDTO(
                    enseignantExistant.id(),
                    enseignant.nom(),
                    enseignant.prenom(),
                    enseignant.email()
            );
            boolean updated = enseignantDAO.updateEnseignant(enseignantMisAJour);
            if (updated) {
                return enseignantMisAJour;
            }
        }

        // Si l'enseignant n'existe pas, on le crée
        return createEnseignant(enseignant);
    }
}

