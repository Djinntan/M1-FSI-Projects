package fr.univ_amu.m1info.server.dao;
import fr.univ_amu.m1info.server.dto.CalendarSlotDTO;

public interface CalendarDAO extends DAO<Integer, CalendarSlotDTO> {
    void initializeDatabase();
}
