package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.EtudiantController;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import io.javalin.Javalin;
import io.javalin.http.Context;

public class EtudiantRoutes {
    private final EtudiantController etudiantController;

    public EtudiantRoutes(EtudiantController etudiantController) {
        this.etudiantController = etudiantController;
    }

    public void register(Javalin app) {
        app.get("/etudiants", this::handleGetAllEtudiants);
        app.get("/etudiants/{id}", this::handleGetEtudiantById);
        app.post("/etudiants", this::handleCreateEtudiant);
        app.put("/etudiants", this::handleCreateOrUpdateEtudiant);
        app.put("/etudiants/{id}", this::handleUpdateEtudiant);

        app.delete("/etudiants/{id}", this::handleDeleteEtudiant);
    }

    void handleGetAllEtudiants(Context ctx) {
        ctx.status(200).json(etudiantController.getAllEtudiants());
    }

    void handleGetEtudiantById(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            EtudiantDTO etudiant = etudiantController.getEtudiantById(id);
            if (etudiant != null) {
                ctx.status(200).json(etudiant);
            } else {
                ctx.status(404).result("Etudiant non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    void handleCreateEtudiant(Context ctx) {
        try {
            EtudiantDTO etudiant = ctx.bodyAsClass(EtudiantDTO.class);
            EtudiantDTO createdEtudiant = etudiantController.createEtudiant(etudiant);
            ctx.status(201).json(createdEtudiant);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    private void handleCreateOrUpdateEtudiant(Context ctx) {
        try {
            EtudiantDTO etudiant = ctx.bodyAsClass(EtudiantDTO.class);

            EtudiantDTO result = etudiantController.createOrUpdateEtudiant(etudiant);
            System.out.println("la");
            ctx.status(200).json(result);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    void handleDeleteEtudiant(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            if (etudiantController.deleteEtudiant(id)) {
                ctx.status(204);
            } else {
                ctx.status(404).result("Etudiant non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    void handleUpdateEtudiant(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            EtudiantDTO etudiant = ctx.bodyAsClass(EtudiantDTO.class);

            boolean success = etudiantController.updateEtudiant(id, etudiant);

            if (success) {
                ctx.status(200).result("Etudiant mis à jour avec succès.");
            } else {
                ctx.status(404).result("Etudiant non trouvé ou mise à jour impossible.");
            }

        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        } catch (Exception e) {
            ctx.status(500).result("Erreur interne lors de la mise à jour");
        }
    }
}
