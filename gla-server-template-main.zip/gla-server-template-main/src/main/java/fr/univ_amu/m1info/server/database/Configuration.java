package fr.univ_amu.m1info.server.database;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configuration {
    private static final Properties properties = new Properties();

    static {

        try (InputStream input = Configuration.class.getResourceAsStream("/configuration.properties")) {
            if (input == null) {
                // Affiche un message pour diagnostiquer où le fichier est recherché
                System.out.println("Impossible de trouver 'configuration.properties' à la racine du classpath !");
                throw new RuntimeException("Configuration file '/configuration.properties' not found in classpath!");
            }

            // Charger les propriétés depuis le fichier
            properties.load(input);

        } catch (IOException e) {
            // Gérer les exceptions en cas de problème lors de la lecture
            throw new RuntimeException("Error loading configuration file '/configuration.properties'", e);
        }
    }

    // Méthode pour récupérer une propriété à partir d'une clé
    public static String get(String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new RuntimeException("Key '" + key + "' not found in configuration!");
        }
        return value;
    }
}
