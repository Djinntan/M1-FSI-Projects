package fr.univ_amu.m1info.server.dao;

import fr.univ_amu.m1info.server.dto.SalleDTO;

import java.util.List;
import java.util.Optional;

public interface SalleDAO {
    List<SalleDTO> getAllSalles();

    Optional<SalleDTO> getSalleById(int id);

    int createSalle(SalleDTO salle);
    boolean updateSalle(SalleDTO salle);
    boolean deleteSalle(int id);

    Optional<SalleDTO> getSalleByNomAndLieu(String nom, String batiment, String campus);
}

