package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dao.EnseignantDAO;
import fr.univ_amu.m1info.server.dto.EnseignantDTO;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EnseignantJDBCDAO implements EnseignantDAO {
    private final Connection connection;

    public EnseignantJDBCDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<EnseignantDTO> getAllEnseignants() {
        List<EnseignantDTO> enseignants = new ArrayList<>();
        String query = "SELECT * FROM Enseignant";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                enseignants.add(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des enseignants", e);
        }
        return enseignants;
    }

    @Override
    public Optional<EnseignantDTO> getEnseignantByEmail(String email) {
        String query = "SELECT * FROM Enseignant WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToDTO(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'enseignant par email", e);
        }
        return Optional.empty();
    }


    @Override
    public Optional<EnseignantDTO> getEnseignantById(int id) {
        String query = "SELECT * FROM Enseignant WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'enseignant", e);
        }
        return Optional.empty();
    }

    @Override
    public int createEnseignant(EnseignantDTO enseignant) {
        String query = "INSERT INTO Enseignant (nom, prenom, email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, enseignant.nom());
            stmt.setString(2, enseignant.prenom());
            stmt.setString(3, enseignant.email());
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création de l'enseignant", e);
        }
        return -1;
    }

    @Override
    public boolean updateEnseignant(EnseignantDTO enseignant) {
        String query = "UPDATE Enseignant SET nom = ?, prenom = ?, email = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, enseignant.nom());
            stmt.setString(2, enseignant.prenom());
            stmt.setString(3, enseignant.email());
            stmt.setInt(4, enseignant.id());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de l'enseignant", e);
        }
    }

    @Override
    public boolean deleteEnseignant(int id) {
        try {
            // Étape 1 : Supprimer la référence à l'enseignant dans les créneaux existants
            String updateSlotsQuery = "UPDATE CalendarSlot SET enseignant_id = NULL WHERE enseignant_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateSlotsQuery)) {
                updateStmt.setInt(1, id);
                updateStmt.executeUpdate();
            }

            // Étape 2 : Supprimer l'enseignant lui-même
            String deleteEnseignantQuery = "DELETE FROM Enseignant WHERE id = ?";
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteEnseignantQuery)) {
                deleteStmt.setInt(1, id);
                int affectedRows = deleteStmt.executeUpdate();
                return affectedRows > 0;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de l'enseignant", e);
        }
    }

    private EnseignantDTO mapResultSetToDTO(ResultSet rs) throws SQLException {
        return new EnseignantDTO(
                rs.getInt("id"),
                rs.getString("nom"),
                rs.getString("prenom"),
                rs.getString("email")
        );
    }
}
