package fr.univ_amu.m1info.server;

import fr.univ_amu.m1info.server.controler.*;
import fr.univ_amu.m1info.server.database.ConnectionFactory;
import fr.univ_amu.m1info.server.database.entities.*;
import fr.univ_amu.m1info.server.model.ServerApp;

public class Main {
    public static void main(String[] args) {
        var connection = ConnectionFactory.getConnection();
        var calendarDAO = new CalendarJDBCDAO(connection);
        var salleDAO = new SalleJDBCDAO(connection);
        var etudiantDAO = new EtudiantJDBCDAO(connection);
        var enseignantDAO = new EnseignantJDBCDAO(connection);
        var groupeDAO = new GroupeJDBCDAO(connection);

        var calendarController = new CalendarController(calendarDAO);
        var salleController = new SalleController(salleDAO);
        var etudiantController = new EtudiantController(etudiantDAO);
        var groupeController = new GroupeController(groupeDAO);
        var enseignantController = new EnseignantController(enseignantDAO);
        ServerApp serverApp = new ServerApp(calendarController, salleController, etudiantController, groupeController,enseignantController);
        serverApp.startServer();
    }
}
