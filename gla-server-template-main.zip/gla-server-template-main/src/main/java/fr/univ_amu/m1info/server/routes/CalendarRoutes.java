package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.CalendarController;
import fr.univ_amu.m1info.server.dto.CalendarSlotDTO;
import fr.univ_amu.m1info.server.dto.TimeInterval;
import fr.univ_amu.m1info.server.model.exceptions.UnknownElementException;
import fr.univ_amu.m1info.server.model.exceptions.WrongVersionException;
import io.javalin.Javalin;
import io.javalin.http.Context;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

public class CalendarRoutes {
    private final CalendarController calendarController;

    public CalendarRoutes(CalendarController calendarController) {
        this.calendarController = calendarController;
    }

    public void register(Javalin app) {
        app.get("/calendar/request", this::handleCalendarRequest);
        app.get("/timeslots/{id}", this::handleGetTimeslotById);
        app.post("/timeslots", this::handleCreateTimeslot);
        app.put("/timeslots/{id}", this::handleUpdateTimeslot);
        app.delete("/timeslots/{id}", this::handleDeleteTimeslot);
    }

    void handleCalendarRequest(Context ctx) {
        String startParam = ctx.queryParam("start");
        String endParam = ctx.queryParam("end");

        if (startParam == null || endParam == null) {
            ctx.status(400).result("Bad request: Missing start or end parameter");
            return;
        }

        try {
            LocalDate startDate = LocalDate.parse(startParam);
            LocalDate endDate = LocalDate.parse(endParam);

            if (startDate.isAfter(endDate)) {
                ctx.status(400).result("Bad request: Start date must be before end date");
                return;
            }
            TimeInterval timeInterval = new TimeInterval(LocalDateTime.of(startDate, LocalTime.MIN),
                    LocalDateTime.of(endDate, LocalTime.MAX));
            ctx.status(200).json(calendarController.getCalendarSlotsIn(timeInterval));
        } catch (DateTimeParseException e) {
            ctx.status(400).result("Bad Request: Invalid date format");
        }
    }

    void handleGetTimeslotById(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            CalendarSlotDTO slot = calendarController.getCalendarSlotById(id);
            if (slot != null) {
                ctx.status(200).json(slot);
            } else {
                ctx.status(404).result("Slot with ID " + id + " not found");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("Bad Request: ID must be an integer");
        }
    }

    void handleCreateTimeslot(Context ctx) {
        try {
            CalendarSlotDTO slot = ctx.bodyAsClass(CalendarSlotDTO.class);
            CalendarSlotDTO createdSlot = calendarController.createSlot(slot);
            ctx.status(201).json(createdSlot);
        } catch (Exception e) {
            ctx.status(400).result("Bad Request: Invalid CalendarSlotDTO format");
        }
    }

    void handleUpdateTimeslot(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            CalendarSlotDTO slot;
            try {
                slot = ctx.bodyAsClass(CalendarSlotDTO.class);
            } catch (Exception e) {
                ctx.status(400).result("Bad Request: Invalid CalendarSlotDTO format");
                return;
            }
            try {
                CalendarSlotDTO updatedSlot = calendarController.updateSlot(id, slot);
                ctx.status(200).json(updatedSlot);
            } catch (UnknownElementException e) {
                ctx.status(404).result("Slot with ID " + id + " not found");
            } catch (WrongVersionException e) {
                ctx.status(409).result("Version incorrecte pour le slot ID " + id);
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("Bad Request: ID must be an integer");
        }
    }

    void handleDeleteTimeslot(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            if (calendarController.deleteSlot(id)) {
                ctx.status(204);
            } else {
                ctx.status(404).result("Slot with ID " + id + " not found");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("Bad Request: ID must be an integer");
        }
    }
}
