package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dao.GroupeDAO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import fr.univ_amu.m1info.server.model.technical.Convertor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GroupeJDBCDAO implements GroupeDAO {
    private final Connection connection;

    public GroupeJDBCDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<GroupeDTO> getAllGroupes() {
        List<GroupeDTO> groupes = new ArrayList<>();
        String query = "SELECT id, nom FROM Groupe";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                int groupeId = rs.getInt("id");
                String nom = rs.getString("nom");
               // List<EtudiantDTO> etudiants = getEtudiantsForGroupe(groupeId);
                groupes.add(new GroupeDTO(groupeId, nom/*, etudiants*/));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des groupes", e);
        }
        return groupes;
    }

    @Override
    public Optional<GroupeDTO> getGroupeById(int id) {
        String query = "SELECT id, nom FROM Groupe WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            try(ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String nom = rs.getString("nom");
                    //List<EtudiantDTO> etudiants = getEtudiantsForGroupe(id);
                    return Optional.of(new GroupeDTO(id, nom/*, etudiants*/));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du groupe", e);
        }
        return Optional.empty();
    }

    @Override
    public int createGroupe(GroupeDTO groupe) {
        String query = "INSERT INTO Groupe (nom) VALUES (?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, groupe.nom());
            stmt.executeUpdate();
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            int groupeId = -1;
            if (generatedKeys.next()) {
                groupeId = generatedKeys.getInt(1);
            }
            // Insertion des associations, si des étudiants sont fournis
            /*for (EtudiantDTO etudiant : groupe.etudiants()) {
                insertGroupeEtudiant(groupeId, etudiant.id());
            }*/
            return groupeId;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création du groupe", e);
        }
    }

    @Override
    public boolean updateGroupe(GroupeDTO groupe) {
        String query = "UPDATE Groupe SET nom = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, groupe.nom());
            stmt.setInt(2, groupe.id());
            int affected = stmt.executeUpdate();
            // Pour simplifier, on ne met pas à jour les associations ici.
            return affected > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du groupe", e);
        }
    }

    @Override
    public boolean deleteGroupe(int id) {
        try {
            // Étape 1 : Supprimer la référence du groupe dans les créneaux existants
            String updateCalendarSlotsQuery = "UPDATE CalendarSlot SET groupe_id = NULL WHERE groupe_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateCalendarSlotsQuery)) {
                updateStmt.setInt(1, id);
                updateStmt.executeUpdate();
            }

            // Étape 2 : Supprimer la référence du groupe dans les étudiants
            String updateEtudiantsQuery = "UPDATE Etudiant SET groupe_id = NULL WHERE groupe_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateEtudiantsQuery)) {
                updateStmt.setInt(1, id);
                updateStmt.executeUpdate();
            }

            // Étape 3 : Supprimer le groupe
            String deleteGroupeQuery = "DELETE FROM Groupe WHERE id = ?";
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteGroupeQuery)) {
                deleteStmt.setInt(1, id);
                int affected = deleteStmt.executeUpdate();
                return affected > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du groupe", e);
        }

    }

    // Méthode auxiliaire pour récupérer les étudiants associés à un groupe
    public List<EtudiantDTO> getEtudiantsForGroupe(int groupeId) throws SQLException {
        List<EtudiantDTO> etudiants = new ArrayList<>();
        String query = "SELECT e.id, e.nom, e.prenom, e.numero, e.email " +
                "FROM Etudiant e " +
                "JOIN Groupe_Etudiant ge ON e.id = ge.etudiant_id " +
                "WHERE ge.groupe_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, groupeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    EtudiantDTO etudiant = new EtudiantDTO(
                            rs.getInt("id"),
                            rs.getString("nom"),
                            rs.getString("prenom"),
                            rs.getString("email"),
                            new GroupeDTO(groupeId,
                                    rs.getString(groupeId)/*,
                                    List.of()*/
                            )
                    );
                    etudiants.add(etudiant);
                }
            }
        }
        return etudiants;
    }

    // Méthode auxiliaire pour insérer une association entre un groupe et un étudiant
    public void insertGroupeEtudiant(int groupeId, int etudiantId) throws SQLException {
        String query = "INSERT INTO Groupe_Etudiant (groupe_id, etudiant_id) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, groupeId);
            stmt.setInt(2, etudiantId);
            stmt.executeUpdate();
        }
    }
}
