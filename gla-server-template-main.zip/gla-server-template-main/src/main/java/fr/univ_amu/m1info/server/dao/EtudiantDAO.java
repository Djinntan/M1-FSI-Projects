package fr.univ_amu.m1info.server.dao;


import fr.univ_amu.m1info.server.dto.EtudiantDTO;

import java.util.List;
import java.util.Optional;

public interface EtudiantDAO {
    List<EtudiantDTO> getAllEtudiants();
    Optional<EtudiantDTO> getEtudiantById(int id);
    int createEtudiant(EtudiantDTO etudiant);
    boolean updateEtudiant(EtudiantDTO etudiant);
    boolean deleteEtudiant(int id);
    Optional<EtudiantDTO> getEtudiantByEmail(String email);

}
