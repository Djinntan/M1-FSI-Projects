package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.EtudiantDAO;
import fr.univ_amu.m1info.server.database.entities.EtudiantJDBCDAO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;

import java.util.List;
import java.util.Optional;

public class EtudiantController {

    final EtudiantDAO etudiantDAO;

    public EtudiantController(EtudiantJDBCDAO etudiantDAO) {
        this.etudiantDAO = etudiantDAO;
    }

    /**
     * Récupérer tous les etudiants
     */
    public List<EtudiantDTO> getAllEtudiants() {
        return etudiantDAO.getAllEtudiants();
    }

    /**
     * Récupérer un etudiant par son ID
     */
    public EtudiantDTO getEtudiantById(int id) {
        return etudiantDAO.getEtudiantById(id).orElse(null);
    }

    /**
     * Ajouter un nouvel etudiant
     */
    public EtudiantDTO createEtudiant(EtudiantDTO etudiant) {
        if (etudiant == null) {
            throw new IllegalArgumentException("L'etudiant ne peut pas être null");
        }

        System.out.println("je suis dans create");
        int id = etudiantDAO.createEtudiant(etudiant);
        System.out.println("je suis after create");
        return new EtudiantDTO(
                id,
                etudiant.nom(),
                etudiant.prenom(),
                etudiant.email() ,
                etudiant.groupe()
        );
    }

    /**
     * Mettre à jour un etudiant existant
     */
    public boolean updateEtudiant(int id, EtudiantDTO etudiant) {
        Optional<EtudiantDTO> existingEtudiantOpt = etudiantDAO.getEtudiantById(id);

        if (existingEtudiantOpt.isPresent()) {
            return etudiantDAO.updateEtudiant(new EtudiantDTO(
                    id,
                    etudiant.nom(),
                    etudiant.prenom(),
                    etudiant.email(),
                    etudiant.groupe()

            ));
        }
        return false;
    }


    /**
     * Supprimer un etudiant
     */
    public boolean deleteEtudiant(int id) {
        return etudiantDAO.deleteEtudiant(id);
    }

    /**
     * Créer ou mettre à jour un etudiant
     */
    public EtudiantDTO createOrUpdateEtudiant(EtudiantDTO etudiant) {
        if (etudiant == null) {
            throw new IllegalArgumentException("L'etudiant ne peut pas être null");
        }

        System.out.println("je suis avant email");
        Optional<EtudiantDTO> existingEtudiantOpt = etudiantDAO.getEtudiantByEmail(etudiant.email());

        System.out.println("je suis avec email");
        if (existingEtudiantOpt.isPresent()) {
            System.out.println("je suis dans if");
            EtudiantDTO etudiantExistant = existingEtudiantOpt.get();
            EtudiantDTO etudiantMisAJour = new EtudiantDTO(
                    etudiantExistant.id(),
                    etudiant.nom(),
                    etudiant.prenom(),
                    etudiant.email(),
                    etudiant.groupe()
            );
            boolean updated = etudiantDAO.updateEtudiant(etudiantMisAJour);
            if (updated) {
                return etudiantMisAJour;
            }
        }

        System.out.println("je suis avant create");
        return createEtudiant(etudiant);
    }
}

