package fr.univ_amu.m1info.server.dto;

import java.util.List;

public record CalendarSlotDTO(int id, String description, TimeInterval timeInterval, int version, SalleDTO salle,
                              EnseignantDTO enseignant,
                              GroupeDTO groupe ) {

}
