package fr.univ_amu.m1info.server.dto;

public record EtudiantDTO(int id, String nom, String prenom, String email,GroupeDTO groupe) {

}
