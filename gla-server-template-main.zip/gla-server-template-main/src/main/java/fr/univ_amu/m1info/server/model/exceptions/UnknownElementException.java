package fr.univ_amu.m1info.server.model.exceptions;

/**
 * Exception that can occur during an update / delete / get
 */
public class UnknownElementException extends Exception {
    private final int elementId;

    public UnknownElementException(String message, int elementId) {
        super(message);
        this.elementId = elementId;
    }

    public int getElementId() {
        return elementId;
    }
}
