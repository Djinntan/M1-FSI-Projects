package fr.univ_amu.m1info.server.model.models.calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The calendar
 */
public class Calendar {

    /**
     * The slot composing the calendar
     */
    private ArrayList<CalendarSlot> slots;

    /**
     * Constructor
     */
    public Calendar() {
        this.slots = new ArrayList<>();
    }

    /**
     * Adding slot to the calendar
     * @param slot the new slot
     */
    public void addSlot(CalendarSlot slot) {
        this.slots.add(slot);
    }

    /**
     * Get the slots
     * @return the list of slots
     */
    public List<CalendarSlot> getSlots() {
        return Collections.unmodifiableList(slots); // ✅ Retourne une copie non modifiable
    }

    public void removeSlot(CalendarSlot slot) {
        this.slots.remove(slot);
    }

    public int updateSlot(CalendarSlot element) {
        for (int i = 0; i < slots.size(); i++) {
            CalendarSlot existingSlot = slots.get(i);
            if (existingSlot.getId() == element.getId()) {
                slots.set(i, element);
                return element.getId();
            }
        }
        throw new IllegalArgumentException("Slot with ID " + element.getId() + " not found");
    }
}
