package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.EnseignantController;
import fr.univ_amu.m1info.server.dto.EnseignantDTO;
import io.javalin.Javalin;
import io.javalin.http.Context;

public class EnseignantRoutes {

    private final EnseignantController enseignantController;

    public EnseignantRoutes(EnseignantController enseignantController) {
        this.enseignantController = enseignantController;
    }

    public void register(Javalin app) {
        app.get("/enseignants", this::handleGetAllEnseignants);
        app.get("/enseignants/{id}", this::handleGetEnseignantById);
        app.post("/enseignants", this::handleCreateEnseignant);
        app.put("/enseignants", this::handleCreateOrUpdateEnseignant);
        app.put("/enseignants/{id}", this::handleUpdateEnseignant);

        app.delete("/enseignants/{id}", this::handleDeleteEnseignant);
    }

    private void handleGetAllEnseignants(Context ctx) {
        ctx.status(200).json(enseignantController.getAllEnseignants());
    }

    private void handleGetEnseignantById(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            EnseignantDTO enseignant = enseignantController.getEnseignantById(id);
            if (enseignant != null) {
                ctx.status(200).json(enseignant);
            } else {
                ctx.status(404).result("Enseignant non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    private void handleCreateEnseignant(Context ctx) {
        try {
            EnseignantDTO enseignant = ctx.bodyAsClass(EnseignantDTO.class);
            EnseignantDTO createdEnseignant = enseignantController.createEnseignant(enseignant);
            ctx.status(201).json(createdEnseignant);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    private void handleCreateOrUpdateEnseignant(Context ctx) {
        try {
            EnseignantDTO enseignant = ctx.bodyAsClass(EnseignantDTO.class);
            EnseignantDTO result = enseignantController.createOrUpdateEnseignant(enseignant);
            ctx.status(200).json(result);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    private void handleDeleteEnseignant(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            if (enseignantController.deleteEnseignant(id)) {
                ctx.status(204);
            } else {
                ctx.status(404).result("Enseignant non trouvé");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    private void handleUpdateEnseignant(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            EnseignantDTO enseignant = ctx.bodyAsClass(EnseignantDTO.class);

            if (enseignant.id() != id) {
                ctx.status(400).result("ID dans l'URL et le corps ne correspondent pas");
                return;
            }

            boolean success = enseignantController.updateEnseignant(id, enseignant);

            if (success) {
                ctx.status(200).result("Enseignant mis à jour avec succès.");
            } else {
                ctx.status(404).result("Enseignant non trouvé ou mise à jour impossible.");
            }

        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        } catch (Exception e) {
            ctx.status(500).result("Erreur interne lors de la mise à jour");
        }
    }

}
