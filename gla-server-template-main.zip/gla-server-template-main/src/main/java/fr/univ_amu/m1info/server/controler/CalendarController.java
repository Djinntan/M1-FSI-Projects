package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.CalendarDAO;
import fr.univ_amu.m1info.server.dto.CalendarDTO;
import fr.univ_amu.m1info.server.dto.CalendarSlotDTO;
import fr.univ_amu.m1info.server.dto.TimeInterval;
import fr.univ_amu.m1info.server.model.exceptions.WrongVersionException;
import fr.univ_amu.m1info.server.model.exceptions.UnknownElementException;
import java.util.List;
import java.util.Optional;

public class CalendarController {
    private final CalendarDAO dao;

    public CalendarController(CalendarDAO dao) {
        this.dao = dao;
        this.dao.initializeDatabase();
    }

    public List<CalendarSlotDTO> getAllSlots() {
        return dao.getAll();
    }

    /**
     * Get the current slots from the model within a given time interval
     * @param timeInterval time intervals
     * @return the corresponding slots
     */
    public CalendarDTO getCalendarSlotsIn(TimeInterval timeInterval) {
        List<CalendarSlotDTO> slots = dao.getAll().stream()
                .filter(slot -> slot.timeInterval().start().isAfter(timeInterval.start()) &&
                        slot.timeInterval().end().isBefore(timeInterval.end()))
                .toList();
        return new CalendarDTO(slots);
    }

    public CalendarSlotDTO createSlot(CalendarSlotDTO slot) {
        if (slot == null) {
            throw new IllegalArgumentException("Le créneau à créer ne peut pas être null");
        }

        int id = dao.create(slot);
        return new CalendarSlotDTO(
                        id,
                        slot.description(),
                        slot.timeInterval(),
                        slot.version(),
                        slot.salle(),
                slot.enseignant(),
                slot.groupe());
    }

    public CalendarSlotDTO updateSlot(int id, CalendarSlotDTO slot) throws WrongVersionException, UnknownElementException {
        Optional<CalendarSlotDTO> existingSlotOpt = dao.get(id);

        if (existingSlotOpt.isPresent()) {
            CalendarSlotDTO existingSlot = existingSlotOpt.get();
            if(slot.version() != existingSlot.version()) {
                throw new WrongVersionException("Version incorrecte pour le slot ID " + id);
            }
            CalendarSlotDTO updatedSlot = new CalendarSlotDTO(
                    existingSlot.id(),
                    slot.description(),
                    slot.timeInterval(),
                    slot.version() + 1,
                    slot.salle(),
                    slot.enseignant(),
                    slot.groupe()
            );

            dao.update(updatedSlot);
            return updatedSlot;
        }

        throw new UnknownElementException("Slot with ID " + id + " not found", id);
    }

    public boolean deleteSlot(int id) {
        Optional<CalendarSlotDTO> existingSlotOpt = dao.get(id);
        if (existingSlotOpt.isPresent()) {
            dao.delete(existingSlotOpt.get());
            return true; // Suppression réussie
        }
        return false; // Slot non trouvé
    }

    public CalendarSlotDTO getCalendarSlotById(int id) {
        return dao.get(id).orElse(null);
    }
}

