package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.GroupeDAO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import java.util.List;
import java.util.Optional;

public class GroupeController {
    private final GroupeDAO groupeDAO;

    public GroupeController(GroupeDAO groupeDAO) {
        this.groupeDAO = groupeDAO;
    }

    public List<GroupeDTO> getAllGroupes() {
        return groupeDAO.getAllGroupes();
    }

    public GroupeDTO getGroupeById(int id) {
        return groupeDAO.getGroupeById(id).orElse(null);
    }

    public GroupeDTO createGroupe(GroupeDTO groupe) {
        if (groupe == null) {
            throw new IllegalArgumentException("Le groupe ne peut pas être null");
        }
        int id = groupeDAO.createGroupe(groupe);
        return new GroupeDTO(id, groupe.nom()/*, groupe.etudiants()*/);
    }

    public boolean updateGroupe(int id, GroupeDTO groupe) {
        Optional<GroupeDTO> existingOpt = groupeDAO.getGroupeById(id);
        if (existingOpt.isPresent()) {
            return groupeDAO.updateGroupe(new GroupeDTO(id, groupe.nom()/*, groupe.etudiants()*/));
        }
        return false;
    }

    public boolean deleteGroupe(int id) {
        return groupeDAO.deleteGroupe(id);
    }

    public GroupeDTO createOrUpdateGroupe(GroupeDTO groupe) {
        if (groupe == null) {
            throw new IllegalArgumentException("Le groupe ne peut pas être null");
        }


        return createGroupe(groupe);
    }
}
