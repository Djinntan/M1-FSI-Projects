package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dao.EtudiantDAO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.technical.Convertor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EtudiantJDBCDAO implements EtudiantDAO {
    private final Connection connection;

    public EtudiantJDBCDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<EtudiantDTO> getAllEtudiants() {
        List<EtudiantDTO> etudiants = new ArrayList<>();
        String query = "SELECT e.id AS etudiant_id, e.nom AS etudiant_nom, e.prenom AS etudiant_prenom, e.email AS etudiant_email, " +
                "g.id AS groupe_id, g.nom AS groupe_nom " +
                "FROM Etudiant e " +
                "LEFT JOIN Groupe g ON e.groupe_id = g.id";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                etudiants.add(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des etudiants", e);
        }
        return etudiants;
    }

    @Override
    public Optional<EtudiantDTO> getEtudiantByEmail(String email) {
        String query = "SELECT e.id AS etudiant_id, e.nom AS etudiant_nom, e.prenom AS etudiant_prenom, e.email AS etudiant_email, g.id AS groupe_id, g.nom AS groupe_nom " +
                "FROM Etudiant e " +
                "LEFT JOIN Groupe g ON e.groupe_id = g.id " +
                "WHERE e.email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToDTO(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'etudiant par email", e);
        }
        return Optional.empty();
    }


    @Override
    public Optional<EtudiantDTO> getEtudiantById(int id) {
        String query = "SELECT e.id AS etudiant_id, e.nom AS etudiant_nom, e.prenom AS etudiant_prenom, e.email AS etudiant_email, g.id AS groupe_id, g.nom AS groupe_nom " +
                "FROM Etudiant e " +
                "LEFT JOIN Groupe g ON e.groupe_id = g.id " +
                "WHERE e.id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de l'etudiant", e);
        }
        return Optional.empty();
    }

    @Override
    public int createEtudiant(EtudiantDTO etudiant) {
        String query = "INSERT INTO Etudiant (nom, prenom, email,groupe_id) VALUES (?, ?, ?,?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, etudiant.nom());
            stmt.setString(2, etudiant.prenom());
            stmt.setString(3, etudiant.email());
            stmt.setObject(4, etudiant.groupe() != null ? etudiant.groupe().id() : null, Types.INTEGER);

            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création de l'etudiant", e);
        }
        return -1;
    }

    @Override
    public boolean updateEtudiant(EtudiantDTO etudiant) {
        String query = "UPDATE Etudiant SET nom = ?, prenom = ?, email = ?, groupe_id = ?  WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, etudiant.nom());
            stmt.setString(2, etudiant.prenom());
            stmt.setString(3, etudiant.email());
            stmt.setObject(4, etudiant.groupe() != null ? etudiant.groupe().id() : null, Types.INTEGER);
            stmt.setInt(5, etudiant.id());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de l'etudiant", e);
        }
    }

    @Override
    public boolean deleteEtudiant(int id) {
        try {
            //Étape 1 : Supprimer la référence à l'etudiant dans les créneaux existants
           /* String updateSlotsQuery = "UPDATE CalendarSlot SET etudiant_id = NULL WHERE etudiant_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateSlotsQuery)) {
                updateStmt.setInt(1, id);
                updateStmt.executeUpdate();
            }*/

            // Étape 2 : Supprimer l'etudiant lui-même
            String deleteEtudiantQuery = "DELETE FROM Etudiant WHERE id = ?";
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteEtudiantQuery)) {
                deleteStmt.setInt(1, id);
                int affectedRows = deleteStmt.executeUpdate();
                return affectedRows > 0;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de l'etudiant", e);
        }
    }

    private EtudiantDTO mapResultSetToDTO(ResultSet rs) throws SQLException {
        Groupe groupe = null;
        if (rs.getObject("groupe_id") != null) {
            groupe = new Groupe(
                    rs.getInt("groupe_id"),
                    rs.getString("groupe_nom")/*,
                    List.of()*/
            );
        }
        return new EtudiantDTO(
                rs.getInt("etudiant_id"),
                rs.getString("etudiant_nom"),
                rs.getString("etudiant_prenom"),
                rs.getString("etudiant_email"),
                Convertor.toGroupeDTO(groupe)
        );
    }
}
