package fr.univ_amu.m1info.server.model.models.salle;

public class Salle {
    private int id;
    private String nom;
    private String batiment;
    private String campus;
    private boolean videoProjecteur;
    private int capacite;
    private TypeSalle typeSalle;

    public Salle(int id, String nom, String batiment, String campus, boolean videoProjecteur, int capacite, TypeSalle typeSalle) {
        this.id = id;
        this.nom = nom;
        this.batiment = batiment;
        this.campus = campus;
        this.videoProjecteur = videoProjecteur;
        this.capacite = capacite;
        this.typeSalle = typeSalle;
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getBatiment() { return batiment; }
    public String getCampus() { return campus; }
    public boolean hasVideoProjecteur() { return videoProjecteur; }
    public int getCapacite() { return capacite; }
    public TypeSalle getTypeSalle() { return typeSalle; }

    public void setId(int id) { this.id = id; }
    public void setNom(String nom) { this.nom = nom; }
    public void setBatiment(String batiment) { this.batiment = batiment; }
    public void setCampus(String campus) { this.campus = campus; }
    public void setVideoProjecteur(boolean videoProjecteur) { this.videoProjecteur = videoProjecteur; }
    public void setCapacite(int capacite) { this.capacite = capacite; }
    public void setTypeSalle(TypeSalle typeSalle) { this.typeSalle = typeSalle; }
}
