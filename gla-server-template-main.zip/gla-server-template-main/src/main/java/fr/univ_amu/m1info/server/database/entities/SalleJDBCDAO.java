package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.database.DatabaseInitializer;
import fr.univ_amu.m1info.server.dao.SalleDAO;
import fr.univ_amu.m1info.server.dto.SalleDTO;
import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SalleJDBCDAO implements SalleDAO {
    private final Connection connection;

    public SalleJDBCDAO(Connection connection) {
        this.connection = connection;
        DatabaseInitializer.initialize(connection);
    }

    @Override
    public List<SalleDTO> getAllSalles() {
        List<SalleDTO> salles = new ArrayList<>();
        String query = "SELECT * FROM Salle";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                salles.add(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des salles", e);
        }
        return salles;
    }

    @Override
    public Optional<SalleDTO> getSalleById(int id) {
        String query = "SELECT * FROM Salle WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération de la salle", e);
        }
        return Optional.empty();
    }

    @Override
    public int createSalle(SalleDTO salle) {
        String query = "INSERT INTO Salle (nom, batiment, campus, videoProjecteur, capacite, typeSalle) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, salle.nom());
            stmt.setString(2, salle.batiment());
            stmt.setString(3, salle.campus());
            stmt.setBoolean(4, salle.videoProjecteur());
            stmt.setInt(5, salle.capacite());
            stmt.setString(6, salle.typeSalle().name());
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création de la salle", e);
        }
        return -1;
    }

    @Override
    public boolean updateSalle(SalleDTO salle) {
        String query = "UPDATE Salle SET nom=?, batiment=?, campus=?, videoProjecteur=?, capacite=?, typeSalle=? WHERE id=?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, salle.nom());
            stmt.setString(2, salle.batiment());
            stmt.setString(3, salle.campus());
            stmt.setBoolean(4, salle.videoProjecteur());
            stmt.setInt(5, salle.capacite());
            stmt.setString(6, salle.typeSalle().name());
            stmt.setInt(7, salle.id());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de la salle", e);
        }
    }

    @Override
    public boolean deleteSalle(int id) {
        try {
            // Étape 1 : Supprimer la référence à la salle dans les créneaux existants
            String updateSlotsQuery = "UPDATE CalendarSlot SET salle_id = NULL WHERE salle_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateSlotsQuery)) {
                updateStmt.setInt(1, id);
                updateStmt.executeUpdate();
            }

            // Étape 2 : Supprimer la salle elle-même
            String deleteSalleQuery = "DELETE FROM Salle WHERE id = ?";
            try (PreparedStatement deleteStmt = connection.prepareStatement(deleteSalleQuery)) {
                deleteStmt.setInt(1, id);
                int affectedRows = deleteStmt.executeUpdate();
                return affectedRows > 0;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de la salle", e);
        }
    }

    private SalleDTO mapResultSetToDTO(ResultSet rs) throws SQLException {
        return new SalleDTO(
                rs.getInt("id"),
                rs.getString("nom"),
                rs.getString("batiment"),
                rs.getString("campus"),
                rs.getBoolean("videoProjecteur"),
                rs.getInt("capacite"),
                TypeSalle.valueOf(rs.getString("typeSalle"))
        );
    }

    /**
     * Recherche une salle par nom, bâtiment et campus.
     */
    public Optional<SalleDTO> getSalleByNomAndLieu(String nom, String batiment, String campus) {
        String sql = "SELECT * FROM Salle WHERE nom = ? AND batiment = ? AND campus = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nom);
            stmt.setString(2, batiment);
            stmt.setString(3, campus);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return Optional.of(new SalleDTO(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("batiment"),
                        rs.getString("campus"),
                        rs.getBoolean("videoProjecteur"),
                        rs.getInt("capacite"),
                        TypeSalle.valueOf(rs.getString("typeSalle"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

}

