package fr.univ_amu.m1info.server.dto;

import java.util.List;

public record CalendarDTO(List<CalendarSlotDTO> calendarSlots) {
}
