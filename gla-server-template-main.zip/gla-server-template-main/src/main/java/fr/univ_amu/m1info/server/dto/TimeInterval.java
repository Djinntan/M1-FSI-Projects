package fr.univ_amu.m1info.server.dto;

import java.time.LocalDateTime;

public record TimeInterval(LocalDateTime start, LocalDateTime end) {
}
