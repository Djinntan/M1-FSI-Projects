package fr.univ_amu.m1info.server.dto;

import java.util.List;

public record SalleManagerDTO(List<SalleDTO> salles) {
    public SalleManagerDTO(List<SalleDTO> salles) {
        this.salles = List.copyOf(salles); // ✅ Stocke une copie immuable
    }

    @Override
    public List<SalleDTO> salles() {
        return List.copyOf(salles); // ✅ Retourne une copie non modifiable
    }
}
