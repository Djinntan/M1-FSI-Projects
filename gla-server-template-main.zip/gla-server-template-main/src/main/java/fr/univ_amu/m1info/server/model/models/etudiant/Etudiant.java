package fr.univ_amu.m1info.server.model.models.etudiant;


import fr.univ_amu.m1info.server.model.models.groupe.Groupe;

public class Etudiant {
    private int id;
    private String nom;
    private String prenom;
    private String email;
    private Groupe groupe;

    public Etudiant(int id, String nom, String prenom, String email, Groupe groupe) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.groupe = groupe;
    }

    // Getters & Setters
    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getEmail() { return email; }
    public Groupe getGroupe() { return groupe; }

    public void setGroupe(Groupe groupe) { this.groupe = groupe; }
}
