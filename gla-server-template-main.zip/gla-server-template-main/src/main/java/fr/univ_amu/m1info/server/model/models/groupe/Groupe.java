package fr.univ_amu.m1info.server.model.models.groupe;

import fr.univ_amu.m1info.server.model.models.etudiant.Etudiant;

import java.util.ArrayList;
import java.util.List;

public class Groupe {
    private int id;
    private String nom;
    //private final List<Etudiant> etudiants;

    public Groupe(int id, String nom/*, List<Etudiant> etudiants*/) {
        this.id = id;
        this.nom = nom;
      //  this.etudiants = new ArrayList<>(etudiants);
    }

    public Groupe(String nom) {
        this(-1, nom/*, new ArrayList<>()*/);
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
   // public List<Etudiant> getEtudiants() { return etudiants; }

    public void setId(int id) { this.id = id; }
    public void setNom(String nom) { this.nom = nom; }

    /*public void addEtudiant(Etudiant etudiant) {
        etudiants.add(etudiant);
    }

    public void removeEtudiant(Etudiant etudiant) {
        etudiants.remove(etudiant);
    }*/
}
