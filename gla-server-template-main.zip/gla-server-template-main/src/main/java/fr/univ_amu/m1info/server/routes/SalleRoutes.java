package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.SalleController;
import fr.univ_amu.m1info.server.dto.SalleDTO;
import io.javalin.Javalin;
import io.javalin.http.Context;

public class SalleRoutes {
    private final SalleController salleController;

    public SalleRoutes(SalleController salleController) {
        this.salleController = salleController;
    }

    public void register(Javalin app) {
        app.get("/salles", this::handleGetAllSalles);
        app.get("/salles/{id}", this::handleGetSalleById);
        app.post("/salles", this::handleCreateSalle);
        app.put("/salles", this::handleCreateOrUpdateSalle);
        app.delete("/salles/{id}", this::handleDeleteSalle);
    }

    void handleGetAllSalles(Context ctx) {
        ctx.status(200).json(salleController.getAllSalles());
    }

    void handleGetSalleById(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            SalleDTO salle = salleController.getSalleById(id);
            if (salle != null) {
                ctx.status(200).json(salle);
            } else {
                ctx.status(404).result("Salle non trouvée");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }

    void handleCreateSalle(Context ctx) {
        try {
            SalleDTO salle = ctx.bodyAsClass(SalleDTO.class);
            SalleDTO createdSalle = salleController.createSalle(salle);
            ctx.status(201).json(createdSalle);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    void handleCreateOrUpdateSalle(Context ctx) {
        try {
            SalleDTO salle = ctx.bodyAsClass(SalleDTO.class);
            SalleDTO result = salleController.createOrUpdateSalle(salle);
            ctx.status(200).json(result);
        } catch (Exception e) {
            ctx.status(400).result("Requête invalide");
        }
    }

    void handleDeleteSalle(Context ctx) {
        try {
            int id = Integer.parseInt(ctx.pathParam("id"));
            if (salleController.deleteSalle(id)) {
                ctx.status(204);
            } else {
                ctx.status(404).result("Salle non trouvée");
            }
        } catch (NumberFormatException e) {
            ctx.status(400).result("ID invalide");
        }
    }
}
