package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.database.DatabaseInitializer;
import fr.univ_amu.m1info.server.dao.CalendarDAO;
import fr.univ_amu.m1info.server.dto.CalendarSlotDTO;
import fr.univ_amu.m1info.server.dto.TimeInterval;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.salle.Salle;
import fr.univ_amu.m1info.server.model.technical.Convertor;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CalendarJDBCDAO implements CalendarDAO {

    private final Connection connection;

    public CalendarJDBCDAO(Connection connection) {
        this.connection = connection;
        DatabaseInitializer.initialize(connection);
    }

    @Override
    public void initializeDatabase() {
        DatabaseInitializer.initialize(connection);
    }

    @Override
    public Optional<CalendarSlotDTO> get(Integer key) {
        String query = """
            SELECT cs.id, cs.description, cs.start, cs.end, cs.version, 
                   s.id as salle_id, s.nom as salle_nom, s.batiment, s.campus, s.videoProjecteur, s.capacite, s.typeSalle,
                   e.id as enseignant_id, e.nom as enseignant_nom, e.prenom as enseignant_prenom, e.email as enseignant_email,
                   g.id as groupe_id, g.nom as groupe_nom
            FROM CalendarSlot cs
            LEFT JOIN Salle s ON cs.salle_id = s.id
            LEFT JOIN Enseignant e ON cs.enseignant_id = e.id
            LEFT JOIN Groupe g ON cs.groupe_id = g.id
            WHERE cs.id = ?
        """;
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, key);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToDTO(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération du créneau", e);
        }
        return Optional.empty();
    }

    @Override
    public List<CalendarSlotDTO> getAll() {
        List<CalendarSlotDTO> slots = new ArrayList<>();
        String query = """
            SELECT cs.id, cs.description, cs.start, cs.end, cs.version, 
                   s.id as salle_id, s.nom as salle_nom, s.batiment, s.campus, s.videoProjecteur, s.capacite, s.typeSalle,
                   e.id as enseignant_id, e.nom as enseignant_nom, e.prenom as enseignant_prenom, e.email as enseignant_email,
                   g.id as groupe_id, g.nom as groupe_nom
            FROM CalendarSlot cs
            LEFT JOIN Salle s ON cs.salle_id = s.id
            LEFT JOIN Enseignant e ON cs.enseignant_id = e.id
            LEFT JOIN Groupe g ON cs.groupe_id = g.id
        """;
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                slots.add(mapResultSetToDTO(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la récupération des créneaux", e);
        }
        return slots;
    }

    public Integer create(CalendarSlotDTO element) {
        System.out.println("create");
        String query = "INSERT INTO CalendarSlot (description, start, end, version, salle_id, enseignant_id, groupe_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, element.description());
            stmt.setTimestamp(2, Timestamp.valueOf(element.timeInterval().start()));
            stmt.setTimestamp(3, Timestamp.valueOf(element.timeInterval().end()));
            stmt.setInt(4, element.version());
            stmt.setObject(5, element.salle() != null ? element.salle().id() : null, Types.INTEGER);
            stmt.setObject(6, element.enseignant() != null ? element.enseignant().id() : null, Types.INTEGER);
            stmt.setObject(7, element.groupe() != null ? element.groupe().id() : null, Types.INTEGER);
            stmt.executeUpdate();
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int id = generatedKeys.getInt(1);
                return id;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création du créneau", e);
        }
        return null;
    }

    @Override
    public int update(CalendarSlotDTO element) {
        String query = "UPDATE CalendarSlot SET description = ?, start = ?, end = ?, version = ?, salle_id = ? , enseignant_id = ?, groupe_id=? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, element.description());
            stmt.setTimestamp(2, Timestamp.valueOf(element.timeInterval().start()));
            stmt.setTimestamp(3, Timestamp.valueOf(element.timeInterval().end()));
            stmt.setInt(4, element.version());
            stmt.setObject(5, element.salle() != null ? element.salle().id() : null, Types.INTEGER);
            stmt.setObject(6, element.enseignant() != null ? element.enseignant().id() : null, Types.INTEGER);
            stmt.setObject(7, element.groupe() != null ? element.groupe().id() : null, Types.INTEGER);
            stmt.setInt(8, element.id());
            return stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du créneau", e);
        }
    }


    @Override
    public void delete(CalendarSlotDTO element) {
        String query = "DELETE FROM CalendarSlot WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, element.id());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du créneau", e);
        }
    }

    private CalendarSlotDTO mapResultSetToDTO(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String description = rs.getString("description");
        TimeInterval timeInterval = new TimeInterval(
                rs.getTimestamp("start").toLocalDateTime(),
                rs.getTimestamp("end").toLocalDateTime()
        );
        int version = rs.getInt("version");

        GroupeDTO groupeDTO = null;
        if (rs.getObject("groupe_id") != null) {
            groupeDTO = new GroupeDTO(rs.getInt("groupe_id"), rs.getString("groupe_nom"));
        }

        Salle salle = null;
        if (rs.getObject("salle_id") != null) {
            salle = new Salle(
                    rs.getInt("salle_id"),
                    rs.getString("salle_nom"),
                    rs.getString("batiment"),
                    rs.getString("campus"),
                    rs.getBoolean("videoProjecteur"),
                    rs.getInt("capacite"),
                    Convertor.fromStringToTypeSalle(rs.getString("typeSalle"))
            );
        }

        // Récupération de la liste des groupes via une méthode auxiliaire
        //List<GroupeDTO> groupes = getGroupesForCalendarSlot(id);

        Enseignant enseignant = null;
        if (rs.getObject("enseignant_id") != null) {
            enseignant = new Enseignant(
                    rs.getInt("enseignant_id"),
                    rs.getString("enseignant_nom"),
                    rs.getString("enseignant_prenom"),
                    rs.getString("enseignant_email")
            );
        }


        return new CalendarSlotDTO(
                id,
                description,
                timeInterval,
                version,
                Convertor.toSalleDTO(salle),
                Convertor.toEnseignantDTO(enseignant),
                groupeDTO
        );
    }

    // Méthode auxiliaire pour récupérer les groupes associés à un créneau
    List<GroupeDTO> getGroupesForCalendarSlot(int calendarSlotId) {
        List<GroupeDTO> groupes = new ArrayList<>();
        String query = """
            SELECT g.id, g.nom
            FROM CalendarSlot_Groupe csg
            JOIN Groupe g ON csg.groupe_id = g.id
            WHERE csg.calendarSlot_id = ?
        """;
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, calendarSlotId);
            try (ResultSet rs = stmt.executeQuery()) {
                while(rs.next()){
                    GroupeDTO groupe = new GroupeDTO(
                            rs.getInt("id"),
                            rs.getString("nom")//,
                           // List.of() // Liste d'étudiants laissée vide pour simplifier
                    );
                    groupes.add(groupe);
                }
            }
        } catch(SQLException e){
            throw new RuntimeException("Erreur lors de la récupération des groupes pour le créneau", e);
        }
        return groupes;
    }
}
