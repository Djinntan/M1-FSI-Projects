package fr.univ_amu.m1info.server.model.models.calendar;

import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.models.salle.Salle;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CalendarSlot {

    private int id;
    private LocalDateTime time_begin;
    private LocalDateTime time_end;
    private String description;
    private int version;
    private Salle salle;
    private Enseignant enseignant;
    private Groupe groupe;
    
    public CalendarSlot(int id, LocalDateTime time_begin, LocalDateTime time_end, String description, int version, Salle salle
            , Enseignant enseignant,Groupe groupe) {
        this.id = id;
        this.time_begin = time_begin;
        this.time_end = time_end;
        this.description = description;
        this.version = version;
        this.salle = salle;
        this.groupe = groupe;
        this.enseignant = enseignant;
    }
    
    public CalendarSlot(LocalDateTime time_begin, LocalDateTime time_end, String description, int version, Salle salle, Enseignant enseignant, Groupe groupe) {
        this(-1, time_begin, time_end, description,version,salle,enseignant,groupe);
    }

   
    public int getId() {
        return id;
    }
   
    public int getVersion() {return version;}
    
    public LocalDateTime getTime_begin() {
        return time_begin;
    }
    
    public LocalDateTime getTime_end() {
        return time_end;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public Salle getSalle() {
        return salle;
    }

    public Groupe getGroupe() {
        return groupe;
    }

    public Enseignant getEnseignant() {
        return enseignant;
    }
}
