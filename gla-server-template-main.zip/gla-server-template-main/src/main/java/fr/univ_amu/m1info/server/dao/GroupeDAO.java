package fr.univ_amu.m1info.server.dao;

import fr.univ_amu.m1info.server.dto.GroupeDTO;
import java.util.List;
import java.util.Optional;

public interface GroupeDAO {
    List<GroupeDTO> getAllGroupes();
    Optional<GroupeDTO> getGroupeById(int id);
    int createGroupe(GroupeDTO groupe);
    boolean updateGroupe(GroupeDTO groupe);
    boolean deleteGroupe(int id);
}
