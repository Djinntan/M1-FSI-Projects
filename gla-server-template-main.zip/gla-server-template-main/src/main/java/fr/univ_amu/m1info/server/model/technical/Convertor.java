package fr.univ_amu.m1info.server.model.technical;

import fr.univ_amu.m1info.server.dto.*;
import fr.univ_amu.m1info.server.model.models.calendar.Calendar;
import fr.univ_amu.m1info.server.model.models.calendar.CalendarSlot;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.models.salle.Salle;
import fr.univ_amu.m1info.server.model.models.salle.SalleManager;
import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class for conversion from DTO to model's instance
 */
public class Convertor {

    /**
     * Build the model's instance from the DTO
     * @param calendarSlotDTO the dto
     * @return an instance of CalendarSlot
     */

    public static CalendarSlot fromCalendarSlotDTO(CalendarSlotDTO calendarSlotDTO) {
        return new CalendarSlot(
                calendarSlotDTO.id(),
                calendarSlotDTO.timeInterval().start(),
                calendarSlotDTO.timeInterval().end(),
                calendarSlotDTO.description(),
                calendarSlotDTO.version(),
                calendarSlotDTO.salle() != null ? fromSalleDTO(calendarSlotDTO.salle()) : null,
                calendarSlotDTO.enseignant() != null ? fromEnseignantDTO(calendarSlotDTO.enseignant()) : null,
                calendarSlotDTO.groupe() != null ? fromGroupeDTO(calendarSlotDTO.groupe()) : null
        );
    }

    public static CalendarSlotDTO toCalendarSlotDTO(CalendarSlot calendarSlot) {
        return new CalendarSlotDTO(
                calendarSlot.getId(),
                calendarSlot.getDescription(),
                new TimeInterval(calendarSlot.getTime_begin(), calendarSlot.getTime_end()),
                calendarSlot.getVersion(),
                calendarSlot.getSalle() != null ? toSalleDTO(calendarSlot.getSalle()) : null,
                calendarSlot.getEnseignant() != null ? toEnseignantDTO(calendarSlot.getEnseignant()) : null,
                calendarSlot.getGroupe() != null ? toGroupeDTO(calendarSlot.getGroupe()) : null
        );
    }

    /**
     * Build the model's calendar from the DTO
     * @param calendarDTO the calendar DTO
     * @return an instance of Calendar
     */
    public static Calendar fromCalendarDTO(CalendarDTO calendarDTO) {
        Calendar calendar = new Calendar();
        for (CalendarSlotDTO calendarSlotDTO : calendarDTO.calendarSlots()) {
            calendar.addSlot(fromCalendarSlotDTO(calendarSlotDTO));
        }
        return calendar;
    }

    /**
     * Build the DTO from the  model's instance
     * @param calendar the calendar
     * @return an instance of CalendarDTO
     */
    public static CalendarDTO toCalendarDTO(Calendar calendar) {
        ArrayList<CalendarSlotDTO> calendarSlotDTOs = new ArrayList<>();
        for (CalendarSlot slot : calendar.getSlots()) {
            calendarSlotDTOs.add(toCalendarSlotDTO(slot));
        }
        return new CalendarDTO(calendarSlotDTOs);
    }

    public static Salle fromSalleDTO(SalleDTO salleDTO) {
        if (salleDTO == null) { // ✅ Empêche une NullPointerException
            return null;
        }
        return new Salle(
                salleDTO.id(),
                salleDTO.nom(),
                salleDTO.batiment(),
                salleDTO.campus(),
                salleDTO.videoProjecteur(),
                salleDTO.capacite(),
                salleDTO.typeSalle()
        );
    }

    /**
     * Convertit un `Salle` en `SalleDTO`
     */
    public static SalleDTO toSalleDTO(Salle salle) {
        if (salle == null) { // ✅ Empêche une NullPointerException
            return null;
        }
        return new SalleDTO(
                salle.getId(),
                salle.getNom(),
                salle.getBatiment(),
                salle.getCampus(),
                salle.hasVideoProjecteur(),
                salle.getCapacite(),
                salle.getTypeSalle()
        );
    }

    public static SalleManager fromSalleManagerDTO(SalleManagerDTO salleManagerDTO) {
        SalleManager salleManager = new SalleManager();
        for (SalleDTO salleDTO : salleManagerDTO.salles()) {
            salleManager.addSalle(fromSalleDTO(salleDTO));
        }
        return salleManager;
    }

    /**
     * Convertit `SalleManager` en `SalleManagerDTO`
     */
    public static SalleManagerDTO toSalleManagerDTO(SalleManager salleManager) {
        List<SalleDTO> salleDTOs = salleManager.getSalles().stream()
                .map(Convertor::toSalleDTO)
                .collect(Collectors.toList());
        return new SalleManagerDTO(salleDTOs);
    }

    public static TypeSalle fromStringToTypeSalle(String typeSalleStr) {
        try {
            return TypeSalle.valueOf(typeSalleStr.toUpperCase()); // Convertit la chaîne en enum
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Type de salle invalide : " + typeSalleStr, e);
        }
    }

    public static Groupe fromGroupeDTO(GroupeDTO groupeDTO) {
        if (groupeDTO == null) return null;
        return new Groupe(groupeDTO.id(), groupeDTO.nom()/*, List.of()*/);
    }

    public static GroupeDTO toGroupeDTO(Groupe groupe) {
        if (groupe == null) return null;
        return new GroupeDTO(groupe.getId(), groupe.getNom()/*, List.of()*/);
    }

    public static Enseignant fromEnseignantDTO(EnseignantDTO enseignantDTO) {
        if (enseignantDTO == null) {
            return null;
        }
        return new Enseignant(
                enseignantDTO.id(),
                enseignantDTO.nom(),
                enseignantDTO.prenom(),
                enseignantDTO.email()
        );
    }

    /**
     * Convertit un `Salle` en `SalleDTO`
     */
    public static EnseignantDTO toEnseignantDTO(Enseignant enseignant) {
        if (enseignant == null) {
            return null;
        }
        return new EnseignantDTO(
                enseignant.getId(),
                enseignant.getNom(),
                enseignant.getPrenom(),
                enseignant.getEmail()

        );
    }

}
