package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.EnseignantDAO;
import fr.univ_amu.m1info.server.database.entities.EnseignantJDBCDAO;
import fr.univ_amu.m1info.server.dto.EnseignantDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EnseignantControllerTest {

    private EnseignantController enseignantController;
    private EnseignantJDBCDAO mockEnseignantDAO;

    private EnseignantDTO mockEnseignant;

    @BeforeEach
    void setUp() {
        // Mock DAO
        mockEnseignantDAO = mock(EnseignantJDBCDAO.class);

        // Initialize Controller with Mock DAO
        enseignantController = new EnseignantController(mockEnseignantDAO);

        // Mock Enseignant Data
        mockEnseignant = new EnseignantDTO(1, "John", "Doe", "johndoe@university.com");
    }

    @Test
    void testGetAllEnseignants() {
        List<EnseignantDTO> enseignants = List.of(mockEnseignant);

        when(mockEnseignantDAO.getAllEnseignants()).thenReturn(enseignants);

        List<EnseignantDTO> result = enseignantController.getAllEnseignants();

        assertEquals(1, result.size());
        assertEquals("John", result.get(0).nom());
        verify(mockEnseignantDAO).getAllEnseignants();
    }

    @Test
    void testGetEnseignantById_Found() {
        when(mockEnseignantDAO.getEnseignantById(1)).thenReturn(Optional.of(mockEnseignant));

        EnseignantDTO result = enseignantController.getEnseignantById(1);

        assertNotNull(result);
        assertEquals("John", result.nom());
        verify(mockEnseignantDAO).getEnseignantById(1);
    }

    @Test
    void testGetEnseignantById_NotFound() {
        when(mockEnseignantDAO.getEnseignantById(1)).thenReturn(Optional.empty());

        EnseignantDTO result = enseignantController.getEnseignantById(1);

        assertNull(result);
        verify(mockEnseignantDAO).getEnseignantById(1);
    }

    @Test
    void testCreateEnseignant_Success() {
        when(mockEnseignantDAO.createEnseignant(mockEnseignant)).thenReturn(1);

        EnseignantDTO result = enseignantController.createEnseignant(mockEnseignant);

        assertNotNull(result);
        assertEquals(1, result.id());
        assertEquals("John", result.nom());
        verify(mockEnseignantDAO).createEnseignant(mockEnseignant);
    }

    @Test
    void testCreateEnseignant_Null_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> enseignantController.createEnseignant(null));
    }

    @Test
    void testUpdateEnseignant_Success() {
        when(mockEnseignantDAO.getEnseignantById(1)).thenReturn(Optional.of(mockEnseignant));
        when(mockEnseignantDAO.updateEnseignant(any())).thenReturn(true);

        boolean result = enseignantController.updateEnseignant(1, mockEnseignant);

        assertTrue(result);
        verify(mockEnseignantDAO).getEnseignantById(1);
        verify(mockEnseignantDAO).updateEnseignant(any());
    }

    @Test
    void testUpdateEnseignant_NotFound() {
        when(mockEnseignantDAO.getEnseignantById(1)).thenReturn(Optional.empty());

        boolean result = enseignantController.updateEnseignant(1, mockEnseignant);

        assertFalse(result);
        verify(mockEnseignantDAO).getEnseignantById(1);
        verify(mockEnseignantDAO, never()).updateEnseignant(any());
    }

    @Test
    void testDeleteEnseignant_Success() {
        when(mockEnseignantDAO.deleteEnseignant(1)).thenReturn(true);

        boolean result = enseignantController.deleteEnseignant(1);

        assertTrue(result);
        verify(mockEnseignantDAO).deleteEnseignant(1);
    }

    @Test
    void testCreateOrUpdateEnseignant_CreateNew() {
        when(mockEnseignantDAO.getEnseignantByEmail(mockEnseignant.email())).thenReturn(Optional.empty());
        when(mockEnseignantDAO.createEnseignant(mockEnseignant)).thenReturn(1);

        EnseignantDTO result = enseignantController.createOrUpdateEnseignant(mockEnseignant);

        assertNotNull(result);
        assertEquals(1, result.id());
        verify(mockEnseignantDAO).getEnseignantByEmail(mockEnseignant.email());
        verify(mockEnseignantDAO).createEnseignant(mockEnseignant);
    }

    @Test
    void testCreateOrUpdateEnseignant_UpdateExisting() {
        EnseignantDTO existingEnseignant = new EnseignantDTO(1, "John", "Doe", "johndoe@university.com");

        when(mockEnseignantDAO.getEnseignantByEmail(mockEnseignant.email())).thenReturn(Optional.of(existingEnseignant));
        when(mockEnseignantDAO.updateEnseignant(any())).thenReturn(true);

        EnseignantDTO result = enseignantController.createOrUpdateEnseignant(mockEnseignant);

        assertNotNull(result);
        assertEquals(1, result.id());
        verify(mockEnseignantDAO).getEnseignantByEmail(mockEnseignant.email());
        verify(mockEnseignantDAO).updateEnseignant(any());
    }

    @Test
    void testCreateOrUpdateEnseignant_Null_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> enseignantController.createOrUpdateEnseignant(null));
    }
}
