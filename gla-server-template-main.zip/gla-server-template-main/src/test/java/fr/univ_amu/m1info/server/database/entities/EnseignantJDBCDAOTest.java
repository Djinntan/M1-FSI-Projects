package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dto.EnseignantDTO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import java.sql.*;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EnseignantJDBCDAOTest {
    private EnseignantJDBCDAO enseignantJDBCDAO;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;
    private Statement mockStatement;
    private GroupeDTO mockGroupe;
    private EtudiantJDBCDAO etudiantJDBCDAO;

    @BeforeEach
    void setUp() throws Exception {
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
        mockStatement = mock(Statement.class);

        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);

        enseignantJDBCDAO = new EnseignantJDBCDAO(mockConnection);
        etudiantJDBCDAO = new EtudiantJDBCDAO(mockConnection);
        mockGroupe = new GroupeDTO(1, "Groupe A");
    }

    @Test
    void testGetEtudiantByEmail_Found() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("etudiant_id")).thenReturn(1);
        when(mockResultSet.getString("etudiant_nom")).thenReturn("Doe");
        when(mockResultSet.getString("etudiant_prenom")).thenReturn("John");
        when(mockResultSet.getString("etudiant_email")).thenReturn("john.doe@example.com");
        when(mockResultSet.getInt("groupe_id")).thenReturn(1);
        when(mockResultSet.getString("groupe_nom")).thenReturn("Groupe A");

        Optional<EtudiantDTO> result = etudiantJDBCDAO.getEtudiantByEmail("john.doe@example.com");

        assertTrue(result.isPresent());
        assertEquals("Doe", result.get().nom());
    }

    @Test
    void testGetEtudiantByEmail_NotFound() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);

        Optional<EtudiantDTO> result = etudiantJDBCDAO.getEtudiantByEmail("john.doe@example.com");

        assertFalse(result.isPresent());
    }
    @Test
    void testCreateEtudiant_VerifyParameters() throws SQLException {
        EtudiantDTO etudiant = new EtudiantDTO(0, "Doe", "John", "john.doe@example.com", mockGroupe);

        // Mocking the execution and generated keys behavior
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(123); // Simulated generated ID

        etudiantJDBCDAO.createEtudiant(etudiant);

        // Verify the correct values were set on the PreparedStatement
        verify(mockPreparedStatement).setString(1, etudiant.nom());
        verify(mockPreparedStatement).setString(2, etudiant.prenom());
        verify(mockPreparedStatement).setString(3, etudiant.email());
        verify(mockPreparedStatement).setObject(4, etudiant.groupe().id(), Types.INTEGER);

        // Ensure we retrieved generated keys
        verify(mockPreparedStatement).getGeneratedKeys();
        verify(mockResultSet).next();
    }


    @Test
    void testUpdateEtudiant_VerifyParameters() throws SQLException {
        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);

        etudiantJDBCDAO.updateEtudiant(etudiant);

        verify(mockPreparedStatement).setString(1, etudiant.nom());
        verify(mockPreparedStatement).setString(2, etudiant.prenom());
        verify(mockPreparedStatement).setString(3, etudiant.email());
        verify(mockPreparedStatement).setObject(4, etudiant.groupe().id(), Types.INTEGER);
        verify(mockPreparedStatement).setInt(5, etudiant.id());
    }
    @Test
    void testGetAllEnseignants() throws SQLException {
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("John");
        when(mockResultSet.getString("prenom")).thenReturn("Doe");
        when(mockResultSet.getString("email")).thenReturn("john.doe@example.com");

        List<EnseignantDTO> enseignants = enseignantJDBCDAO.getAllEnseignants();
        assertEquals(1, enseignants.size());
        assertEquals("John", enseignants.get(0).nom());
    }

    @Test
    void testGetAllEnseignants_EmptyResult() throws SQLException {
        when(mockResultSet.next()).thenReturn(false);

        List<EnseignantDTO> enseignants = enseignantJDBCDAO.getAllEnseignants();
        assertTrue(enseignants.isEmpty());
    }

    @Test
    void testGetAllEnseignants_ThrowsSQLException() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenThrow(new SQLException("Database error"));

        assertThrows(RuntimeException.class, () -> enseignantJDBCDAO.getAllEnseignants());
    }

    @Test
    void testGetEnseignantById_Found() throws SQLException {
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("John");
        when(mockResultSet.getString("prenom")).thenReturn("Doe");
        when(mockResultSet.getString("email")).thenReturn("john.doe@example.com");

        Optional<EnseignantDTO> enseignant = enseignantJDBCDAO.getEnseignantById(1);
        assertTrue(enseignant.isPresent());
        assertEquals("John", enseignant.get().nom());
    }

    @Test
    void testGetEnseignantById_NotFound() throws SQLException {
        when(mockResultSet.next()).thenReturn(false);

        Optional<EnseignantDTO> enseignant = enseignantJDBCDAO.getEnseignantById(1);
        assertFalse(enseignant.isPresent());
    }

    @Test
    void testGetEnseignantById_ThrowsSQLException() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("Database error"));

        assertThrows(RuntimeException.class, () -> enseignantJDBCDAO.getEnseignantById(1));
    }

    @Test
    void testGetEnseignantByEmail_Found() throws SQLException {
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("John");
        when(mockResultSet.getString("prenom")).thenReturn("Doe");
        when(mockResultSet.getString("email")).thenReturn("john.doe@example.com");

        Optional<EnseignantDTO> enseignant = enseignantJDBCDAO.getEnseignantByEmail("john.doe@example.com");
        assertTrue(enseignant.isPresent());
        assertEquals("John", enseignant.get().nom());
    }

    @Test
    void testGetEnseignantByEmail_NotFound() throws SQLException {
        when(mockResultSet.next()).thenReturn(false);

        Optional<EnseignantDTO> enseignant = enseignantJDBCDAO.getEnseignantByEmail("unknown@example.com");
        assertFalse(enseignant.isPresent());
    }

    @Test
    void testCreateEnseignant_Success() throws SQLException {
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1);

        EnseignantDTO newEnseignant = new EnseignantDTO(0, "John", "Doe", "john.doe@example.com");
        int generatedId = enseignantJDBCDAO.createEnseignant(newEnseignant);

        assertEquals(1, generatedId);
        verify(mockPreparedStatement, atLeastOnce()).executeUpdate();
    }

    @Test
    void testCreateEnseignant_Fails() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenThrow(new SQLException("Insert error"));

        EnseignantDTO newEnseignant = new EnseignantDTO(0, "John", "Doe", "john.doe@example.com");

        assertThrows(RuntimeException.class, () -> enseignantJDBCDAO.createEnseignant(newEnseignant));
    }

    @Test
    void testUpdateEnseignant_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        EnseignantDTO updatedEnseignant = new EnseignantDTO(1, "John", "Smith", "john.smith@example.com");
        boolean updated = enseignantJDBCDAO.updateEnseignant(updatedEnseignant);

        assertTrue(updated);
        verify(mockPreparedStatement).setString(1, "John");
        verify(mockPreparedStatement).setString(2, "Smith");
        verify(mockPreparedStatement).setString(3, "john.smith@example.com");
        verify(mockPreparedStatement).setInt(4, 1);
    }

    @Test
    void testDeleteEnseignant_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean deleted = enseignantJDBCDAO.deleteEnseignant(1);

        assertTrue(deleted);
        verify(mockPreparedStatement, atLeastOnce()).executeUpdate();
    }

    @Test
    void testDeleteEnseignant_Fails() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(0);

        boolean deleted = enseignantJDBCDAO.deleteEnseignant(1);
        assertFalse(deleted);
    }

    @Test
    void testDeleteEnseignant_ThrowsSQLException() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenThrow(new SQLException("Delete error"));

        assertThrows(RuntimeException.class, () -> enseignantJDBCDAO.deleteEnseignant(1));
    }

}
