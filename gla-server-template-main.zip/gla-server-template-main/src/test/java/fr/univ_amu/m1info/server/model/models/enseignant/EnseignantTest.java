package fr.univ_amu.m1info.server.model.models.enseignant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnseignantTest {
    private Enseignant enseignant;

    @BeforeEach
    void setUp() {
        enseignant = new Enseignant(1, "John", "Doe", "john.doe@example.com");
    }

    @Test
    void testGetId() {
        assertEquals(1, enseignant.getId());
    }

    @Test
    void testGetNom() {
        assertEquals("John", enseignant.getNom());
    }

    @Test
    void testGetPrenom() {
        assertEquals("Doe", enseignant.getPrenom());
    }

    @Test
    void testGetEmail() {
        assertEquals("john.doe@example.com", enseignant.getEmail());
    }
}
