//package fr.univ_amu.m1info.server.model;
//
//import org.junit.jupiter.api.Test;
//
//import java.time.LocalDateTime;
//import java.time.Month;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//class CalendarTest {
//
//    @Test
//    void addSlot() {
//        LocalDateTime startCM = LocalDateTime.of(2025, Month.JANUARY, 8, 8, 30, 0);
//        LocalDateTime endCM = LocalDateTime.of(2025, Month.JANUARY, 8, 8, 30, 0);
//
//        CalendarSlot calendarSlot = new CalendarSlot(startCM, endCM, "CM GLA",0);
//        Calendar calendar = new Calendar();
//        calendar.addSlot(calendarSlot);
//
//        assertEquals(calendarSlot, calendar.getSlots().getFirst());
//    }
//
//    @Test
//    void getSlots() {
//        Calendar calendar = new Calendar();
//        assertTrue(calendar.getSlots().isEmpty());
//    }
//}