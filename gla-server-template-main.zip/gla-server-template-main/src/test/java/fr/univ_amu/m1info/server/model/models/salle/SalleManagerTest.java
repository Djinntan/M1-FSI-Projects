package fr.univ_amu.m1info.server.model.models.salle;

import org.junit.jupiter.api.*;
import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SalleManagerTest {
    private SalleManager salleManager;
    private Salle salle1;
    private Salle salle2;

    @BeforeEach
    void setUp() {
        salleManager = new SalleManager();
        salle1 = new Salle(0, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);
        salle2 = new Salle(0, "Salle B", "Batiment C", "Campus Y", false, 50, TypeSalle.TD);
    }

    @Test
    void testAddSalle() {
        salleManager.addSalle(salle1);
        List<Salle> salles = salleManager.getSalles();
        assertEquals(1, salles.size());
        assertEquals(1, salles.get(0).getId());
    }

    @Test
    void testRemoveSalle() {
        salleManager.addSalle(salle1);
        salleManager.removeSalle(salle1.getId());
        assertTrue(salleManager.getSalles().isEmpty());
    }

    @Test
    void testGetSalles() {
        salleManager.addSalle(salle1);
        salleManager.addSalle(salle2);
        List<Salle> salles = salleManager.getSalles();
        assertEquals(2, salles.size());
    }

    @Test
    void testGetSalleById_Found() {
        salleManager.addSalle(salle1);
        Optional<Salle> result = salleManager.getSalleById(1);
        assertTrue(result.isPresent());
        assertEquals("Salle A", result.get().getNom());
    }

    @Test
    void testGetSalleById_NotFound() {
        Optional<Salle> result = salleManager.getSalleById(999);
        assertTrue(result.isEmpty());
    }

    @Test
    void testUpdateSalle_Success() {
        salleManager.addSalle(salle1);
        Salle updatedSalle = new Salle(1, "Updated Salle", "Updated Batiment", "Updated Campus", false, 200, TypeSalle.TD);
        boolean success = salleManager.updateSalle(updatedSalle);
        assertTrue(success);
        assertEquals("Updated Salle", salleManager.getSalleById(1).get().getNom());
    }

    @Test
    void testUpdateSalle_Failure() {
        Salle updatedSalle = new Salle(999, "Non-existent Salle", "Batiment X", "Campus Y", false, 200, TypeSalle.TD);
        boolean success = salleManager.updateSalle(updatedSalle);
        assertFalse(success);
    }

    @Test
    void testGetSalleByNomAndLieu_Found() {
        salleManager.addSalle(salle1);
        Optional<Salle> result = salleManager.getSalleByNomAndLieu("Salle A", "Batiment B", "Campus X");
        assertTrue(result.isPresent());
    }

    @Test
    void testGetSalleByNomAndLieu_NotFound() {
        Optional<Salle> result = salleManager.getSalleByNomAndLieu("Salle X", "Batiment Y", "Campus Z");
        assertTrue(result.isEmpty());
    }
}
