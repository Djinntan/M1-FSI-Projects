package fr.univ_amu.m1info.server.database;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DatabaseInitializerTest {

    @Mock private Connection mockConnection;
    @Mock private Statement mockStatement;

    @BeforeEach
    void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.execute(anyString())).thenReturn(true); // Ensure execute() is stubbed correctly
    }

    @Test
    void testInitialize_Success() throws SQLException {
        when(mockStatement.execute(anyString())).thenReturn(true);

        assertDoesNotThrow(() -> DatabaseInitializer.initialize(mockConnection));
        verify(mockStatement, atLeastOnce()).execute(anyString());
    }

    @Test
    void testInitialize_Failure() throws SQLException {
        when(mockConnection.createStatement()).thenThrow(new SQLException("Database error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> DatabaseInitializer.initialize(mockConnection));
        assertTrue(exception.getMessage().contains("Erreur lors de l'initialisation de la base de données"));
    }
}
