package fr.univ_amu.m1info.server.model.models.salle;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class SalleTest {
    private Salle salle;

    @BeforeEach
    void setUp() {
        salle = new Salle(1, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);
    }

    @Test
    void testGetId() {
        assertEquals(1, salle.getId());
    }

    @Test
    void testGetNom() {
        assertEquals("Salle A", salle.getNom());
    }

    @Test
    void testGetBatiment() {
        assertEquals("Batiment B", salle.getBatiment());
    }

    @Test
    void testGetCampus() {
        assertEquals("Campus X", salle.getCampus());
    }

    @Test
    void testHasVideoProjecteur() {
        assertTrue(salle.hasVideoProjecteur());
    }

    @Test
    void testGetCapacite() {
        assertEquals(100, salle.getCapacite());
    }

    @Test
    void testGetTypeSalle() {
        assertEquals(TypeSalle.AMPHITHEATRE, salle.getTypeSalle());
    }

    @Test
    void testSetId() {
        salle.setId(10);
        assertEquals(10, salle.getId());
    }

    @Test
    void testSetNom() {
        salle.setNom("Salle B");
        assertEquals("Salle B", salle.getNom());
    }

    @Test
    void testSetBatiment() {
        salle.setBatiment("Batiment C");
        assertEquals("Batiment C", salle.getBatiment());
    }

    @Test
    void testSetCampus() {
        salle.setCampus("Campus Y");
        assertEquals("Campus Y", salle.getCampus());
    }

    @Test
    void testSetVideoProjecteur() {
        salle.setVideoProjecteur(false);
        assertFalse(salle.hasVideoProjecteur());
    }

    @Test
    void testSetCapacite() {
        salle.setCapacite(200);
        assertEquals(200, salle.getCapacite());
    }

    @Test
    void testSetTypeSalle() {
        salle.setTypeSalle(TypeSalle.TD);
        assertEquals(TypeSalle.TD, salle.getTypeSalle());
    }
}
