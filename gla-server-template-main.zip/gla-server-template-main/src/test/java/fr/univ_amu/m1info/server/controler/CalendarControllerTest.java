package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.CalendarDAO;
import fr.univ_amu.m1info.server.dto.*;
import fr.univ_amu.m1info.server.model.exceptions.WrongVersionException;
import fr.univ_amu.m1info.server.model.exceptions.UnknownElementException;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import org.junit.jupiter.api.*;
import org.mockito.*;
import java.time.LocalDateTime;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CalendarControllerTest {

    private CalendarController calendarController;
    private EnseignantDTO mockEnseignant;
    private GroupeDTO mockGroupe;
    @Mock private CalendarDAO mockDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockEnseignant = mock(EnseignantDTO.class);
        mockGroupe  = mock(GroupeDTO.class);
        calendarController = new CalendarController(mockDao);
    }

    @Test
    void testGetAllSlots_ReturnsSlots() {
        List<CalendarSlotDTO> slots = List.of(new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null, mockEnseignant, mockGroupe));
        when(mockDao.getAll()).thenReturn(slots);

        List<CalendarSlotDTO> result = calendarController.getAllSlots();

        assertEquals(1, result.size());
        assertEquals("Meeting", result.get(0).description());
    }

    @Test
    void testGetAllSlots_EmptyList() {
        when(mockDao.getAll()).thenReturn(Collections.emptyList());
        assertTrue(calendarController.getAllSlots().isEmpty());
    }

    @Test
    void testCreateSlot_Success() {
        CalendarSlotDTO slot = new CalendarSlotDTO(0, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null, mockEnseignant,mockGroupe);
        when(mockDao.create(slot)).thenReturn(1);

        CalendarSlotDTO createdSlot = calendarController.createSlot(slot);

        assertNotNull(createdSlot);
        assertEquals(1, createdSlot.id());
    }

    @Test
    void testCreateSlot_NullSlot_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> calendarController.createSlot(null));
    }

    @Test
    void testUpdateSlot_Success() throws WrongVersionException, UnknownElementException {
        CalendarSlotDTO existingSlot = new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null, mockEnseignant,mockGroupe);
        CalendarSlotDTO updatedSlot = new CalendarSlotDTO(1, "Updated Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(2)), 1, null , mockEnseignant,mockGroupe);
        when(mockDao.get(1)).thenReturn(Optional.of(existingSlot));

        CalendarSlotDTO result = calendarController.updateSlot(1, updatedSlot);

        assertEquals("Updated Meeting", result.description());
        verify(mockDao).update(any(CalendarSlotDTO.class));
    }

    @Test
    void testUpdateSlot_WrongVersion_ThrowsException() {
        CalendarSlotDTO existingSlot = new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null , mockEnseignant,mockGroupe);
        CalendarSlotDTO updatedSlot = new CalendarSlotDTO(1, "Updated Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(2)), 2, null , mockEnseignant,mockGroupe);
        when(mockDao.get(1)).thenReturn(Optional.of(existingSlot));

        assertThrows(WrongVersionException.class, () -> calendarController.updateSlot(1, updatedSlot));
    }

    @Test
    void testUpdateSlot_UnknownElement_ThrowsException() {
        CalendarSlotDTO updatedSlot = new CalendarSlotDTO(1, "Updated Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(2)), 1, null , mockEnseignant,mockGroupe);
        when(mockDao.get(1)).thenReturn(Optional.empty());

        assertThrows(UnknownElementException.class, () -> calendarController.updateSlot(1, updatedSlot));
    }

    @Test
    void testDeleteSlot_Success() {
        CalendarSlotDTO existingSlot = new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null , mockEnseignant,mockGroupe);
        when(mockDao.get(1)).thenReturn(Optional.of(existingSlot));

        assertTrue(calendarController.deleteSlot(1));
        verify(mockDao).delete(existingSlot);
    }

    @Test
    void testDeleteSlot_NotFound() {
        when(mockDao.get(1)).thenReturn(Optional.empty());
        assertFalse(calendarController.deleteSlot(1));
    }

    @Test
    void testGetCalendarSlotById_Found() {
        CalendarSlotDTO slot = new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, null , mockEnseignant,mockGroupe);
        when(mockDao.get(1)).thenReturn(Optional.of(slot));

        assertEquals(slot, calendarController.getCalendarSlotById(1));
    }

    @Test
    void testGetCalendarSlotById_NotFound() {
        when(mockDao.get(1)).thenReturn(Optional.empty());
        assertNull(calendarController.getCalendarSlotById(1));
    }
    @Test
    void testGetCalendarSlotsIn_ReturnsMatchingSlots() {
        CalendarSlotDTO slot1 = new CalendarSlotDTO(1, "Morning Meeting", new TimeInterval(
                LocalDateTime.of(2024, 2, 10, 9, 0), LocalDateTime.of(2024, 2, 10, 10, 0)), 1, null , mockEnseignant,mockGroupe);
        CalendarSlotDTO slot2 = new CalendarSlotDTO(2, "Afternoon Meeting", new TimeInterval(
                LocalDateTime.of(2024, 2, 10, 14, 0), LocalDateTime.of(2024, 2, 10, 15, 0)), 1, null , mockEnseignant,mockGroupe);
        List<CalendarSlotDTO> allSlots = List.of(slot1, slot2);
        when(mockDao.getAll()).thenReturn(allSlots);

        // Adjusted TimeInterval to ensure both slots fall within range based on the filtering logic
        TimeInterval interval = new TimeInterval(LocalDateTime.of(2024, 2, 10, 8, 59),
                LocalDateTime.of(2024, 2, 10, 15, 1));
        CalendarDTO result = calendarController.getCalendarSlotsIn(interval);

        assertEquals(2, result.calendarSlots().size());
    }


    @Test
    void testGetCalendarSlotsIn_NoMatchingSlots() {
        CalendarSlotDTO slot = new CalendarSlotDTO(1, "Meeting", new TimeInterval(
                LocalDateTime.of(2024, 2, 10, 18, 0), LocalDateTime.of(2024, 2, 10, 19, 0)), 1, null , mockEnseignant,mockGroupe);
        when(mockDao.getAll()).thenReturn(List.of(slot));

        TimeInterval interval = new TimeInterval(LocalDateTime.of(2024, 2, 10, 8, 0), LocalDateTime.of(2024, 2, 10, 16, 0));
        CalendarDTO result = calendarController.getCalendarSlotsIn(interval);

        assertEquals(0, result.calendarSlots().size());
    }
}
