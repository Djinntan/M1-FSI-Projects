/*package fr.univ_amu.m1info.server.model;

import fr.univ_amu.m1info.server.controler.CalendarController;
import fr.univ_amu.m1info.server.dto.CalendarSlotDTO;
import fr.univ_amu.m1info.server.dto.TimeInterval;
import io.javalin.Javalin;
import io.javalin.testtools.JavalinTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ServerAppTest {

    private CalendarController mockController;
    private  ServerApp serverApp;
    private static TimeInterval mockTimeInterval = new TimeInterval(
            LocalDateTime.of(2024, 1, 1, 9, 0),
            LocalDateTime.of(2024, 1, 1, 17, 0)
    );

    @BeforeEach
    void setUp() {
        mockController = Mockito.mock(CalendarController.class);
        serverApp = new ServerApp();
    }

    @Disabled
    void testGetTimeslotsEndpoint() {

        //when(mockController.getCalendarSlotsIn(mockTimeInterval)).thenReturn(List.of());

        JavalinTest.test(Javalin.create(), (server, client) -> {
            server.get("/timeslots/{dateInterval}", ctx -> {
                ctx.json(mockController.getCalendarSlotsIn(mockTimeInterval));
            });

            var response = client.get("/timeslots/2024-01-01&2024-01-02");
            //assertEquals(200, response.getStatus());
            verify(mockController).getCalendarSlotsIn(any());
        });
    }

    @Disabled
    void testPostTimeslotEndpoint() {
        // Mock the controller's behavior

        CalendarSlotDTO mockSlot = new CalendarSlotDTO(5, "Test Description", mockTimeInterval);
        when(mockController.createSlot(any())).thenReturn(mockSlot);

        JavalinTest.test(Javalin.create(), (server, client) -> {
            server.post("/timeslots", ctx -> {
                ctx.status(201).json(mockController.createSlot(ctx.bodyAsClass(CalendarSlotDTO.class)));
            });

            var response = client.post("/timeslots", mockSlot);
            //assertEquals(201, response.getStatus());
            verify(mockController).createSlot(any());
        });
    }

    @Disabled
    void testPutTimeslotEndpoint() {
        CalendarSlotDTO mockUpdatedSlot = new CalendarSlotDTO(6, "Updated Description", mockTimeInterval);

        when(mockController.updateSlot(anyInt(), any())).thenReturn(mockUpdatedSlot);

        JavalinTest.test(Javalin.create(), (server, client) -> {
            server.put("/timeslots/{id}", ctx -> {
                ctx.json(mockController.updateSlot(
                        Integer.parseInt(ctx.pathParam("id")),
                        ctx.bodyAsClass(CalendarSlotDTO.class)
                ));
            });

            var response = client.put("/timeslots/1", mockUpdatedSlot);
           // assertEquals(200, response.getStatus());
            verify(mockController).updateSlot(eq(1), any());
        });
    }

    @Disabled
    void testDeleteTimeslotEndpoint() {
        // Test the DELETE endpoint
        JavalinTest.test(Javalin.create(), (server, client) -> {
            server.delete("/timeslots/{id}", ctx -> {
                mockController.deleteSlot(Integer.parseInt(ctx.pathParam("id")));
                ctx.status(204);
            });

            var response = client.delete("/timeslots/1");
            //assertEquals(204, response.getStatus());
            verify(mockController).deleteSlot(eq(1));
        });
    }
}*/
