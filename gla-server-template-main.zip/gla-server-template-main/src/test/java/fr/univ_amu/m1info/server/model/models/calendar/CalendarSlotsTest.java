package fr.univ_amu.m1info.server.model.models.calendar;

import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.models.salle.Salle;
import org.junit.jupiter.api.*;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CalendarSlotsTest {
    private CalendarSlot calendarSlot;
    private Salle mockSalle;
    private Enseignant mockEnseignant;
    private Groupe mockGroupes;

    @BeforeEach
    void setUp() {
        mockSalle = mock(Salle.class);
        mockGroupes = mock(Groupe.class);
        mockEnseignant = new Enseignant(1, "John", "Doe", "johndoe@university.com");
        calendarSlot = new CalendarSlot(1, LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Test Slot", 1, mockSalle, mockEnseignant, mockGroupes);
    }

    @Test
    void testGetId() {
        assertEquals(1, calendarSlot.getId());
    }

    @Test
    void testGetTimeBegin() {
        assertNotNull(calendarSlot.getTime_begin());
    }

    @Test
    void testGetTimeEnd() {
        assertNotNull(calendarSlot.getTime_end());
    }

    @Test
    void testGetDescription() {
        assertEquals("Test Slot", calendarSlot.getDescription());
    }

    @Test
    void testGetVersion() {
        assertEquals(1, calendarSlot.getVersion());
    }

    @Test
    void testSetId() {
        calendarSlot.setId(10);
        assertEquals(10, calendarSlot.getId());
    }

    @Test
    void testGetSalle() {
        assertEquals(mockSalle, calendarSlot.getSalle());
    }

    @Test
    void testGetEnseignant() {
        assertEquals(mockEnseignant, calendarSlot.getEnseignant());
    }
}
