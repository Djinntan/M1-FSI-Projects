package fr.univ_amu.m1info.server.database;

import fr.univ_amu.m1info.server.database.entities.GroupeJDBCDAO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;

import java.sql.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;


class GroupeJDBCDAOTest {

    private GroupeJDBCDAO groupeJDBCDAO;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;
    private Statement mockStatement;

    @BeforeEach
    void setUp() throws Exception {
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
        mockStatement = mock(Statement.class);

        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockConnection.createStatement()).thenReturn(mockStatement);

        groupeJDBCDAO = new GroupeJDBCDAO(mockConnection);
    }

    @Test
    void testGetAllGroupes_ReturnsList() throws SQLException {
        when(mockStatement.executeQuery("SELECT id, nom FROM Groupe"))
                .thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Groupe A");

        List<GroupeDTO> result = groupeJDBCDAO.getAllGroupes();

        assertEquals(1, result.size());
        assertEquals("Groupe A", result.get(0).nom());
    }

    @Test
    void testGetGroupeById_Found() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Groupe A");

        GroupeJDBCDAO spyDAO = spy(groupeJDBCDAO);
        doReturn(Collections.emptyList()).when(spyDAO).getEtudiantsForGroupe(1);

        Optional<GroupeDTO> result = spyDAO.getGroupeById(1);

        assertTrue(result.isPresent());
        assertEquals("Groupe A", result.get().nom());
    }

    @Test
    void testCreateGroupe_Success() throws SQLException {
        GroupeDTO groupe = new GroupeDTO(0, "Groupe A");
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1);

        int generatedId = groupeJDBCDAO.createGroupe(groupe);
        assertEquals(1, generatedId);
    }

    @Test
    void testUpdateGroupe_Success() throws SQLException {
        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = groupeJDBCDAO.updateGroupe(groupe);
        assertTrue(success);
    }

    @Test
    void testDeleteGroupe_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = groupeJDBCDAO.deleteGroupe(1);
        assertTrue(success);
    }

    @Test
    void testGetAllGroupes_HandlesSQLException() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> groupeJDBCDAO.getAllGroupes());
    }

    @Test
    void testGetGroupeById_HandlesSQLException() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> groupeJDBCDAO.getGroupeById(1));
    }

    @Test
    void testInsertGroupeEtudiant_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);

        groupeJDBCDAO.insertGroupeEtudiant(1, 1);

        verify(mockPreparedStatement, times(1)).executeUpdate();
    }

    @Test
    void testGetEtudiantsForGroupe_ReturnsList() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true, true, false);
        when(mockResultSet.getInt("id")).thenReturn(1, 2);
        when(mockResultSet.getString("nom")).thenReturn("Doe", "Smith");
        when(mockResultSet.getString("prenom")).thenReturn("John", "Jane");
        when(mockResultSet.getString("numero")).thenReturn("12345", "67890");
        when(mockResultSet.getString("email")).thenReturn("john.doe@example.com", "jane.smith@example.com");

        List<EtudiantDTO> result = groupeJDBCDAO.getEtudiantsForGroupe(1);
        assertEquals(2, result.size());
    }

    @Test
    void testGetEtudiantsForGroupe_HandlesSQLException() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("DB Error"));
        assertThrows(SQLException.class, () -> groupeJDBCDAO.getEtudiantsForGroupe(1));
    }
}
