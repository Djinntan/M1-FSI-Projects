package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.EtudiantController;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EtudiantRoutesTest {
    @Mock
    private EtudiantController etudiantController;
    @Mock
    private Context ctx;
    private EtudiantRoutes etudiantRoutes;

    @BeforeEach
    public void setUp() {
        etudiantRoutes = new EtudiantRoutes(etudiantController);
        lenient().when(ctx.status(anyInt())).thenReturn(ctx);
        lenient().when(ctx.json(any())).thenReturn(ctx);
        lenient().when(ctx.result(anyString())).thenReturn(ctx);
    }

    private EtudiantDTO createDummyEtudiant() {
        return new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", null);
    }

    @Test
    public void testHandleGetAllEtudiants() {
        List<EtudiantDTO> etudiants = List.of(createDummyEtudiant());
        when(etudiantController.getAllEtudiants()).thenReturn(etudiants);

        etudiantRoutes.handleGetAllEtudiants(ctx);

        verify(ctx).status(200);
        verify(ctx).json(etudiants);
    }

    @Test
    public void testHandleGetEtudiantById_Found() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(etudiantController.getEtudiantById(1)).thenReturn(createDummyEtudiant());

        etudiantRoutes.handleGetEtudiantById(ctx);

        verify(ctx).status(200);
        verify(ctx).json(any(EtudiantDTO.class));
    }

    @Test
    public void testHandleGetEtudiantById_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(etudiantController.getEtudiantById(1)).thenReturn(null);

        etudiantRoutes.handleGetEtudiantById(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Etudiant non trouvé"); // Fix accent issue
    }

    @Test
    public void testHandleGetEtudiantById_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("invalid");

        etudiantRoutes.handleGetEtudiantById(ctx);

        verify(ctx).status(400);
        verify(ctx).result("ID invalide");
    }

    @Test
    public void testHandleCreateEtudiant_Success() {
        EtudiantDTO newEtudiant = createDummyEtudiant();
        when(ctx.bodyAsClass(EtudiantDTO.class)).thenReturn(newEtudiant);
        when(etudiantController.createEtudiant(newEtudiant)).thenReturn(newEtudiant);

        etudiantRoutes.handleCreateEtudiant(ctx);

        verify(ctx).status(201);
        verify(ctx).json(newEtudiant);
    }

    @Test
    public void testHandleCreateEtudiant_InvalidBody() {
        when(ctx.bodyAsClass(EtudiantDTO.class)).thenThrow(new RuntimeException("Invalid body"));

        etudiantRoutes.handleCreateEtudiant(ctx);

        verify(ctx).status(400);
        verify(ctx).result("Requête invalide");
    }

    @Test
    public void testHandleUpdateEtudiant_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        EtudiantDTO updatedEtudiant = createDummyEtudiant();
        when(ctx.bodyAsClass(EtudiantDTO.class)).thenReturn(updatedEtudiant);
        when(etudiantController.updateEtudiant(1, updatedEtudiant)).thenReturn(true);

        etudiantRoutes.handleUpdateEtudiant(ctx);

        verify(ctx).status(200);
        verify(ctx).result("Etudiant mis à jour avec succès."); // Fix accent issue
    }

    @Test
    public void testHandleUpdateEtudiant_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(ctx.bodyAsClass(EtudiantDTO.class)).thenReturn(createDummyEtudiant());
        when(etudiantController.updateEtudiant(1, createDummyEtudiant())).thenReturn(false);

        etudiantRoutes.handleUpdateEtudiant(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Etudiant non trouvé ou mise à jour impossible."); // Fix accent issue
    }

    @Test
    public void testHandleDeleteEtudiant_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(etudiantController.deleteEtudiant(1)).thenReturn(true);

        etudiantRoutes.handleDeleteEtudiant(ctx);

        verify(ctx).status(204);
        verify(ctx, never()).result(anyString());
    }

    @Test
    public void testHandleDeleteEtudiant_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(etudiantController.deleteEtudiant(1)).thenReturn(false);

        etudiantRoutes.handleDeleteEtudiant(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Etudiant non trouvé"); // Fix accent issue
    }
}
