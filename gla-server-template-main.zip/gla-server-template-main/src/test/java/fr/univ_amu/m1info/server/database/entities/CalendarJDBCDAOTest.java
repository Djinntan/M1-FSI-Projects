package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dto.*;
import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CalendarJDBCDAOTest {

    private CalendarJDBCDAO calendarJDBCDAO;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;
    private Statement mockStatement;

    private TimeInterval mockTimeInterval;
    private SalleDTO mockSalle;
    private EnseignantDTO mockEnseignant;
    private GroupeDTO mockGroupe;
    private CalendarSlotDTO mockCalendarSlot;

    @BeforeEach
    void setUp() throws Exception {
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
        mockStatement = mock(Statement.class);

        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);

        calendarJDBCDAO = new CalendarJDBCDAO(mockConnection);

        mockTimeInterval = new TimeInterval(
                LocalDateTime.of(2023, 1, 1, 10, 0),
                LocalDateTime.of(2023, 1, 1, 11, 0)
        );
        mockSalle = new SalleDTO(1, "Amphi 5", "Batiment A", "Campus Luminy",
                true, 50, TypeSalle.AMPHITHEATRE
        );
        mockEnseignant = new EnseignantDTO(1, "John", "Doe", "JaneDoe@University.com");
        mockGroupe = new GroupeDTO(1, "Groupe 1");
        mockCalendarSlot = new CalendarSlotDTO(1, "Mathematics Class", mockTimeInterval, 1, mockSalle, mockEnseignant, mockGroupe);
    }

    @Disabled
    void testGet_existingKey() throws SQLException {
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("description")).thenReturn("Test Slot");
        when(mockResultSet.getTimestamp("start")).thenReturn(Timestamp.valueOf("2023-01-01 10:00:00"));
        when(mockResultSet.getTimestamp("end")).thenReturn(Timestamp.valueOf("2023-01-01 11:00:00"));
        when(mockResultSet.getInt("version")).thenReturn(1);

        Optional<CalendarSlotDTO> result = calendarJDBCDAO.get(1);

        assertTrue(result.isPresent());
        assertEquals("Test Slot", result.get().description());
    }

    @Test
    void testGet_nonExistentKey() throws SQLException {
        when(mockResultSet.next()).thenReturn(false);

        Optional<CalendarSlotDTO> result = calendarJDBCDAO.get(99);

        assertTrue(result.isEmpty());
    }

    @Test
    void testSQLExceptionHandlingInGet() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.get(1));
    }

    @Test
    void testGetAllSlots() throws SQLException {
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("description")).thenReturn("Test Slot");
        when(mockResultSet.getTimestamp("start")).thenReturn(Timestamp.valueOf("2023-01-01 10:00:00")); // ✅ FIXED
        when(mockResultSet.getTimestamp("end")).thenReturn(Timestamp.valueOf("2023-01-01 11:00:00"));   // ✅ FIXED
        when(mockResultSet.getInt("version")).thenReturn(1);

        List<CalendarSlotDTO> slots = calendarJDBCDAO.getAll();

        assertEquals(1, slots.size());
        assertEquals("Test Slot", slots.get(0).description());
    }

    @Test
    void testGetAllSlots_EmptyResult() throws SQLException {
        when(mockResultSet.next()).thenReturn(false);

        List<CalendarSlotDTO> slots = calendarJDBCDAO.getAll();

        assertTrue(slots.isEmpty());
    }

    @Test
    void testGetAllSlots_SQLException() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.getAll());
    }

    @Test
    void testCreate_validSlot() throws SQLException {
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1);

        int generatedId = calendarJDBCDAO.create(mockCalendarSlot);

        assertEquals(1, generatedId);
    }

    @Test
    void testCreate_Fails() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.create(mockCalendarSlot));
    }

    @Test
    void testUpdate_existingSlot() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        int rowsUpdated = calendarJDBCDAO.update(mockCalendarSlot);

        assertEquals(1, rowsUpdated);
    }

    @Test
    void testUpdate_Fails() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.update(mockCalendarSlot));
    }

    @Test
    void testDelete_existingSlot() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        calendarJDBCDAO.delete(mockCalendarSlot);

        verify(mockPreparedStatement).executeUpdate();
    }

    @Test
    void testDelete_Fails() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.delete(mockCalendarSlot));
    }

    @Test
    void testGetGroupesForCalendarSlot() throws SQLException {
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Groupe Test");

        List<GroupeDTO> groupes = calendarJDBCDAO.getGroupesForCalendarSlot(1);

        assertEquals(1, groupes.size());
        assertEquals("Groupe Test", groupes.get(0).nom());
    }

    @Test
    void testGetGroupesForCalendarSlot_SQLException() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenThrow(new SQLException("DB Error"));

        assertThrows(RuntimeException.class, () -> calendarJDBCDAO.getGroupesForCalendarSlot(1));
    }
}
