package fr.univ_amu.m1info.server.model.models.groupe;

import fr.univ_amu.m1info.server.model.models.etudiant.Etudiant;
import org.junit.jupiter.api.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GroupeTest {
    private Groupe groupe;
    private Etudiant mockEtudiant;

    @BeforeEach
    void setUp() {
        mockEtudiant = mock(Etudiant.class);
        groupe = new Groupe(1, "Groupe A"/*, List.of(mockEtudiant)*/);
    }

    @Test
    void testGetId() {
        assertEquals(1, groupe.getId());
    }

    @Test
    void testGetNom() {
        assertEquals("Groupe A", groupe.getNom());
    }

    @Disabled
    void testGetEtudiants() {
        //assertEquals(1, groupe.getEtudiants().size());
        //assertTrue(groupe.getEtudiants().contains(mockEtudiant));
    }

    @Test
    void testSetId() {
        groupe.setId(10);
        assertEquals(10, groupe.getId());
    }

    @Test
    void testSetNom() {
        groupe.setNom("Groupe B");
        assertEquals("Groupe B", groupe.getNom());
    }

    @Disabled
    void testAddEtudiant() {
        Etudiant newEtudiant = mock(Etudiant.class);
        //groupe.addEtudiant(newEtudiant);
        //assertTrue(groupe.getEtudiants().contains(newEtudiant));
    }

    @Disabled
    void testRemoveEtudiant() {
        //groupe.removeEtudiant(mockEtudiant);
        //assertFalse(groupe.getEtudiants().contains(mockEtudiant));
    }
} 
