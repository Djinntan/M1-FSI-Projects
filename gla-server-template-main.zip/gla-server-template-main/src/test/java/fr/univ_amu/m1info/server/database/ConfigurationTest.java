package fr.univ_amu.m1info.server.database;

import org.junit.jupiter.api.*;
import org.mockito.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ConfigurationTest {

    @Mock private Properties mockProperties;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGet_Success() {
        assertDoesNotThrow(() -> Configuration.get("db_url"));
    }

    @Test
    void testGet_KeyNotFound() {
        Exception exception = assertThrows(RuntimeException.class, () -> Configuration.get("unknown_key"));
        assertTrue(exception.getMessage().contains("Key 'unknown_key' not found in configuration!"));
    }

    @Test
    void testConfigurationFileLoadsSuccessfully() throws IOException {
        Properties properties = new Properties();
        properties.setProperty("db_url", "jdbc:h2:mem:test");

        try (MockedStatic<Configuration> mockedConfiguration = mockStatic(Configuration.class);
             InputStream mockInputStream = mock(InputStream.class)) {

            mockedConfiguration.when(() -> Configuration.get("db_url")).thenReturn("jdbc:h2:mem:test");

            properties.load(mockInputStream);
            assertEquals("jdbc:h2:mem:test", properties.getProperty("db_url"));
        }
    }

    @Disabled
    void testConfigurationFileNotFound() {
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            try (InputStream input = Configuration.class.getResourceAsStream("/configuration.properties")) {
                if (input == null) {
                    throw new RuntimeException("Configuration file '/configuration.properties' not found in classpath!");
                }
            }
        });
        assertTrue(exception.getMessage().contains("Configuration file '/configuration.properties' not found in classpath!"));
    }

    @Disabled
    void testPropertiesFileLoadingFailure() {
        try (MockedStatic<Configuration> mockedConfiguration = mockStatic(Configuration.class);
             MockedStatic<Properties> mockedProperties = mockStatic(Properties.class)) {

            mockedProperties.when(() -> {
                Properties props = new Properties();
                try (InputStream input = Configuration.class.getResourceAsStream("/configuration.properties")) {
                    if (input == null) {
                        throw new IOException("Error loading configuration file");
                    }
                    props.load(input);
                }
            }).thenThrow(new RuntimeException("Error loading configuration file"));

            RuntimeException exception = assertThrows(RuntimeException.class, () -> Configuration.get("db_url"));
            assertTrue(exception.getMessage().contains("Error loading configuration file"));
        }
    }
}
