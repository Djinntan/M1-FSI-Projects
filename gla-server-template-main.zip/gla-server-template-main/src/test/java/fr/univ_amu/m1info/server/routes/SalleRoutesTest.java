package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.SalleController;
import fr.univ_amu.m1info.server.dto.SalleDTO;
import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SalleRoutesTest {
    @Mock
    private SalleController salleController;

    @Mock
    private Context ctx;

    private SalleRoutes salleRoutes;

    @BeforeEach
    void setUp() {
        salleRoutes = new SalleRoutes(salleController);
        when(ctx.status(anyInt())).thenReturn(ctx);
    }

    @Test
    void testHandleGetAllSalles() {
        List<SalleDTO> salles = List.of(new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, null));
        when(salleController.getAllSalles()).thenReturn(salles);

        salleRoutes.handleGetAllSalles(ctx);

        verify(ctx).status(200);
        verify(ctx).json(salles);
    }

    @Test
    void testHandleGetSalleById_Found() {
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, null);
        when(ctx.pathParam("id")).thenReturn("1");
        when(salleController.getSalleById(1)).thenReturn(salle);

        salleRoutes.handleGetSalleById(ctx);

        verify(ctx).status(200);
        verify(ctx).json(salle);
    }

    @Test
    void testHandleGetSalleById_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(salleController.getSalleById(1)).thenReturn(null);

        salleRoutes.handleGetSalleById(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Salle non trouvée");
    }

    @Test
    void testHandleCreateSalle_Success() {
        SalleDTO inputSalle = new SalleDTO(0, "Salle A", "B1", "Campus A", true, 50, null);
        SalleDTO createdSalle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, null);

        when(ctx.bodyAsClass(SalleDTO.class)).thenReturn(inputSalle);
        when(salleController.createSalle(inputSalle)).thenReturn(createdSalle);

        salleRoutes.handleCreateSalle(ctx);

        verify(ctx).status(201);
        verify(ctx).json(createdSalle);
    }

    @Test
    void testHandleCreateOrUpdateSalle_Success() {
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, null);
        when(ctx.bodyAsClass(SalleDTO.class)).thenReturn(salle);
        when(salleController.createOrUpdateSalle(salle)).thenReturn(salle);

        salleRoutes.handleCreateOrUpdateSalle(ctx);

        verify(ctx).status(200);
        verify(ctx).json(salle);
    }

    @Test
    void testHandleDeleteSalle_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(salleController.deleteSalle(1)).thenReturn(true);

        salleRoutes.handleDeleteSalle(ctx);

        verify(ctx).status(204);
        verify(ctx, never()).result(anyString());
    }

    @Test
    void testHandleDeleteSalle_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(salleController.deleteSalle(1)).thenReturn(false);

        salleRoutes.handleDeleteSalle(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Salle non trouvée");
    }
}
