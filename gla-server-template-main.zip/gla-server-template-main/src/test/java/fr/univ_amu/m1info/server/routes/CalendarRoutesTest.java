package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.CalendarController;
import fr.univ_amu.m1info.server.dto.*;
import fr.univ_amu.m1info.server.model.exceptions.UnknownElementException;
import fr.univ_amu.m1info.server.model.exceptions.WrongVersionException;
import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CalendarRoutesTest {

    @Mock
    private CalendarController calendarController;

    @Mock
    private Context ctx;

    private CalendarRoutes calendarRoutes;
    private EnseignantDTO enseignantDTO;
    private GroupeDTO groupeDTO;

    @BeforeEach
    public void setUp() {
        calendarRoutes = new CalendarRoutes(calendarController);
        enseignantDTO = mock(EnseignantDTO.class);
        groupeDTO = mock(GroupeDTO.class);
        // Stub the chainable status() method so that it returns the context.
        when(ctx.status(anyInt())).thenReturn(ctx);
    }

    /**
     * Helper method to create a dummy CalendarSlotDTO.
     * For SalleDTO and GroupeDTO, we pass null and an empty list respectively.
     */
    private CalendarSlotDTO createDummySlot() {
        return new CalendarSlotDTO(
                1,
                "dummy description",
                new TimeInterval(
                        LocalDateTime.of(2025, 1, 1, 0, 0),
                        LocalDateTime.of(2025, 1, 2, 0, 0)
                ),
                1,
                null,           // Assuming SalleDTO is not needed in tests.
                enseignantDTO,
                groupeDTO    // Empty list for GroupeDTO.
        );
    }

    // ======== Tests for handleCalendarRequest ========

    @Test
    public void testHandleCalendarRequest_MissingParams() {
        when(ctx.queryParam("start")).thenReturn(null);
        calendarRoutes.handleCalendarRequest(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad request: Missing start or end parameter");
    }

    @Test
    public void testHandleCalendarRequest_InvalidDateFormat() {
        when(ctx.queryParam("start")).thenReturn("invalid-date");
        when(ctx.queryParam("end")).thenReturn("2025-01-31");
        calendarRoutes.handleCalendarRequest(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: Invalid date format");
    }

    @Test
    public void testHandleCalendarRequest_StartAfterEnd() {
        when(ctx.queryParam("start")).thenReturn("2025-02-01");
        when(ctx.queryParam("end")).thenReturn("2025-01-31");
        calendarRoutes.handleCalendarRequest(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad request: Start date must be before end date");
    }

    @Test
    public void testHandleCalendarRequest_ValidDates() {
        String startStr = "2025-01-01";
        String endStr = "2025-01-31";
        when(ctx.queryParam("start")).thenReturn(startStr);
        when(ctx.queryParam("end")).thenReturn(endStr);

        CalendarSlotDTO dummySlot = createDummySlot();
        // Stub the controller to return a CalendarDTO wrapping the dummy slot.
        CalendarDTO calendarDTO = new CalendarDTO(List.of(dummySlot));
        when(calendarController.getCalendarSlotsIn(any(TimeInterval.class))).thenReturn(calendarDTO);

        calendarRoutes.handleCalendarRequest(ctx);

        // Capture the TimeInterval passed to the controller.
        ArgumentCaptor<TimeInterval> intervalCaptor = ArgumentCaptor.forClass(TimeInterval.class);
        verify(calendarController).getCalendarSlotsIn(intervalCaptor.capture());
        TimeInterval capturedInterval = intervalCaptor.getValue();

        LocalDateTime expectedStart = LocalDate.parse(startStr).atStartOfDay();
        LocalDateTime expectedEnd = LocalDate.parse(endStr).atTime(LocalTime.MAX);
        assertEquals(expectedStart, capturedInterval.start());
        assertEquals(expectedEnd, capturedInterval.end());

        verify(ctx).status(200);
        verify(ctx).json(calendarDTO);
    }

    // ======== Tests for handleGetTimeslotById ========

    @Test
    public void testHandleGetTimeslotById_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("notAnInteger");
        calendarRoutes.handleGetTimeslotById(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: ID must be an integer");
    }

    @Test
    public void testHandleGetTimeslotById_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(calendarController.getCalendarSlotById(1)).thenReturn(null);
        calendarRoutes.handleGetTimeslotById(ctx);
        verify(ctx).status(404);
        verify(ctx).result("Slot with ID 1 not found");
    }

    @Test
    public void testHandleGetTimeslotById_Found() {
        when(ctx.pathParam("id")).thenReturn("2");
        CalendarSlotDTO slot = createDummySlot();
        when(calendarController.getCalendarSlotById(2)).thenReturn(slot);
        calendarRoutes.handleGetTimeslotById(ctx);
        verify(ctx).status(200);
        verify(ctx).json(slot);
    }

    // ======== Tests for handleCreateTimeslot ========

    @Test
    public void testHandleCreateTimeslot_InvalidBody() {
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenThrow(new RuntimeException("parsing error"));
        calendarRoutes.handleCreateTimeslot(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: Invalid CalendarSlotDTO format");
    }

    @Test
    public void testHandleCreateTimeslot_Success() {
        CalendarSlotDTO inputSlot = createDummySlot();
        CalendarSlotDTO createdSlot = new CalendarSlotDTO(
                99,
                inputSlot.description(),
                inputSlot.timeInterval(),
                inputSlot.version(),
                inputSlot.salle(),
                inputSlot.enseignant(),
                inputSlot.groupe()
        );
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenReturn(inputSlot);
        when(calendarController.createSlot(inputSlot)).thenReturn(createdSlot);

        calendarRoutes.handleCreateTimeslot(ctx);
        verify(ctx).status(201);
        verify(ctx).json(createdSlot);
    }

    // ======== Tests for handleUpdateTimeslot ========

    @Test
    public void testHandleUpdateTimeslot_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("notAnInteger");
        calendarRoutes.handleUpdateTimeslot(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: ID must be an integer");
    }

    @Test
    public void testHandleUpdateTimeslot_InvalidBody() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenThrow(new RuntimeException("parsing error"));
        calendarRoutes.handleUpdateTimeslot(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: Invalid CalendarSlotDTO format");
    }

    @Test
    public void testHandleUpdateTimeslot_Success() throws Exception {
        when(ctx.pathParam("id")).thenReturn("1");
        CalendarSlotDTO inputSlot = createDummySlot();
        CalendarSlotDTO updatedSlot = new CalendarSlotDTO(
                inputSlot.id(),
                "updated description",
                inputSlot.timeInterval(),
                inputSlot.version(),
                inputSlot.salle(),
                inputSlot.enseignant(),
                inputSlot.groupe()
        );
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenReturn(inputSlot);
        when(calendarController.updateSlot(1, inputSlot)).thenReturn(updatedSlot);

        calendarRoutes.handleUpdateTimeslot(ctx);
        verify(ctx).status(200);
        verify(ctx).json(updatedSlot);
    }

    @Test
    public void testHandleUpdateTimeslot_NotFound() throws Exception {
        when(ctx.pathParam("id")).thenReturn("1");
        CalendarSlotDTO inputSlot = createDummySlot();
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenReturn(inputSlot);
        // Throw the exception using the two-argument constructor.
        doThrow(new UnknownElementException("Slot with ID 1 not found", 1))
                .when(calendarController).updateSlot(1, inputSlot);

        calendarRoutes.handleUpdateTimeslot(ctx);
        verify(ctx).status(404);
        verify(ctx).result("Slot with ID 1 not found");
    }

    @Test
    public void testHandleUpdateTimeslot_WrongVersion() throws Exception {
        when(ctx.pathParam("id")).thenReturn("1");
        CalendarSlotDTO inputSlot = createDummySlot();
        when(ctx.bodyAsClass(CalendarSlotDTO.class)).thenReturn(inputSlot);
        doThrow(new WrongVersionException("Wrong version"))
                .when(calendarController).updateSlot(1, inputSlot);

        calendarRoutes.handleUpdateTimeslot(ctx);
        verify(ctx).status(409);
        verify(ctx).result("Version incorrecte pour le slot ID 1");
    }

    // ======== Tests for handleDeleteTimeslot ========

    @Test
    public void testHandleDeleteTimeslot_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("notAnInteger");
        calendarRoutes.handleDeleteTimeslot(ctx);
        verify(ctx).status(400);
        verify(ctx).result("Bad Request: ID must be an integer");
    }

    @Test
    public void testHandleDeleteTimeslot_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(calendarController.deleteSlot(1)).thenReturn(false);
        calendarRoutes.handleDeleteTimeslot(ctx);
        verify(ctx).status(404);
        verify(ctx).result("Slot with ID 1 not found");
    }

    @Test
    public void testHandleDeleteTimeslot_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(calendarController.deleteSlot(1)).thenReturn(true);
        calendarRoutes.handleDeleteTimeslot(ctx);
        verify(ctx).status(204);
        // When deletion is successful, no result message should be sent.
        verify(ctx, never()).result(anyString());
    }
}
