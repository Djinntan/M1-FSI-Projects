package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.database.entities.EtudiantJDBCDAO;
import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import org.junit.jupiter.api.*;
import org.mockito.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EtudiantControllerTest {

    private EtudiantController etudiantController;
    private GroupeDTO mockGroupe;
    @Mock private EtudiantJDBCDAO mockEtudiantJDBCDAO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockGroupe = mock(GroupeDTO.class);
        etudiantController = new EtudiantController(mockEtudiantJDBCDAO);
    }

    @Test
    void testControllerInitialization() {
        assertNotNull(etudiantController.etudiantDAO, "EtudiantDAO should be initialized");
    }

    @Test
    void testGetAllEtudiants_ReturnsList() {
        List<EtudiantDTO> etudiants = List.of(new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe));
        when(mockEtudiantJDBCDAO.getAllEtudiants()).thenReturn(etudiants);

        List<EtudiantDTO> result = etudiantController.getAllEtudiants();

        assertEquals(1, result.size());
        assertEquals("Doe", result.get(0).nom());
    }

    @Test
    void testGetAllEtudiants_EmptyList() {
        when(mockEtudiantJDBCDAO.getAllEtudiants()).thenReturn(Collections.emptyList());
        assertTrue(etudiantController.getAllEtudiants().isEmpty());
    }

    @Test
    void testGetEtudiantById_Found() {
        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);
        when(mockEtudiantJDBCDAO.getEtudiantById(1)).thenReturn(Optional.of(etudiant));

        EtudiantDTO result = etudiantController.getEtudiantById(1);

        assertNotNull(result);
        assertEquals("Doe", result.nom());
    }

    @Test
    void testGetEtudiantById_NotFound() {
        when(mockEtudiantJDBCDAO.getEtudiantById(1)).thenReturn(Optional.empty());
        assertNull(etudiantController.getEtudiantById(1));
    }

    @Test
    void testCreateEtudiant_Success() {
        EtudiantDTO etudiant = new EtudiantDTO(0, "Doe", "John",  "john.doe@example.com", mockGroupe);
        when(mockEtudiantJDBCDAO.createEtudiant(etudiant)).thenReturn(1);

        EtudiantDTO createdEtudiant = etudiantController.createEtudiant(etudiant);

        assertNotNull(createdEtudiant);
        assertEquals(1, createdEtudiant.id());
    }

    @Test
    void testCreateEtudiant_Null_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> etudiantController.createEtudiant(null));
    }

    @Test
    void testUpdateEtudiant_Success() {
        EtudiantDTO existingEtudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com",mockGroupe);
        when(mockEtudiantJDBCDAO.getEtudiantById(1)).thenReturn(Optional.of(existingEtudiant));
        when(mockEtudiantJDBCDAO.updateEtudiant(any(EtudiantDTO.class))).thenReturn(true);

        boolean success = etudiantController.updateEtudiant(1, existingEtudiant);
        assertTrue(success);
    }

    @Test
    void testUpdateEtudiant_NotFound() {
        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com",mockGroupe);
        when(mockEtudiantJDBCDAO.getEtudiantById(1)).thenReturn(Optional.empty());

        boolean success = etudiantController.updateEtudiant(1, etudiant);
        assertFalse(success);
    }

    @Test
    void testDeleteEtudiant_Success() {
        when(mockEtudiantJDBCDAO.deleteEtudiant(1)).thenReturn(true);
        assertTrue(etudiantController.deleteEtudiant(1));
    }

    @Test
    void testDeleteEtudiant_NotFound() {
        when(mockEtudiantJDBCDAO.deleteEtudiant(1)).thenReturn(false);
        assertFalse(etudiantController.deleteEtudiant(1));
    }

    @Test
    void testCreateOrUpdateEtudiant_ExistingUpdated() {
        EtudiantDTO existingEtudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);
        EtudiantDTO updatedEtudiant = new EtudiantDTO(1, "Doe", "Johnny", "john.doe@example.com", mockGroupe);
        when(mockEtudiantJDBCDAO.getEtudiantByEmail("john.doe@example.com")).thenReturn(Optional.of(existingEtudiant));
        when(mockEtudiantJDBCDAO.updateEtudiant(any(EtudiantDTO.class))).thenReturn(true);

        EtudiantDTO result = etudiantController.createOrUpdateEtudiant(updatedEtudiant);

        assertNotNull(result);
        assertEquals("Johnny", result.prenom());
        verify(mockEtudiantJDBCDAO, never()).createEtudiant(updatedEtudiant);
    }

    @Test
    void testCreateOrUpdateEtudiant_NotExistingCreated() {
        EtudiantDTO newEtudiant = new EtudiantDTO(0, "Doe", "Johnny", "johnny.doe@example.com", mockGroupe);
        when(mockEtudiantJDBCDAO.getEtudiantByEmail("johnny.doe@example.com")).thenReturn(Optional.empty());
        when(mockEtudiantJDBCDAO.createEtudiant(any(EtudiantDTO.class))).thenReturn(2);

        EtudiantDTO result = etudiantController.createOrUpdateEtudiant(newEtudiant);

        assertNotNull(result);
        assertEquals(2, result.id());
    }
}
