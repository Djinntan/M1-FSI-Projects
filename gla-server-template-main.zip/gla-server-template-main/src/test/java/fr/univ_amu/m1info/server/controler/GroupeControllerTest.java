package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.GroupeDAO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import org.junit.jupiter.api.*;
import org.mockito.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GroupeControllerTest {

    private GroupeController groupeController;
    @Mock private GroupeDAO mockGroupeDAO;
    private Enseignant mockEnseignant;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        groupeController = new GroupeController(mockGroupeDAO);
    }

    @Test
    void testGetAllGroupes_ReturnsList() {
        List<GroupeDTO> groupes = List.of(new GroupeDTO(1, "Groupe A"));
        when(mockGroupeDAO.getAllGroupes()).thenReturn(groupes);

        List<GroupeDTO> result = groupeController.getAllGroupes();

        assertEquals(1, result.size());
        assertEquals("Groupe A", result.get(0).nom());
    }

    @Test
    void testGetAllGroupes_EmptyList() {
        when(mockGroupeDAO.getAllGroupes()).thenReturn(Collections.emptyList());
        assertTrue(groupeController.getAllGroupes().isEmpty());
    }

    @Test
    void testGetGroupeById_Found() {
        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");
        when(mockGroupeDAO.getGroupeById(1)).thenReturn(Optional.of(groupe));

        GroupeDTO result = groupeController.getGroupeById(1);

        assertNotNull(result);
        assertEquals("Groupe A", result.nom());
    }

    @Test
    void testGetGroupeById_NotFound() {
        when(mockGroupeDAO.getGroupeById(1)).thenReturn(Optional.empty());
        assertNull(groupeController.getGroupeById(1));
    }

    @Test
    void testCreateGroupe_Success() {
        GroupeDTO groupe = new GroupeDTO(0, "Groupe A");
        when(mockGroupeDAO.createGroupe(groupe)).thenReturn(1);

        GroupeDTO createdGroupe = groupeController.createGroupe(groupe);

        assertNotNull(createdGroupe);
        assertEquals(1, createdGroupe.id());
    }

    @Test
    void testCreateGroupe_Null_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> groupeController.createGroupe(null));
    }

    @Test
    void testUpdateGroupe_Success() {
        GroupeDTO existingGroupe = new GroupeDTO(1, "Groupe A");
        when(mockGroupeDAO.getGroupeById(1)).thenReturn(Optional.of(existingGroupe));
        when(mockGroupeDAO.updateGroupe(any(GroupeDTO.class))).thenReturn(true);

        boolean success = groupeController.updateGroupe(1, existingGroupe);
        assertTrue(success);
    }

    @Test
    void testUpdateGroupe_NotFound() {
        GroupeDTO groupe = new GroupeDTO(1, "Groupe A");
        when(mockGroupeDAO.getGroupeById(1)).thenReturn(Optional.empty());

        boolean success = groupeController.updateGroupe(1, groupe);
        assertFalse(success);
    }

    @Test
    void testDeleteGroupe_Success() {
        when(mockGroupeDAO.deleteGroupe(1)).thenReturn(true);
        assertTrue(groupeController.deleteGroupe(1));
    }

    @Test
    void testDeleteGroupe_NotFound() {
        when(mockGroupeDAO.deleteGroupe(1)).thenReturn(false);
        assertFalse(groupeController.deleteGroupe(1));
    }
}
