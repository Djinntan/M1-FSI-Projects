package fr.univ_amu.m1info.server.controler;

import fr.univ_amu.m1info.server.dao.SalleDAO;
import fr.univ_amu.m1info.server.dto.SalleDTO;
import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;
import org.junit.jupiter.api.*;
import org.mockito.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SalleControllerTest {

    private SalleController salleController;
    @Mock private SalleDAO mockSalleDAO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        salleController = new SalleController(mockSalleDAO);
    }

    @Test
    void testGetAllSalles_ReturnsList() {
        List<SalleDTO> salles = List.of(new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE));
        when(mockSalleDAO.getAllSalles()).thenReturn(salles);

        List<SalleDTO> result = salleController.getAllSalles();

        assertEquals(1, result.size());
        assertEquals("Salle A", result.get(0).nom());
    }

    @Test
    void testGetAllSalles_EmptyList() {
        when(mockSalleDAO.getAllSalles()).thenReturn(Collections.emptyList());
        assertTrue(salleController.getAllSalles().isEmpty());
    }

    @Test
    void testGetSalleById_Found() {
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockSalleDAO.getSalleById(1)).thenReturn(Optional.of(salle));

        SalleDTO result = salleController.getSalleById(1);

        assertNotNull(result);
        assertEquals("Salle A", result.nom());
    }

    @Test
    void testGetSalleById_NotFound() {
        when(mockSalleDAO.getSalleById(1)).thenReturn(Optional.empty());
        assertNull(salleController.getSalleById(1));
    }

    @Test
    void testCreateSalle_Success() {
        SalleDTO salle = new SalleDTO(0, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockSalleDAO.createSalle(salle)).thenReturn(1);

        SalleDTO createdSalle = salleController.createSalle(salle);

        assertNotNull(createdSalle);
        assertEquals(1, createdSalle.id());
    }

    @Test
    void testCreateSalle_Null_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> salleController.createSalle(null));
    }

    @Test
    void testUpdateSalle_Success() {
        SalleDTO existingSalle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockSalleDAO.getSalleById(1)).thenReturn(Optional.of(existingSalle));
        when(mockSalleDAO.updateSalle(any(SalleDTO.class))).thenReturn(true);

        boolean success = salleController.updateSalle(1, existingSalle);
        assertTrue(success);
    }

    @Test
    void testUpdateSalle_NotFound() {
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockSalleDAO.getSalleById(1)).thenReturn(Optional.empty());

        boolean success = salleController.updateSalle(1, salle);
        assertFalse(success);
    }

    @Test
    void testDeleteSalle_Success() {
        when(mockSalleDAO.deleteSalle(1)).thenReturn(true);
        assertTrue(salleController.deleteSalle(1));
    }

    @Test
    void testDeleteSalle_NotFound() {
        when(mockSalleDAO.deleteSalle(1)).thenReturn(false);
        assertFalse(salleController.deleteSalle(1));
    }

    @Test
    void testCreateOrUpdateSalle_CreatesNewSalle() {
        SalleDTO salle = new SalleDTO(0, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockSalleDAO.getSalleByNomAndLieu(salle.nom(), salle.batiment(), salle.campus())).thenReturn(Optional.empty());
        when(mockSalleDAO.createSalle(salle)).thenReturn(1);

        SalleDTO result = salleController.createOrUpdateSalle(salle);

        assertNotNull(result);
        assertEquals(1, result.id());
    }

    @Test
    void testCreateOrUpdateSalle_UpdatesExistingSalle_Success() {
        SalleDTO existingSalle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        SalleDTO updatedSalle = new SalleDTO(1, "Salle B", "B1", "Campus A", false, 30, TypeSalle.TD);

        when(mockSalleDAO.getSalleByNomAndLieu(existingSalle.nom(), existingSalle.batiment(), existingSalle.campus()))
                .thenReturn(Optional.of(existingSalle));
        when(mockSalleDAO.updateSalle(any(SalleDTO.class))).thenReturn(true);

        SalleDTO result = salleController.createOrUpdateSalle(updatedSalle);

        assertNotNull(result);
        assertEquals("Salle B", result.nom());
    }
    @Disabled
    void testCreateOrUpdateSalle_UpdatesExistingSalle_Failure() {
        SalleDTO existingSalle = new SalleDTO(1, "Salle A", "B1", "Campus A", true, 50, TypeSalle.AMPHITHEATRE);
        SalleDTO updatedSalle = new SalleDTO(1, "Salle B", "B1", "Campus A", false, 30, TypeSalle.TD);

        when(mockSalleDAO.getSalleByNomAndLieu(existingSalle.nom(), existingSalle.batiment(), existingSalle.campus()))
                .thenReturn(Optional.of(existingSalle));
        when(mockSalleDAO.updateSalle(any(SalleDTO.class))).thenReturn(false);

        SalleDTO result = salleController.createOrUpdateSalle(updatedSalle);

        assertNotNull(result);
        assertEquals(existingSalle.id(), result.id()); // ✅ Ensure the returned ID matches the existing salle
        assertEquals(existingSalle.nom(), result.nom()); // ✅ Ensure the returned salle is the original
    }

}
