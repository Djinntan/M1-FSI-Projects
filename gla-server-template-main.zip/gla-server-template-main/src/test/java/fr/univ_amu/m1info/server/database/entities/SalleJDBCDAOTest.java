package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dto.SalleDTO;
import fr.univ_amu.m1info.server.model.models.salle.TypeSalle;
import org.junit.jupiter.api.*;

import java.sql.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SalleJDBCDAOTest {

    private SalleJDBCDAO salleJDBCDAO;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;
    private Statement mockStatement;

    @BeforeEach
    void setUp() throws Exception {
        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
        mockStatement = mock(Statement.class);

        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.getString("batiment")).thenReturn("B1");
        when(mockResultSet.getString("campus")).thenReturn("Main Campus");
        when(mockResultSet.getBoolean("videoProjecteur")).thenReturn(true);
        when(mockResultSet.getInt("capacite")).thenReturn(50);
        when(mockResultSet.getString("typeSalle")).thenReturn("AMPHITHEATRE");
        when(mockConnection.createStatement()).thenReturn(mockStatement);

        salleJDBCDAO = new SalleJDBCDAO(mockConnection);
    }

    @Test
    void testGetAllSalles_ReturnsList() throws SQLException {
        when(mockStatement.executeQuery("SELECT * FROM Salle"))
                .thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Salle A");
        when(mockResultSet.getString("batiment")).thenReturn("B1");
        when(mockResultSet.getString("campus")).thenReturn("Main Campus");
        when(mockResultSet.getBoolean("videoProjecteur")).thenReturn(true);
        when(mockResultSet.getInt("capacite")).thenReturn(50);
        when(mockResultSet.getString("typeSalle")).thenReturn("AMPHITHEATRE");

        List<SalleDTO> result = salleJDBCDAO.getAllSalles();

        assertEquals(1, result.size());
        assertEquals("Salle A", result.get(0).nom());
    }

    @Test
    void testGetSalleById_Found() throws SQLException {
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Salle A");

        Optional<SalleDTO> result = salleJDBCDAO.getSalleById(1);

        assertTrue(result.isPresent());
        assertEquals("Salle A", result.get().nom());
    }

    @Test
    void testCreateSalle_Success() throws SQLException {
        SalleDTO salle = new SalleDTO(0, "Salle A", "B1", "Main Campus", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1);

        int generatedId = salleJDBCDAO.createSalle(salle);
        assertEquals(1, generatedId);
    }

    @Test
    void testUpdateSalle_Success() throws SQLException {
        SalleDTO salle = new SalleDTO(1, "Salle A", "B1", "Main Campus", true, 50, TypeSalle.AMPHITHEATRE);
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = salleJDBCDAO.updateSalle(salle);
        assertTrue(success);
    }

    @Test
    void testDeleteSalle_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = salleJDBCDAO.deleteSalle(1);
        assertTrue(success);
    }

    @Test
    void testGetAllSalles_HandlesSQLException() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> salleJDBCDAO.getAllSalles());
    }

    @Test
    void testGetSalleById_HandlesSQLException() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> salleJDBCDAO.getSalleById(1));
    }

    @Test
    void testGetSalleByNomAndLieu_Found() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nom")).thenReturn("Salle A");
        when(mockResultSet.getString("batiment")).thenReturn("B1");
        when(mockResultSet.getString("campus")).thenReturn("Main Campus");
        when(mockResultSet.getBoolean("videoProjecteur")).thenReturn(true);
        when(mockResultSet.getInt("capacite")).thenReturn(50);
        when(mockResultSet.getString("typeSalle")).thenReturn("AMPHITHEATRE");

        Optional<SalleDTO> result = salleJDBCDAO.getSalleByNomAndLieu("Salle A", "B1", "Main Campus");

        assertTrue(result.isPresent());
        assertEquals("Salle A", result.get().nom());
    }
}
