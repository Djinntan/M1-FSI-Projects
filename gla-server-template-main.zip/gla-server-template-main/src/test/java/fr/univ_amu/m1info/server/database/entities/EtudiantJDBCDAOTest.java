package fr.univ_amu.m1info.server.database.entities;

import fr.univ_amu.m1info.server.dto.EtudiantDTO;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import fr.univ_amu.m1info.server.model.models.etudiant.Etudiant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import org.junit.jupiter.api.*;

import java.sql.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EtudiantJDBCDAOTest {

    private EtudiantJDBCDAO etudiantJDBCDAO;
    private Connection mockConnection;
    private PreparedStatement mockPreparedStatement;
    private ResultSet mockResultSet;
    private Statement mockStatement;
    private GroupeDTO mockGroupe;
    private EtudiantDTO mockEtudiant;

    @BeforeEach
    void setUp() throws Exception {
        mockGroupe = new GroupeDTO(1, "Groupe A");
        mockEtudiant = new EtudiantDTO(0, "Doe", "John", "john.doe@example.com", mockGroupe);


        mockConnection = mock(Connection.class);
        mockPreparedStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
        mockStatement = mock(Statement.class);

        when(mockConnection.prepareStatement(anyString(), anyInt())).thenReturn(mockPreparedStatement);
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockConnection.createStatement()).thenReturn(mockStatement);

        etudiantJDBCDAO = new EtudiantJDBCDAO(mockConnection);
    }
    @Test
    void testGetAllEtudiants_ReturnsList() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true, false);
        when(mockResultSet.getInt("etudiant_id")).thenReturn(1);
        when(mockResultSet.getString("etudiant_nom")).thenReturn("Doe");
        when(mockResultSet.getString("etudiant_prenom")).thenReturn("John");
        when(mockResultSet.getString("etudiant_email")).thenReturn("john.doe@example.com");
        when(mockResultSet.getInt("groupe_id")).thenReturn(1);
        when(mockResultSet.getString("groupe_nom")).thenReturn("Groupe A");

        List<EtudiantDTO> result = etudiantJDBCDAO.getAllEtudiants();

        assertEquals(1, result.size());
        assertEquals("Doe", result.get(0).nom());
    }

    @Test
    void testGetEtudiantById_Found() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("etudiant_id")).thenReturn(1);
        when(mockResultSet.getString("etudiant_nom")).thenReturn("Doe");
        when(mockResultSet.getString("etudiant_prenom")).thenReturn("John");
        when(mockResultSet.getString("etudiant_email")).thenReturn("john.doe@example.com");
        when(mockResultSet.getInt("groupe_id")).thenReturn(1);
        when(mockResultSet.getString("groupe_nom")).thenReturn("Groupe A");

        Optional<EtudiantDTO> result = etudiantJDBCDAO.getEtudiantById(1);

        assertTrue(result.isPresent());
        assertEquals("Doe", result.get().nom());
    }


    @Test
    void testCreateEtudiant_Success() throws SQLException {
        EtudiantDTO etudiant = new EtudiantDTO(0, "Doe", "John","john.doe@example.com", mockGroupe);
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt(1)).thenReturn(1);

        int generatedId = etudiantJDBCDAO.createEtudiant(etudiant);
        assertEquals(1, generatedId);
    }

    @Test
    void testUpdateEtudiant_Success() throws SQLException {
        EtudiantDTO etudiant = new EtudiantDTO(0, "Doe", "John","john.doe@example.com", mockGroupe);
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = etudiantJDBCDAO.updateEtudiant(etudiant);
        assertTrue(success);
    }

    @Test
    void testDeleteEtudiant_Success() throws SQLException {
        when(mockPreparedStatement.executeUpdate()).thenReturn(1);

        boolean success = etudiantJDBCDAO.deleteEtudiant(1);
        assertTrue(success);
    }

    @Test
    void testGetAllEtudiants_HandlesSQLException() throws SQLException {
        when(mockStatement.executeQuery(anyString())).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> etudiantJDBCDAO.getAllEtudiants());
    }

    @Test
    void testGetEtudiantById_HandlesSQLException() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenThrow(new SQLException("DB Error"));
        assertThrows(RuntimeException.class, () -> etudiantJDBCDAO.getEtudiantById(1));
    }
    @Test
    void testGetEtudiantByEmail_Found() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("etudiant_id")).thenReturn(1);
        when(mockResultSet.getString("etudiant_nom")).thenReturn("Doe");
        when(mockResultSet.getString("etudiant_prenom")).thenReturn("John");
        when(mockResultSet.getString("etudiant_email")).thenReturn("john.doe@example.com");
        when(mockResultSet.getInt("groupe_id")).thenReturn(1);
        when(mockResultSet.getString("groupe_nom")).thenReturn("Groupe A");

        Optional<EtudiantDTO> result = etudiantJDBCDAO.getEtudiantByEmail("john.doe@example.com");

        assertTrue(result.isPresent());
        assertEquals("Doe", result.get().nom());
    }

    @Test
    void testGetEtudiantByEmail_NotFound() throws SQLException {
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);

        Optional<EtudiantDTO> result = etudiantJDBCDAO.getEtudiantByEmail("john.doe@example.com");

        assertFalse(result.isPresent());
    }

    @Test
    void testCreateEtudiant_VerifyParameters() throws SQLException {
        // Arrange
        EtudiantDTO etudiant = new EtudiantDTO(0, "Doe", "John", "john.doe@example.com", mockGroupe);

        // Setup PreparedStatement to be returned when creating a prepared statement with RETURN_GENERATED_KEYS
        when(mockConnection.prepareStatement(anyString(), eq(Statement.RETURN_GENERATED_KEYS))).thenReturn(mockPreparedStatement);

        // Setup the mock ResultSet to simulate database generated keys
        ResultSet mockGeneratedKeys = mock(ResultSet.class);
        when(mockPreparedStatement.getGeneratedKeys()).thenReturn(mockGeneratedKeys);
        when(mockGeneratedKeys.next()).thenReturn(true);
        when(mockGeneratedKeys.getInt(1)).thenReturn(1);

        // Act
        etudiantJDBCDAO.createEtudiant(etudiant);

        // Assert
        // Verify the PreparedStatement parameters are set correctly
        verify(mockPreparedStatement).setString(1, etudiant.nom());
        verify(mockPreparedStatement).setString(2, etudiant.prenom());
        verify(mockPreparedStatement).setString(3, etudiant.email());
        verify(mockPreparedStatement).setObject(4, etudiant.groupe().id(), Types.INTEGER);

        // Verify executeUpdate is called, which triggers the SQL insert operation
        verify(mockPreparedStatement).executeUpdate();

        // Optionally verify that generated keys were actually requested and processed
        verify(mockPreparedStatement).getGeneratedKeys();
        verify(mockGeneratedKeys).next();
        verify(mockGeneratedKeys).getInt(1);
    }


    @Test
    void testUpdateEtudiant_VerifyParameters() throws SQLException {
        EtudiantDTO etudiant = new EtudiantDTO(1, "Doe", "John", "john.doe@example.com", mockGroupe);

        etudiantJDBCDAO.updateEtudiant(etudiant);

        verify(mockPreparedStatement).setString(1, etudiant.nom());
        verify(mockPreparedStatement).setString(2, etudiant.prenom());
        verify(mockPreparedStatement).setString(3, etudiant.email());
        verify(mockPreparedStatement).setObject(4, etudiant.groupe().id(), Types.INTEGER);
        verify(mockPreparedStatement).setInt(5, etudiant.id());
    }

}
