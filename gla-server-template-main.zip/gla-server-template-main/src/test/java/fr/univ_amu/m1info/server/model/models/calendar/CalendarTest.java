package fr.univ_amu.m1info.server.model.models.calendar;

import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.models.salle.Salle;
import org.junit.jupiter.api.*;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CalendarTest {
    private Calendar calendar;
    private CalendarSlot slot1;
    private CalendarSlot slot2;
    private Salle mockSalle;
    private Groupe mockGroupes;
    private Enseignant mockEnseignant;

    @BeforeEach
    void setUp() {
        calendar = new Calendar();
        mockSalle = mock(Salle.class);
        mockGroupes = mock(Groupe.class);
        mockEnseignant = new Enseignant(1, "John", "Doe", "johndoe@university.com");


        slot1 = new CalendarSlot(1, LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Slot 1", 1, mockSalle, mockEnseignant,mockGroupes);
        slot2 = new CalendarSlot(2, LocalDateTime.now(), LocalDateTime.now().plusHours(2), "Slot 2", 1, mockSalle, mockEnseignant,mockGroupes);
    }

    @Test
    void testAddSlot() {
        calendar.addSlot(slot1);
        List<CalendarSlot> slots = calendar.getSlots();

        assertEquals(1, slots.size());
        assertTrue(slots.contains(slot1));
    }

    @Test
    void testRemoveSlot() {
        calendar.addSlot(slot1);
        calendar.removeSlot(slot1);
        List<CalendarSlot> slots = calendar.getSlots();

        assertTrue(slots.isEmpty());
    }

    @Test
    void testUpdateSlot_Success() {
        calendar.addSlot(slot1);
        CalendarSlot updatedSlot = new CalendarSlot(1, LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Updated Slot", 2, mockSalle, mockEnseignant,mockGroupes);
        int updatedId = calendar.updateSlot(updatedSlot);

        assertEquals(1, updatedId);
        assertEquals(updatedSlot.getDescription(), calendar.getSlots().get(0).getDescription());
    }

    @Test
    void testUpdateSlot_NotFound() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> calendar.updateSlot(slot1));
        assertTrue(exception.getMessage().contains("Slot with ID"));
    }
}
