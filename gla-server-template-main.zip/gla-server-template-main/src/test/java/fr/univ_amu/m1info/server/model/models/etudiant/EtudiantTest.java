package fr.univ_amu.m1info.server.model.models.etudiant;

import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class EtudiantTest {
    private Etudiant etudiant;
    private Groupe groupe;

    @BeforeEach
    void setUp() {
        groupe = new Groupe(1, "Info"); // Assuming Groupe has an id and a name
        etudiant = new Etudiant(1, "Doe", "John", "john.doe@example.com", groupe);
    }

    @Test
    void testGetId() {
        assertEquals(1, etudiant.getId());
    }

    @Test
    void testGetNom() {
        assertEquals("Doe", etudiant.getNom());
    }

    @Test
    void testGetPrenom() {
        assertEquals("John", etudiant.getPrenom());
    }

    @Test
    void testGetEmail() {
        assertEquals("john.doe@example.com", etudiant.getEmail());
    }

    @Test
    void testGetGroupe() {
        assertEquals(groupe, etudiant.getGroupe());
    }

    @Test
    void testSetGroupe() {
        Groupe newGroupe = new Groupe(2, "Maths");
        etudiant.setGroupe(newGroupe);
        assertEquals(newGroupe, etudiant.getGroupe());
    }
}
