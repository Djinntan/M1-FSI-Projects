package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.EnseignantController;
import fr.univ_amu.m1info.server.dto.EnseignantDTO;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.testtools.JavalinTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EnseignantRoutesTest {

    private EnseignantController mockController;
    private Javalin app;
    private EnseignantRoutes enseignantRoutes;

    private EnseignantDTO mockEnseignant;

    @BeforeEach
    void setUp() {
        mockController = mock(EnseignantController.class);
        enseignantRoutes = new EnseignantRoutes(mockController);

        app = Javalin.create();
        enseignantRoutes.register(app);

        mockEnseignant = new EnseignantDTO(1, "John", "Doe", "johndoe@university.com");
    }

    @Test
    void testHandleGetAllEnseignants() {
        when(mockController.getAllEnseignants()).thenReturn(List.of(mockEnseignant));

        JavalinTest.test(app, (server, client) -> {
            var response = client.get("/enseignants");
            assertEquals(200, response.code());
            assertTrue(response.body().string().contains("johndoe@university.com"));
        });

        verify(mockController).getAllEnseignants();
    }

    @Test
    void testHandleGetEnseignantById_Found() {
        when(mockController.getEnseignantById(1)).thenReturn(mockEnseignant);

        JavalinTest.test(app, (server, client) -> {
            var response = client.get("/enseignants/1");
            assertEquals(200, response.code());
            assertTrue(response.body().string().contains("John"));
        });

        verify(mockController).getEnseignantById(1);
    }

    @Test
    void testHandleGetEnseignantById_NotFound() {
        when(mockController.getEnseignantById(2)).thenReturn(null);

        JavalinTest.test(app, (server, client) -> {
            var response = client.get("/enseignants/2");
            assertEquals(404, response.code());
            assertEquals("Enseignant non trouvé", response.body().string());
        });

        verify(mockController).getEnseignantById(2);
    }

    @Test
    void testHandleGetEnseignantById_InvalidId() {
        JavalinTest.test(app, (server, client) -> {
            var response = client.get("/enseignants/abc");
            assertEquals(400, response.code());
            assertEquals("ID invalide", response.body().string());
        });
    }

    @Test
    void testHandleCreateEnseignant_Success() {
        when(mockController.createEnseignant(any())).thenReturn(mockEnseignant);

        JavalinTest.test(app, (server, client) -> {
            var response = client.post("/enseignants", mockEnseignant);
            assertEquals(201, response.code());
            assertTrue(response.body().string().contains("johndoe@university.com"));
        });

        ArgumentCaptor<EnseignantDTO> captor = ArgumentCaptor.forClass(EnseignantDTO.class);
        verify(mockController).createEnseignant(captor.capture());
        assertEquals("John", captor.getValue().nom());
    }

    @Test
    void testHandleCreateEnseignant_BadRequest() {
        JavalinTest.test(app, (server, client) -> {
            var response = client.post("/enseignants", "INVALID_JSON");
            assertEquals(400, response.code());
            assertEquals("Requête invalide", response.body().string());
        });
    }

    @Test
    void testHandleUpdateEnseignant_Success() {
        when(mockController.updateEnseignant(eq(1), any())).thenReturn(true);

        JavalinTest.test(app, (server, client) -> {
            var response = client.put("/enseignants/1", mockEnseignant);
            assertEquals(200, response.code());
            assertEquals("Enseignant mis à jour avec succès.", response.body().string());
        });

        verify(mockController).updateEnseignant(eq(1), any());
    }

    @Test
    void testHandleUpdateEnseignant_IdMismatch() {
        EnseignantDTO differentIdEnseignant = new EnseignantDTO(2, "Jane", "Doe", "janedoe@university.com");

        JavalinTest.test(app, (server, client) -> {
            var response = client.put("/enseignants/1", differentIdEnseignant);
            assertEquals(400, response.code());
            assertEquals("ID dans l'URL et le corps ne correspondent pas", response.body().string());
        });

        verify(mockController, never()).updateEnseignant(anyInt(), any());
    }

    @Test
    void testHandleUpdateEnseignant_NotFound() {
        when(mockController.updateEnseignant(eq(1), any())).thenReturn(false);

        JavalinTest.test(app, (server, client) -> {
            var response = client.put("/enseignants/1", mockEnseignant);
            assertEquals(404, response.code());
            assertEquals("Enseignant non trouvé ou mise à jour impossible.", response.body().string());
        });

        verify(mockController).updateEnseignant(eq(1), any());
    }

    @Test
    void testHandleDeleteEnseignant_Success() {
        when(mockController.deleteEnseignant(1)).thenReturn(true);

        JavalinTest.test(app, (server, client) -> {
            var response = client.delete("/enseignants/1");
            assertEquals(204, response.code());
        });

        verify(mockController).deleteEnseignant(1);
    }

    @Test
    void testHandleDeleteEnseignant_NotFound() {
        when(mockController.deleteEnseignant(1)).thenReturn(false);

        JavalinTest.test(app, (server, client) -> {
            var response = client.delete("/enseignants/1");
            assertEquals(404, response.code());
            assertEquals("Enseignant non trouvé", response.body().string());
        });

        verify(mockController).deleteEnseignant(1);
    }

    @Test
    void testHandleDeleteEnseignant_InvalidId() {
        JavalinTest.test(app, (server, client) -> {
            var response = client.delete("/enseignants/abc");
            assertEquals(400, response.code());
            assertEquals("ID invalide", response.body().string());
        });
    }
}
