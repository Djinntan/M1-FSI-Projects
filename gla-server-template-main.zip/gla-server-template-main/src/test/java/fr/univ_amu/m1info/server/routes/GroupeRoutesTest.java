package fr.univ_amu.m1info.server.routes;

import fr.univ_amu.m1info.server.controler.GroupeController;
import fr.univ_amu.m1info.server.dto.GroupeDTO;
import io.javalin.http.Context;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GroupeRoutesTest {

    @Mock private GroupeController groupeController;
    @Mock private Context ctx;
    private GroupeRoutes groupeRoutes;

    @BeforeEach
    void setUp() {
        groupeRoutes = new GroupeRoutes(groupeController);
        when(ctx.status(anyInt())).thenReturn(ctx);
    }

    @Test
    void testHandleGetAllGroupes() {
        List<GroupeDTO> groupes = List.of(new GroupeDTO(1, "Groupe A"/*, List.of()*/));
        when(groupeController.getAllGroupes()).thenReturn(groupes);

        groupeRoutes.handleGetAllGroupes(ctx);

        verify(ctx).status(200);
        verify(ctx).json(groupes);
    }

    @Test
    void testHandleGetGroupeById_ValidId() {
        GroupeDTO groupe = new GroupeDTO(1, "Groupe A"/*, List.of()*/);
        when(ctx.pathParam("id")).thenReturn("1");
        when(groupeController.getGroupeById(1)).thenReturn(groupe);

        groupeRoutes.handleGetGroupeById(ctx);

        verify(ctx).status(200);
        verify(ctx).json(groupe);
    }

    @Test
    void testHandleGetGroupeById_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(groupeController.getGroupeById(1)).thenReturn(null);

        groupeRoutes.handleGetGroupeById(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Groupe non trouvé");
    }

    @Test
    void testHandleGetGroupeById_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("invalid");
        groupeRoutes.handleGetGroupeById(ctx);

        verify(ctx).status(400);
        verify(ctx).result("ID invalide");
    }

    @Test
    void testHandleCreateGroupe_Success() {
        GroupeDTO groupe = new GroupeDTO(-1, "Groupe B"/*, List.of()*/);
        GroupeDTO createdGroupe = new GroupeDTO(1, "Groupe B"/*, List.of()*/);
        when(ctx.bodyAsClass(GroupeDTO.class)).thenReturn(groupe);
        when(groupeController.createGroupe(any(GroupeDTO.class))).thenReturn(createdGroupe);

        groupeRoutes.handleCreateGroupe(ctx);

        verify(ctx).status(201);
        verify(ctx).json(createdGroupe);
    }

    @Test
    void testHandleCreateGroupe_InvalidBody() {
        when(ctx.bodyAsClass(GroupeDTO.class)).thenThrow(new RuntimeException());
        groupeRoutes.handleCreateGroupe(ctx);

        verify(ctx).status(400);
        verify(ctx).result("Requête invalide");
    }

    @Test
    void testHandleUpdateGroupe_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        GroupeDTO groupe = new GroupeDTO(1, "Groupe Updated"/*, List.of()*/);
        when(ctx.bodyAsClass(GroupeDTO.class)).thenReturn(groupe);
        when(groupeController.updateGroupe(1, groupe)).thenReturn(true);

        groupeRoutes.handleUpdateGroupe(ctx);

        verify(ctx).status(200);
        verify(ctx).result("Groupe mis à jour avec succès.");
    }

    @Test
    void testHandleUpdateGroupe_IdMismatch() {
        when(ctx.pathParam("id")).thenReturn("1");
        GroupeDTO groupe = new GroupeDTO(2, "Groupe Updated"/*, List.of()*/);
        when(ctx.bodyAsClass(GroupeDTO.class)).thenReturn(groupe);

        groupeRoutes.handleUpdateGroupe(ctx);

        verify(ctx).status(400);
        verify(ctx).result("ID dans l'URL et le corps ne correspondent pas");
    }

    @Test
    void testHandleUpdateGroupe_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        GroupeDTO groupe = new GroupeDTO(1, "Groupe Updated"/*, List.of()*/);
        when(ctx.bodyAsClass(GroupeDTO.class)).thenReturn(groupe);
        when(groupeController.updateGroupe(1, groupe)).thenReturn(false);

        groupeRoutes.handleUpdateGroupe(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Groupe non trouvé ou mise à jour impossible.");
    }

    @Test
    void testHandleDeleteGroupe_Success() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(groupeController.deleteGroupe(1)).thenReturn(true);

        groupeRoutes.handleDeleteGroupe(ctx);

        verify(ctx).status(204);
        verify(ctx, never()).result(anyString());
    }

    @Test
    void testHandleDeleteGroupe_NotFound() {
        when(ctx.pathParam("id")).thenReturn("1");
        when(groupeController.deleteGroupe(1)).thenReturn(false);

        groupeRoutes.handleDeleteGroupe(ctx);

        verify(ctx).status(404);
        verify(ctx).result("Groupe non trouvé");
    }

    @Test
    void testHandleDeleteGroupe_InvalidId() {
        when(ctx.pathParam("id")).thenReturn("invalid");
        groupeRoutes.handleDeleteGroupe(ctx);

        verify(ctx).status(400);
        verify(ctx).result("ID invalide");
    }
}
