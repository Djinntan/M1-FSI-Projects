package fr.univ_amu.m1info.server.database;

import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ConnectionFactoryTest {

    @Test
    void testGetConnection_Success() throws SQLException {
        try (MockedStatic<Configuration> mockedConfig = mockStatic(Configuration.class);
             MockedStatic<DriverManager> mockedDriverManager = mockStatic(DriverManager.class)) {

            mockedConfig.when(() -> Configuration.get("db_url")).thenReturn("jdbc:h2:mem:test");
            mockedConfig.when(() -> Configuration.get("db_username")).thenReturn("user");
            mockedConfig.when(() -> Configuration.get("db_password")).thenReturn("password");

            Connection mockConnection = mock(Connection.class);
            mockedDriverManager.when(() -> DriverManager.getConnection("jdbc:h2:mem:test", "user", "password"))
                    .thenReturn(mockConnection);

            Connection connection = ConnectionFactory.getConnection();

            assertNotNull(connection);
            assertEquals(mockConnection, connection);
        }
    }

    @Disabled
    void testGetConnection_Failure() {
        try (MockedStatic<Configuration> mockedConfig = mockStatic(Configuration.class);
             MockedStatic<DriverManager> mockedDriverManager = mockStatic(DriverManager.class)) {

            mockedConfig.when(() -> Configuration.get("db_url")).thenReturn("jdbc:h2:mem:test");
            mockedConfig.when(() -> Configuration.get("db_username")).thenReturn("user");
            mockedConfig.when(() -> Configuration.get("db_password")).thenReturn("password");

            mockedDriverManager.when(() -> DriverManager.getConnection("jdbc:h2:mem:test", "user", "password"))
                    .thenThrow(new SQLException("Database connection error"));

            RuntimeException exception = assertThrows(RuntimeException.class, ConnectionFactory::getConnection);

            assertNotNull(exception);
            assertTrue(exception.getMessage().contains("Erreur de connexion"));
            assertTrue(exception.getCause() instanceof SQLException);
        }
    }
}
