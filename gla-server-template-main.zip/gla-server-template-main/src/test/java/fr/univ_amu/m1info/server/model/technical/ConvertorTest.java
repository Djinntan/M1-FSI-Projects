package fr.univ_amu.m1info.server.model.technical;

import fr.univ_amu.m1info.server.dto.*;
import fr.univ_amu.m1info.server.model.models.calendar.*;
import fr.univ_amu.m1info.server.model.models.enseignant.Enseignant;
import fr.univ_amu.m1info.server.model.models.etudiant.Etudiant;
import fr.univ_amu.m1info.server.model.models.groupe.Groupe;
import fr.univ_amu.m1info.server.model.models.salle.*;
import org.junit.jupiter.api.*;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ConvertorTest {
    private SalleDTO salleDTO;
    private Salle salle;
    private GroupeDTO groupeDTO;
    private Groupe groupe;
    private EtudiantDTO etudiantDTO;
    private Etudiant etudiant;
    private EnseignantDTO enseignantDTO;
    private Enseignant enseignant;
    private CalendarSlotDTO calendarSlotDTO;
    private CalendarSlot calendarSlot;
    private Calendar calendar;
    private CalendarDTO calendarDTO;
    private SalleManager salleManager;
    private SalleManagerDTO salleManagerDTO;

    @BeforeEach
    void setUp() {
        salleDTO = new SalleDTO(1, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);
        salle = new Salle(1, "Salle A", "Batiment B", "Campus X", true, 100, TypeSalle.AMPHITHEATRE);

        groupeDTO = new GroupeDTO(1, "Groupe A" );
        groupe = new Groupe(1, "Groupe A" );

        etudiantDTO = new EtudiantDTO(0, "Doe", "John", "john.doe@example.com", groupeDTO);
        etudiant = new Etudiant(0, "Doe", "John", "john.doe@example.com", groupe);

        enseignantDTO = new EnseignantDTO(0, "Doe", "John", "john.doe@University.com");
        enseignant = new Enseignant(0, "Doe", "John", "john.doe@University.com");

        calendarSlotDTO = new CalendarSlotDTO(1, "Slot A", new TimeInterval(LocalDateTime.now(), LocalDateTime.now().plusHours(1)), 1, salleDTO, enseignantDTO, groupeDTO);
        calendarSlot = new CalendarSlot(1, LocalDateTime.now(), LocalDateTime.now().plusHours(1), "Slot A", 1, salle, enseignant, groupe);

        calendar = new Calendar();
        calendar.addSlot(calendarSlot);
        calendarDTO = new CalendarDTO(List.of(calendarSlotDTO));

        salleManager = new SalleManager();
        salleManager.addSalle(salle);
        salleManagerDTO = new SalleManagerDTO(List.of(salleDTO));
    }

    @Test
    void testFromCalendarSlotDTO() {
        CalendarSlot result = Convertor.fromCalendarSlotDTO(calendarSlotDTO);
        assertNotNull(result);
        assertEquals(calendarSlotDTO.id(), result.getId());
    }

    @Test
    void testToCalendarSlotDTO() {
        CalendarSlotDTO result = Convertor.toCalendarSlotDTO(calendarSlot);
        assertNotNull(result);
        assertEquals(calendarSlot.getId(), result.id());
    }

    @Test
    void testFromCalendarDTO() {
        Calendar result = Convertor.fromCalendarDTO(calendarDTO);
        assertNotNull(result);
        assertEquals(1, result.getSlots().size());
    }

    @Test
    void testToCalendarDTO() {
        CalendarDTO result = Convertor.toCalendarDTO(calendar);
        assertNotNull(result);
        assertEquals(1, result.calendarSlots().size());
    }

    @Test
    void testFromSalleManagerDTO() {
        SalleManager result = Convertor.fromSalleManagerDTO(salleManagerDTO);
        assertNotNull(result);
        assertEquals(1, result.getSalles().size());
    }

    @Test
    void testToSalleManagerDTO() {
        SalleManagerDTO result = Convertor.toSalleManagerDTO(salleManager);
        assertNotNull(result);
        assertEquals(1, result.salles().size());
    }

    @Test
    void testFromSalleDTO() {
        Salle result = Convertor.fromSalleDTO(salleDTO);
        assertNotNull(result);
        assertEquals(salleDTO.id(), result.getId());
    }

    @Test
    void testToSalleDTO() {
        SalleDTO result = Convertor.toSalleDTO(salle);
        assertNotNull(result);
        assertEquals(salle.getId(), result.id());
    }

    @Test
    void testFromGroupeDTO() {
        Groupe result = Convertor.fromGroupeDTO(groupeDTO);
        assertNotNull(result);
        assertEquals(groupeDTO.id(), result.getId());
    }

    @Test
    void testToGroupeDTO() {
        GroupeDTO result = Convertor.toGroupeDTO(groupe);
        assertNotNull(result);
        assertEquals(groupe.getId(), result.id());
    }

    @Test
    void testFromStringToTypeSalle_Valid() {
        TypeSalle result = Convertor.fromStringToTypeSalle("AMPHITHEATRE");
        assertEquals(TypeSalle.AMPHITHEATRE, result);
    }

    @Test
    void testFromStringToTypeSalle_Invalid() {
        assertThrows(RuntimeException.class, () -> Convertor.fromStringToTypeSalle("UNKNOWN"));
    }
}
